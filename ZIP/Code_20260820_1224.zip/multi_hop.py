# -*- coding: utf-8 -*-
"""
MultiHop — MultiChunk 的「圖 hop」版本 (drop-in preprocessor)。

跟 multi_chunk.MultiChunk 同介面，差別在「鄰居」用 provenance 圖的 k-hop，不是時間。
⚠ 圖的 key 跟 embedding 的 key 分開:embedding 用名字/屬性(有語意)、建圖用唯一 id:
    - graph_mode="shared" (SAGA/Training_data): ga=srcNode.UUID_id, gb=dstNode.UUID_id
        → 兩 event 共用任一 UUID 就相連 (a/b 交叉四種)。
    - graph_mode="tree"   (KELLECT4APT):        ga=PID, gb=PPID
        → 同 process (a==a) 或父子 (a_i==b_j, b_i==a_j) 才相連；不連純同父 siblings。
  這樣「同名不同實例的 process」不會被亂連(用 PID/UUID 區分實例)。

scales(=hops) 例如 (3,2,1);k-hop = row-normalized 鄰接連乘 A^k @ x。
forward(x, ga, gb, mask): x=[B,L,d_in], ga/gb=[B,L] long(pad 事件的 key 由 mask 排除), → [B,L,d_out]。
"""
import os
import math
import torch
import torch.nn as nn

# ★ 建圖行為開關 —— 預設 "0" = 論文當初的行為,**不要為了「修得更對」而改預設值**。
#   論文的 checkpoint 是在舊行為下訓練與評測的,改了預設就再也復現不出表中的數字。
#   MULTIHOP_MASK_INVALID=1 才啟用下面的修正(缺 UUID 不互連 + 自環),用於新實驗。
MASK_INVALID = os.environ.get("MULTIHOP_MASK_INVALID", "0") == "1"


def build_adj(ga, gb, mask, graph_mode="shared"):
    """ga/gb: [B,L] long 圖節點 id → row-normalized 鄰接 [B,L,L]。
    (由 MultiHop 與 MultiHopParallel 共用,確保兩者的圖完全一致。)

    已知問題(需 MULTIHOP_MASK_INVALID=1 才修正):
      資料缺 UUID 時會全部填 -1,直接比對相等會讓所有缺 UUID 的事件互相「相等」
      而連成完全圖 → A^k x 退化成全域平均。SAGA 沒有缺 UUID,所以兩種行為等價;
      換資料集前請先確認,再決定要不要開這個開關。
    """
    a1, a2 = ga.unsqueeze(2), ga.unsqueeze(1)
    b1, b2 = gb.unsqueeze(2), gb.unsqueeze(1)
    if MASK_INVALID:
        va1, va2 = (ga >= 0).unsqueeze(2), (ga >= 0).unsqueeze(1)
        vb1, vb2 = (gb >= 0).unsqueeze(2), (gb >= 0).unsqueeze(1)
        aa = (a1 == a2) & va1 & va2
        ab = (a1 == b2) & va1 & vb2
        ba = (b1 == a2) & vb1 & va2
        bb = (b1 == b2) & vb1 & vb2
    else:                                       # 論文行為
        aa, ab, ba, bb = (a1 == a2), (a1 == b2), (b1 == a2), (b1 == b2)
    if graph_mode == "tree":                    # 同 process 或 父子(不含 siblings)
        adj = aa | ab | ba
    else:                                       # shared:共用任一端點
        adj = aa | ab | ba | bb
    if mask is not None:                        # pad 事件不連
        m = mask.bool()
        adj = adj & m.unsqueeze(2) & m.unsqueeze(1)
    if MASK_INVALID:
        # 自環:確保每個有效事件至少連到自己,否則沒有鄰居的事件整列為 0
        eye = torch.eye(ga.size(1), dtype=torch.bool, device=ga.device).unsqueeze(0)
        if mask is not None:
            eye = eye & mask.bool().unsqueeze(2)
        adj = adj | eye
    adj = adj.float()
    return adj / adj.sum(-1, keepdim=True).clamp(min=1.0)


class _PE(nn.Module):
    """本檔自用的位置編碼(不從 ttp_model import,避免循環相依)。"""
    def __init__(self, d_model, max_len=1000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div); pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1), :]


class MultiHopParallel(nn.Module):
    """hop*3 —— **每個 hop 各自一個 Transformer**,最後才融合(對照 MultiHop 的「先融合、共用一個」)。

        for k in hops:  h_k = Transformer_k( PE( Linear_k( A^k x ) ) )
        out = LayerNorm( fuse( concat[h_1, h_2, h_3] ) )

    include_raw=False(預設,對應 PPT Table 7 的 hop*3):**沒有 hop-0 原始分支**
        → 每個分支都是被鄰域平均過的輸入,逐事件解析度會流失。
    include_raw=True :額外加一條未經聚合的原始分支(改良版,非 PPT 原設定)。
    forward 介面與 MultiHop 相同:(x, ga, gb, mask) → [B,L,d_out]
    """
    def __init__(self, d_in, d_out=None, hops=(1, 2, 3), graph_mode="shared",
                 nhead=8, layers=2, dropout=0.1, include_raw=False, max_len=1000):
        super().__init__()
        assert graph_mode in ("shared", "tree"), graph_mode
        d_out = d_out if d_out is not None else d_in
        self.d_in, self.d_out = d_in, d_out
        self.hops = tuple(hops)
        self.graph_mode = graph_mode
        self.include_raw = include_raw
        self.n_branch = len(self.hops) + (1 if include_raw else 0)
        self.proj = nn.ModuleList([nn.Linear(d_in, d_out) for _ in range(self.n_branch)])
        self.pos = _PE(d_out, max_len=max_len)
        self.tfs = nn.ModuleList([
            nn.TransformerEncoder(
                nn.TransformerEncoderLayer(d_model=d_out, nhead=nhead, dim_feedforward=d_out * 2,
                                           dropout=dropout, batch_first=True),
                num_layers=layers)
            for _ in range(self.n_branch)])
        self.fuse = nn.Linear(d_out * self.n_branch, d_out)
        self.norm = nn.LayerNorm(d_out)

    def forward(self, x, ga, gb, mask=None):
        adj = build_adj(ga, gb, mask, self.graph_mode).to(x.dtype)
        cache, cur = {}, x
        for k in range(1, max(self.hops) + 1):          # A^k @ x
            cur = torch.bmm(adj, cur); cache[k] = cur
        streams = ([x] if self.include_raw else []) + [cache[h] for h in self.hops]
        key_pad = ~mask.bool() if mask is not None else None
        outs = []
        for s, proj, tf in zip(streams, self.proj, self.tfs):
            outs.append(tf(self.pos(proj(s)), src_key_padding_mask=key_pad))
        out = self.norm(self.fuse(torch.cat(outs, dim=-1)))
        if mask is not None:
            out = out * mask.float().unsqueeze(-1)
        return out


class MultiHop(nn.Module):
    def __init__(self, d_in, d_out=None, hops=(3, 2, 1), graph_mode="shared",
                 masked=True, dropout=0.1, learnable_gate=False):
        super().__init__()
        assert graph_mode in ("shared", "tree"), graph_mode
        d_out = d_out if d_out is not None else d_in
        self.d_in, self.d_out = d_in, d_out
        self.hops = tuple(hops)
        self.graph_mode = graph_mode
        self.masked = masked
        self.learnable_gate = learnable_gate
        self.n_streams = 1 + len(self.hops)
        if learnable_gate:
            self.hop_gate = nn.Parameter(torch.zeros(len(self.hops)))
        self.fuse = nn.Sequential(
            nn.Linear(d_in * self.n_streams, d_out * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_out * 2, d_out),
        )
        self.norm = nn.LayerNorm(d_out)

    def _build_adj(self, ga, gb, mask):
        """ga/gb: [B,L] long 圖節點 id。回傳 row-normalized 鄰接 [B,L,L]。"""
        return build_adj(ga, gb, mask, self.graph_mode)   # 與 MultiHopParallel 共用同一份實作

    def forward(self, x, ga, gb, mask=None):
        adj = self._build_adj(ga, gb, mask).to(x.dtype)          # [B,L,L]
        cache, cur = {}, x
        for k in range(1, max(self.hops) + 1):                   # A^k @ x
            cur = torch.bmm(adj, cur); cache[k] = cur
        streams = [x]
        for i, h in enumerate(self.hops):
            hk = cache[h]
            if self.learnable_gate:
                hk = hk * torch.sigmoid(self.hop_gate[i])
            streams.append(hk)
        out = self.fuse(torch.cat(streams, dim=-1))
        if mask is not None:
            out = out * mask.float().unsqueeze(-1)
        return self.norm(out)


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    torch.manual_seed(0)
    B, L, D = 2, 6, 8
    x = torch.randn(B, L, D)
    mask = torch.ones(B, L, dtype=torch.bool); mask[0, 4:] = False
    # tree(KELLECT): ga=pid, gb=ppid。seq0: pid=[10,11,10,12], ppid=[9,10,9,99]
    #   event3(pid12,ppid99) 跟 pid10 無關係 → 不連。
    ga = torch.tensor([[10, 11, 10, 12, -1, -1], [1, 2, 3, 4, 5, 6]])
    gb = torch.tensor([[9, 10, 9, 99, -1, -1], [0, 1, 1, 2, 2, 3]])
    mh = MultiHop(D, 16, hops=(3, 2, 1), graph_mode="tree", learnable_gate=True)
    y = mh(x, ga, gb, mask)
    assert y.shape == (B, L, 16) and torch.all(y[0, 4:].abs() < 1e-6)
    # event0(pid10) 應連 event2(同proc pid10) + event1(ppid10=event0.pid,子)；不連 event3
    adj = mh._build_adj(ga, gb, mask)[0]
    nb0 = (adj[0] > 0).nonzero().flatten().tolist()
    print("tree seq0 event0 鄰居:", nb0, "(期望 0,1,2 — 自己/子11/同proc10;不連無關的3)")
    assert set(nb0) == {0, 1, 2}
    # shared(SFM): ga=src_uuid, gb=dst_uuid
    mh2 = MultiHop(D, 16, hops=(2, 1), graph_mode="shared")
    ga2 = torch.tensor([[100, 200, 300, 100, -1, -1], [1, 2, 3, 4, 5, 6]])
    gb2 = torch.tensor([[200, 300, 400, 900, -1, -1], [7, 8, 9, 10, 11, 12]])
    adj2 = mh2._build_adj(ga2, gb2, mask)[0]
    nb0b = (adj2[0] > 0).nonzero().flatten().tolist()
    print("shared seq0 event0 鄰居:", nb0b, "(期望 0,1,3 — 共用 uuid200 / src100)")
    assert set(nb0b) == {0, 1, 3}
    print("MultiHop 兩種 graph_mode 鄰接正確，padding 歸零。smoke passed.")

# -*- coding: utf-8 -*-
"""
TTP tagger (Transformer+CRF) — KELLECT4APT / train-valid-test 版本
==================================================================
改自先前的 episodic few-shot 版；**模型/損失/權重結構完全不動**
(Transformer_CRF、FocalLoss、class weight、推論端 O-bias 全保留 →
存出來的 checkpoint 仍可被 infer_K4APT.py 直接載入)。

切分方式(這版重點)：
  每個 TTP(=資料夾名)先固定保留 HOLDOUT_PER_CLASS 個樣本當「inference」
  (絕不進 train/valid/test)；其餘樣本再按比例切 train / valid / test。
    - train  : 訓練
    - valid  : 選 best epoch + 決定 deploy O-bias（test 不偷看）
    - test   : 最終回報 P/R/F1（result.csv）
    - inference holdout : 存成清單，交給 infer_K4APT.py 單獨推論
  → 不再是 few-shot：用「全部類別」、單一模型訓練，比 3-shot 穩很多。
  → 合格門檻只要該類 >= HOLDOUT_PER_CLASS + MIN_TRAIN（預設 1+1=2）。

資料 / 事件抽取與 make_emb_K4APT.py 共用 kellect_event.py(event→三元組)，
node/edge 字串保證一致，不會 OOV。

調參改最上面 CONFIG。
"""
import os
import re
import math
import json
import random
import pickle
import logging
import gc
import time
import atexit
import argparse
import hashlib
from glob import glob
from collections import defaultdict

import numpy as np
import pandas as pd
from tqdm import tqdm
from sklearn.metrics import classification_report, precision_recall_fscore_support

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchcrf import CRF
from torch.utils.data import DataLoader

from ckpt_guard import safe_save   # best.pt 是固定檔名,存之前先備份上一次的

from kellect_event import iter_events, event_to_triple, event_ts

# ======================================================================
# CONFIG
# ======================================================================
SEED          = 42
WINDOW_SIZE   = 256
STRIDE        = 32
BATCH_SIZE    = 64
EPOCHS        = 20
LR            = 1e-4        # 正常 train 集(非 3-shot)用較保守 LR，配 best-on-valid 更穩
WARMUP_RATIO  = 0.1         # 前 10% epoch 線性 warmup，再接 cosine 衰減
PATIENCE      = 0           # valid 連續幾個 epoch 沒進步就 early-stop(0=不啟用)

# ---- 切分：每類留 HOLDOUT 個做 inference，其餘按比例切 train/valid/test ----
HOLDOUT_PER_CLASS = 1       # 每類固定保留幾個樣本當 inference(永不進 train/valid/test)
VAL_RATIO     = 0.2         # 扣掉 inference 後，valid 佔比
TEST_RATIO    = 0.2         # 扣掉 inference 後，test 佔比 (其餘全給 train，train 有優先權)
MIN_TRAIN     = 1           # 扣掉 inference 後 train_pool 至少要有幾個，這類才收(否則整類跳過)

# ---- 保守度控制 ----
ATTACK_CLASS_WEIGHT = 3.0
O_CLASS_WEIGHT      = 1.0
FOCAL_GAMMA         = 2.0
O_DECODE_BIAS       = None  # None → 用 val 自動建議；設數值 → 直接用
O_BIAS_SWEEP        = [0.0, 0.5, 1.0, 2.0, 4.0, 8.0]
RECALL_TOL          = 0.02

# ---- 評估加速 (val/test/inference 只取非重疊視窗即可算 token 指標) ----
EVAL_NONOVERLAP  = True
EVAL_MAX_WINDOWS = 8000     # val/test 各自視窗上限；超過就隨機抽樣 (0=不限)

# ---- 資料 / label ----
DATA_ROOT     = "./KELLECT4APT/public_data"
STRIP_VARIANT_SUFFIX = False
VARIANT_RE    = re.compile(r"-\d+$")
BENIGN_NAMES  = {"O", "benign", "BENIGN", "normal", "NORMAL", "none", "NONE"}

# ---- 資產路徑 ----
SB_DIR        = "./SecureBERT2.0-K4APT"
LABEL2IDX_OUT = "./label2index_kellect4apt.pkl"
IDX2LABEL_OUT = "./index2label_kellect4apt.pkl"
CACHE_TRACES  = "./kellect4apt_traces.pt"
MODEL_SAVE    = "./Trans_CRF_KELLECT4APT/save_model"
RESULT_SAVE   = "./Trans_CRF_KELLECT4APT/save_result"
# ======================================================================

ap = argparse.ArgumentParser()
ap.add_argument("--data_root", default=DATA_ROOT)
ap.add_argument("--sb_dir", default=SB_DIR)
ap.add_argument("--holdout", type=int, default=HOLDOUT_PER_CLASS)
ap.add_argument("--val_ratio", type=float, default=VAL_RATIO)
ap.add_argument("--test_ratio", type=float, default=TEST_RATIO)
ap.add_argument("--min_train", type=int, default=MIN_TRAIN)
ap.add_argument("--lr", type=float, default=LR)
ap.add_argument("--epochs", type=int, default=EPOCHS)
ap.add_argument("--patience", type=int, default=PATIENCE)
ap.add_argument("--strip_variant", action="store_true", default=STRIP_VARIANT_SUFFIX)
ap.add_argument("--rebuild_cache", action="store_true")
args, _ = ap.parse_known_args()   # 忽略舊 CLI(--episodes/--n_way/--k_shot 等) 不會報錯
DATA_ROOT = args.data_root
SB_DIR = args.sb_dir
HOLDOUT_PER_CLASS = args.holdout
VAL_RATIO = args.val_ratio
TEST_RATIO = args.test_ratio
MIN_TRAIN = args.min_train
LR = args.lr
EPOCHS = args.epochs
PATIENCE = args.patience
STRIP_VARIANT_SUFFIX = args.strip_variant

random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")
logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

# ----------------------------------------------------------------------
# 讀資產：node/edge vocab + embedding (由 make_emb_K4APT.py 產)
# ----------------------------------------------------------------------
with open(f"{SB_DIR}/nodes/vocab2idx.pkl", "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/edges/vocab2idx.pkl", "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/nodes_ent2emb_256.pkl", "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(f"{SB_DIR}/edges_ent2emb_16.pkl", "rb") as fp:
    edge_ent2emb = pickle.load(fp)

NODE_EMB_SIZE = 256
EDGE_EMB_SIZE = 16
EVENT_DIM = NODE_EMB_SIZE * 2 + EDGE_EMB_SIZE

node_emb_tensor = torch.tensor(np.array(node_ent2emb), dtype=torch.float32).to(device)
edge_emb_tensor = torch.tensor(np.array(edge_ent2emb), dtype=torch.float32).to(device)
NODE_PAD_IDX = node_emb_tensor.shape[0]
EDGE_PAD_IDX = edge_emb_tensor.shape[0]
node_emb_tensor = torch.cat([node_emb_tensor, torch.zeros(1, NODE_EMB_SIZE).to(device)], dim=0)
edge_emb_tensor = torch.cat([edge_emb_tensor, torch.zeros(1, EDGE_EMB_SIZE).to(device)], dim=0)


# ----------------------------------------------------------------------
# label 由資料夾名決定
# ----------------------------------------------------------------------
def label_of(json_path):
    name = os.path.basename(os.path.dirname(json_path))
    if STRIP_VARIANT_SUFFIX:
        name = VARIANT_RE.sub("", name)
    if name in BENIGN_NAMES:
        return "O"
    return name


def scan_dataset(data_root):
    paths = glob(os.path.join(data_root, "**", "*.json"), recursive=True)
    if not paths:
        raise FileNotFoundError(
            f"在 {data_root} 底下找不到任何 .json。\n"
            f"請把 --data_root 指到 KELLECT4APT/public_data。")
    by_class = defaultdict(list)
    for p in paths:
        by_class[label_of(p)].append(p)
    return by_class, paths


by_class_all, all_json = scan_dataset(DATA_ROOT)

# schema 探針
try:
    _peek = iter_events(all_json[0])
    logging.info(f"[schema 探針] {all_json[0]}  (前 {min(len(_peek),200)} 筆抽樣)")
    if _peek:
        logging.info(f"  第一筆事件 keys = {list(_peek[0].keys())}")
        _ok = [t for t in (event_to_triple(e) for e in _peek[:200]) if t is not None]
        logging.info(f"  可轉三元組比率 = {len(_ok)}/{min(len(_peek),200)}")
        if _ok:
            s, ed, d = _ok[0]
            logging.info(f"  範例三元組: src={s!r} edge={ed!r} dst={d!r}")
        else:
            logging.warning("前 200 筆都轉不出三元組 → 確認事件是 Event/PName/args 結構(kellect_event.py)。")
except Exception as _ex:
    logging.warning(f"schema 探針失敗: {_ex}")

# ----------------------------------------------------------------------
# label2index / index2label：由所有 label 建立(O 若存在放 index 0)
# ----------------------------------------------------------------------
labels_sorted = sorted(by_class_all.keys())
ordered = (["O"] if "O" in labels_sorted else []) + [l for l in labels_sorted if l != "O"]
label2index = {l: i for i, l in enumerate(ordered)}
index2label = {i: l for l, i in label2index.items()}
with open(LABEL2IDX_OUT, "wb") as fp:
    pickle.dump(label2index, fp)
with open(IDX2LABEL_OUT, "wb") as fp:
    pickle.dump(index2label, fp)

OUTPUT_SIZE = len(label2index)
O_IDX = label2index.get("O", -1)
PAD_LABEL = O_IDX if O_IDX != -1 else 0

counts = {l: len(v) for l, v in by_class_all.items()}
logging.info("=== KELLECT4APT 掃描結果 ===")
logging.info(f"總 .json 樣本數 = {len(all_json)}；類別數(含O={'有' if O_IDX!=-1 else '無'}) = {OUTPUT_SIZE}")
_dist = sorted(counts.items(), key=lambda x: -x[1])
logging.info("樣本數最多的幾類: " + ", ".join(f"{l}:{c}" for l, c in _dist[:8]))
logging.info("樣本數最少的幾類: " + ", ".join(f"{l}:{c}" for l, c in _dist[-8:]))


# ----------------------------------------------------------------------
# 一個 sample(.json) → window 清單(label 全填該 sample 的類別)
# ----------------------------------------------------------------------
def process_sample(json_path, label_idx):
    events = iter_events(json_path)
    events.sort(key=event_ts)
    seq_src, seq_rel, seq_dst = [], [], []
    for e in events:
        tri = event_to_triple(e)
        if tri is None:
            continue
        src, edge, dst = tri
        seq_src.append(node_ent2idx.get(src, NODE_PAD_IDX))
        seq_rel.append(edge_ent2idx.get(edge, EDGE_PAD_IDX))
        seq_dst.append(node_ent2idx.get(dst, NODE_PAD_IDX))
    n = len(seq_src)
    if n == 0:
        return []
    seq_lab = [label_idx] * n
    seq_msk = [1] * n
    if n % WINDOW_SIZE != 0:
        pad_len = (WINDOW_SIZE - n if n < WINDOW_SIZE
                   else ((n - WINDOW_SIZE) // STRIDE + 1) * STRIDE + WINDOW_SIZE - n)
        seq_src += [NODE_PAD_IDX] * pad_len
        seq_rel += [EDGE_PAD_IDX] * pad_len
        seq_dst += [NODE_PAD_IDX] * pad_len
        seq_lab += [PAD_LABEL] * pad_len
        seq_msk += [0] * pad_len
    windows = []
    for i in range(0, len(seq_src) - WINDOW_SIZE + 1, STRIDE):
        windows.append({
            "src": torch.tensor(seq_src[i:i+WINDOW_SIZE], dtype=torch.long),
            "rel": torch.tensor(seq_rel[i:i+WINDOW_SIZE], dtype=torch.long),
            "dst": torch.tensor(seq_dst[i:i+WINDOW_SIZE], dtype=torch.long),
            "label_idx": torch.tensor(seq_lab[i:i+WINDOW_SIZE], dtype=torch.long),
            "mask": torch.tensor(seq_msk[i:i+WINDOW_SIZE], dtype=torch.bool),
            "process": json_path,
        })
    return windows


def build_or_load_cache():
    if os.path.exists(CACHE_TRACES) and not args.rebuild_cache:
        logging.info(f"載入 sample 視窗快取 {CACHE_TRACES} ...")
        blob = torch.load(CACHE_TRACES, weights_only=False)
        if (blob.get("label2index") == label2index
                and blob.get("strip") == STRIP_VARIANT_SUFFIX
                and blob.get("scheme") == "kellect_triple_v1"):
            return blob["by_class"]
        logging.warning("快取的 label/strip/scheme 與現在不符 → 重建。")
    by_class = defaultdict(list)
    for lab, paths in tqdm(by_class_all.items(), desc="processing samples"):
        li = label2index[lab]
        for p in paths:
            w = process_sample(p, li)
            if w:
                by_class[lab].append({"path": p, "windows": w})
        gc.collect()
    torch.save({"by_class": dict(by_class), "label2index": label2index,
                "strip": STRIP_VARIANT_SUFFIX, "scheme": "kellect_triple_v1"}, CACHE_TRACES)
    logging.info(f"已存快取 {CACHE_TRACES}")
    return by_class

by_class = build_or_load_cache()


# ----------------------------------------------------------------------
# 切分：每類先扣掉 inference holdout，其餘切 train/valid/test
# ----------------------------------------------------------------------
def _stable_seed(s):
    return int(hashlib.md5(s.encode("utf-8")).hexdigest(), 16) % (2**32)


def split_counts(R):
    """扣掉 inference 後剩 R 個 → (train, val, test)。train 有優先權(至少 1)。"""
    if R <= 0:
        return 0, 0, 0
    te = int(round(R * TEST_RATIO))
    va = int(round(R * VAL_RATIO))
    tr = R - te - va
    if tr < MIN_TRAIN:
        tr = min(R, MIN_TRAIN)
        rem = R - tr
        denom = VAL_RATIO + TEST_RATIO
        te = int(round(rem * (TEST_RATIO / denom))) if denom > 0 else 0
        va = rem - te
    return tr, va, te


eval_sub = max(1, WINDOW_SIZE // STRIDE) if EVAL_NONOVERLAP else 1


def _cap(windows, rng, name):
    if EVAL_MAX_WINDOWS and len(windows) > EVAL_MAX_WINDOWS:
        idx = list(range(len(windows))); rng.shuffle(idx)
        keep = sorted(idx[:EVAL_MAX_WINDOWS])
        logging.info(f"    [{name}] 視窗 {len(windows)} > 上限 {EVAL_MAX_WINDOWS} → 抽樣至 {EVAL_MAX_WINDOWS}")
        windows = [windows[i] for i in keep]
    return windows


os.makedirs(RESULT_SAVE, exist_ok=True)
os.makedirs(MODEL_SAVE, exist_ok=True)

train_w, val_w, test_w, infer_w = [], [], [], []
holdout_files = []          # (label, path)
class_rows = []             # 每類切分統計
used_classes, dropped = [], []

for lab in sorted(by_class):
    if lab == "O":
        continue
    samples = sorted(by_class[lab], key=lambda d: d["path"])
    random.Random(_stable_seed(lab) ^ SEED).shuffle(samples)      # 穩定洗牌
    hold = samples[:HOLDOUT_PER_CLASS]                            # inference holdout
    rest = samples[HOLDOUT_PER_CLASS:]
    if len(rest) < MIN_TRAIN or len(hold) < HOLDOUT_PER_CLASS:
        dropped.append((lab, len(samples)))
        continue
    tr, va, te = split_counts(len(rest))
    tr_s, va_s, te_s = rest[:tr], rest[tr:tr+va], rest[tr+va:tr+va+te]
    for d in tr_s: train_w.extend(d["windows"])                   # train: 全部重疊視窗
    for d in va_s: val_w.extend(d["windows"][::eval_sub])         # val/test/infer: 非重疊
    for d in te_s: test_w.extend(d["windows"][::eval_sub])
    for d in hold:
        infer_w.extend(d["windows"][::eval_sub])
        holdout_files.append((lab, d["path"]))
    used_classes.append(lab)
    class_rows.append({"label": lab, "total": len(samples), "inference": len(hold),
                       "train": len(tr_s), "valid": len(va_s), "test": len(te_s)})

val_w  = _cap(val_w, random.Random(SEED), "val")
test_w = _cap(test_w, random.Random(SEED + 1), "test")

# 存 inference holdout 清單 + 每類切分統計
with open(f"{RESULT_SAVE}/infer_holdout_files.txt", "w", encoding="utf-8") as fp:
    for lab, p in holdout_files:
        fp.write(f"{lab}\t{p}\n")
pd.DataFrame(class_rows).to_csv(f"{RESULT_SAVE}/split_per_class.csv", index=False)

atk = sorted({label2index[l] for l in used_classes})
logging.info("=== 切分結果 (每類 1 個 inference + 其餘 train/valid/test) ===")
logging.info(f"可用類別 = {len(used_classes)} / {OUTPUT_SIZE - (1 if O_IDX!=-1 else 0)}；"
             f"跳過(樣本不足 {HOLDOUT_PER_CLASS + MIN_TRAIN}) = {len(dropped)}")
if dropped:
    logging.info("  跳過的類別: " + ", ".join(f"{l}({c})" for l, c in dropped[:20]))
logging.info(f"視窗數: train={len(train_w)}  val={len(val_w)}  test={len(test_w)}  inference={len(infer_w)}")
logging.info(f"held-out 清單 → {RESULT_SAVE}/infer_holdout_files.txt；逐類切分 → {RESULT_SAVE}/split_per_class.csv")

if not train_w or not used_classes:
    # 自我診斷：schema 對不上(視窗全空)
    n_total = sum(counts.values()); n_nonempty = sum(len(v) for v in by_class.values())
    logging.error("========== 前置診斷 ==========")
    logging.error(f"類別數={len(counts)} 原始json={n_total} 產出非空視窗的樣本數={n_nonempty}")
    if n_total > 0 and n_nonempty <= max(1, n_total * 0.05):
        tev, ntri, evt = 0, 0, defaultdict(int)
        for p in all_json[:30]:
            for e in iter_events(p):
                tev += 1
                if isinstance(e, dict): evt[e.get("Event", "?")] += 1
                if event_to_triple(e) is not None: ntri += 1
        logging.error(f"[判別] 幾乎產不出視窗：可轉三元組 = {ntri}/{tev}")
        logging.error(f"  Event 型別(前15)：{sorted(evt.items(), key=lambda x:-x[1])[:15]}")
        logging.error("  → 檢查 kellect_event.event_to_triple 是否涵蓋這些 Event/args；確認 SB_DIR 是 make_emb_K4APT 產的。")
    raise RuntimeError("沒有可用的訓練資料/類別。見上面『前置診斷』。")


# ======================================================================
# Model (與原版一致 → checkpoint 可被 infer_K4APT.py 載入)
# ======================================================================
class FocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=2.0, reduction="mean"):
        super().__init__()
        self.weight = weight; self.gamma = gamma; self.reduction = reduction

    def forward(self, inputs, targets):
        ce = F.cross_entropy(inputs, targets, weight=self.weight, reduction="none")
        pt = torch.exp(-ce)
        focal = ((1 - pt) ** self.gamma) * ce
        return focal.mean() if self.reduction == "mean" else (focal.sum() if self.reduction == "sum" else focal)


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1), :]


class Transformer_CRF(nn.Module):
    def __init__(self, embedding_dim, output_size, layers, nhead, device, dropout=0.2):
        super().__init__()
        self.device = device
        self.tagset_size = output_size
        self.d_model = 512
        self.input_proj = nn.Linear(embedding_dim, self.d_model)
        self.pos_encoder = PositionalEncoding(self.d_model, max_len=1000)
        encoder_layers = nn.TransformerEncoderLayer(
            d_model=self.d_model, nhead=nhead, dim_feedforward=self.d_model * 2,
            dropout=dropout, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers=layers)
        self.hidden2tag = nn.Linear(self.d_model, output_size)
        self.crf = CRF(num_tags=output_size, batch_first=True)

        self.o_idx = label2index.get("O", -1)
        self.decode_o_bias = 0.0

        self.loss_weights = torch.ones(output_size).to(device) * ATTACK_CLASS_WEIGHT
        if self.o_idx != -1:
            self.loss_weights[self.o_idx] = O_CLASS_WEIGHT
        self.focal_loss = FocalLoss(weight=self.loss_weights, gamma=FOCAL_GAMMA)

    def emissions(self, x, mask_tensor=None):
        x = self.pos_encoder(self.input_proj(x))
        key_pad = ~mask_tensor if mask_tensor is not None else None
        out = self.transformer_encoder(x, src_key_padding_mask=key_pad)
        return self.hidden2tag(out)

    def compute_loss(self, feats, label_tensor, mask_tensor):
        crf_loss = -self.crf(emissions=feats, tags=label_tensor, mask=mask_tensor, reduction="mean")
        active = mask_tensor.view(-1)
        foc = self.focal_loss(feats.view(-1, self.tagset_size)[active], label_tensor.view(-1)[active])
        return crf_loss + foc

    def decode(self, feats, mask_tensor, o_bias=None):
        b = self.decode_o_bias if o_bias is None else o_bias
        if b != 0.0 and self.o_idx != -1:
            feats = feats.clone()
            feats[:, :, self.o_idx] = feats[:, :, self.o_idx] + b
        return self.crf.decode(emissions=feats, mask=mask_tensor)

    def forward(self, sentence_tensor, label_tensor=None, mask_tensor=None):
        feats = self.emissions(sentence_tensor, mask_tensor)
        loss = self.compute_loss(feats, label_tensor, mask_tensor) if label_tensor is not None else None
        if self.training:
            return None, loss
        return self.decode(feats, mask_tensor), loss


def _feat(data):
    src = data["src"].to(device, non_blocking=True)
    rel = data["rel"].to(device, non_blocking=True)
    dst = data["dst"].to(device, non_blocking=True)
    return torch.cat([node_emb_tensor[src], edge_emb_tensor[rel], node_emb_tensor[dst]], dim=-1)


@torch.no_grad()
def eval_sweep(model, loader, biases, attack_labels, desc=""):
    if loader is None or len(loader.dataset) == 0 or not attack_labels:
        return {b: (0.0, 0.0, 0.0) for b in biases}
    model.eval()
    t0 = time.time()
    trues_all, preds_by_bias = [], {b: [] for b in biases}
    it = tqdm(loader, desc=desc, leave=False) if desc else loader
    for data in it:
        feats = model.emissions(_feat(data), data["mask"].to(device, non_blocking=True)).float()
        mask = data["mask"].to(device, non_blocking=True)
        label_cpu = data["label_idx"].cpu().tolist()
        for k, b in enumerate(biases):
            out = model.decode(feats, mask, o_bias=b)
            for idx, pred in enumerate(out):
                preds_by_bias[b].extend(pred)
                if k == 0:
                    trues_all.extend(label_cpu[idx][:len(pred)])
    rows = {}
    for b in biases:
        p, r, f, _ = precision_recall_fscore_support(
            trues_all, preds_by_bias[b], labels=attack_labels, average="macro", zero_division=0)
        rows[b] = (p, r, f)
    if desc:
        logging.info(f"    [{desc}] {len(loader.dataset)} win × {len(biases)} bias 用時 {time.time()-t0:.1f}s")
    return rows


def recommend_bias(rows, base_bias=0.0, recall_tol=RECALL_TOL):
    base_r = rows.get(base_bias, (0, 0, 0))[1]
    cands = [(b, v) for b, v in rows.items() if v[1] >= base_r - recall_tol]
    if not cands:
        return base_bias
    return max(cands, key=lambda x: (x[1][0], x[0]))[0]


def make_loader(windows, shuffle):
    return DataLoader(windows, batch_size=BATCH_SIZE, shuffle=shuffle,
                      num_workers=0, pin_memory=True) if windows else None


# ======================================================================
# checkpoint 存檔工具
# ======================================================================
def _make_ckpt_blob(state, bias):
    return {
        "state_dict": state, "deploy_o_bias": bias,
        "label2index": label2index, "index2label": index2label,
        "arch": {"event_dim": EVENT_DIM, "output_size": OUTPUT_SIZE,
                 "d_model": 512, "layers": 2, "nhead": 8, "dropout": 0.2},
        "window_size": WINDOW_SIZE, "stride": STRIDE,
        "sb_dir": SB_DIR, "scheme": "kellect_triple_v1",
    }


def save_best_ckpt(state, bias, metric, archival=False):
    blob = _make_ckpt_blob(state, bias)
    # best.pt 是固定檔名:safe_save 會先把「上一次執行」留下的備份成 .bak_<時間>,
    # 每個 process 只備份一次。archival 分支本來就寫帶分數的檔名,所以 unique=False。
    safe_save(blob, f"{MODEL_SAVE}/best.pt", score=metric, unique=not archival, quiet=True)
    if archival:
        torch.save(blob, f"{MODEL_SAVE}/best_valF1_{metric:.4f}_bias_{bias}.pt")
    logging.info(f"    ✔ best.pt 已更新{' [archival]' if archival else ''} (metric={metric:.4f}, bias={bias})")


# ======================================================================
# 單一模型 train / valid / test
# ======================================================================
train_loader = make_loader(train_w, True)
val_loader   = make_loader(val_w, False)
test_loader  = make_loader(test_w, False)
infer_loader = make_loader(infer_w, False)

model = Transformer_CRF(EVENT_DIM, OUTPUT_SIZE, layers=2, nhead=8, device=device, dropout=0.2).to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-5)

_WARMUP_EPOCHS = max(1, int(EPOCHS * WARMUP_RATIO))
def _warmup_cosine(e):
    if e < _WARMUP_EPOCHS:
        return (e + 1) / _WARMUP_EPOCHS
    prog = (e - _WARMUP_EPOCHS) / max(1, EPOCHS - _WARMUP_EPOCHS)
    return 0.5 * (1.0 + math.cos(math.pi * min(1.0, prog)))
scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, _warmup_cosine)
scaler = torch.amp.GradScaler("cuda")

best_val, best_state = float("-inf"), None
deploy_bias = O_DECODE_BIAS if O_DECODE_BIAS is not None else 0.0
_disk_best = float("-inf")
_final_saved = False
no_improve = 0


def _emergency_save():
    if _final_saved or best_state is None:
        return
    try:
        save_best_ckpt(best_state, deploy_bias, best_val)
        logging.warning("⚠ 偵測到中斷 → 已把當前最佳權重緊急存到 best.pt")
    except Exception as ex:
        logging.error(f"緊急存檔失敗: {ex}")
atexit.register(_emergency_save)

logging.info(f"===== 開始訓練 | {len(used_classes)} 類 | train_win={len(train_w)} "
             f"val_win={len(val_w)} test_win={len(test_w)} | EPOCHS={EPOCHS} LR={LR} =====")
for epoch in range(EPOCHS):
    model.train()
    losses = []
    for data in tqdm(train_loader, desc=f"epoch{epoch} train", leave=False):
        label = data["label_idx"].to(device, non_blocking=True)
        mask = data["mask"].to(device, non_blocking=True)
        optimizer.zero_grad()
        with torch.amp.autocast("cuda"):
            _, loss = model(_feat(data), label, mask)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        scaler.step(optimizer); scaler.update()
        losses.append(loss.item())
    scheduler.step()

    if val_loader is not None:
        vf1 = eval_sweep(model, val_loader, [0.0], atk)[0.0][2]
        sel = vf1
    else:
        sel = -np.mean(losses); vf1 = float("nan")
    improved = sel > best_val
    if improved:
        best_val = sel
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        no_improve = 0
    else:
        no_improve += 1
    logging.info(f"  epoch{epoch} lr={optimizer.param_groups[0]['lr']:.2e} "
                 f"loss={np.mean(losses):.4f} val_atkF1={vf1:.4f}{'  *' if improved else ''}")
    # 即時落盤(只在贏過硬碟最佳時)，中途崩潰不白跑
    if improved and best_state is not None and best_val > _disk_best:
        _disk_best = best_val
        save_best_ckpt(best_state, deploy_bias, best_val)
    if PATIENCE and no_improve >= PATIENCE:
        logging.info(f"  early-stop：valid 連續 {PATIENCE} epoch 沒進步。")
        break

if best_state is not None:
    model.load_state_dict(best_state)

# 決定 deploy O-bias (valid 上)
logging.info("訓練完成 → valid bias-sweep + test/inference 評估 ...")
if val_loader is not None:
    vrows = eval_sweep(model, val_loader, O_BIAS_SWEEP, atk, desc="val-bias-sweep")
    deploy_bias = O_DECODE_BIAS if O_DECODE_BIAS is not None else recommend_bias(vrows)
else:
    deploy_bias = O_DECODE_BIAS if O_DECODE_BIAS is not None else 0.0

# test 指標(base vs deploy)
if test_loader is not None:
    trows = eval_sweep(model, test_loader, sorted(set([0.0, deploy_bias])), atk, desc="test")
    (bp, br, bf) = trows[0.0]; (dp, dr, df) = trows[deploy_bias]
    logging.info(f"[TEST base   bias=0        ] P={bp:.4f} R={br:.4f} F1={bf:.4f}")
    logging.info(f"[TEST deploy bias={deploy_bias:<4}] P={dp:.4f} R={dr:.4f} F1={df:.4f}")
else:
    logging.warning("test 集為空(類別樣本太少)→ 跳過 test 指標，改看 inference holdout。")

# inference holdout 指標
if infer_loader is not None:
    irows = eval_sweep(model, infer_loader, sorted(set([0.0, deploy_bias])), atk, desc="inference")
    (ip, ir, iff) = irows[deploy_bias]
    logging.info(f"[INFERENCE holdout bias={deploy_bias:<4}] P={ip:.4f} R={ir:.4f} F1={iff:.4f}")

# ======================================================================
# 存 checkpoint + 逐類 classification_report(在 test；test 空則用 inference holdout)
# ======================================================================
save_best_ckpt(best_state, deploy_bias, best_val, archival=True)
_final_saved = True
logging.info(f"saved {MODEL_SAVE}/best.pt (自帶 arch/label/bias，給 infer_K4APT.py)")

report_loader = test_loader if test_loader is not None else infer_loader
report_name = "test" if test_loader is not None else "inference_holdout"
if report_loader is not None:
    model.decode_o_bias = deploy_bias
    preds, labs = [], []
    model.eval()
    with torch.no_grad():
        for data in tqdm(report_loader, desc=f"{report_name} collect-preds", leave=False):
            mask = data["mask"].to(device, non_blocking=True)
            with torch.amp.autocast("cuda"):
                out, _ = model(_feat(data), None, mask)
            lc = data["label_idx"].cpu().tolist()
            for idx, pred in enumerate(out):
                preds.extend(pred); labs.extend(lc[idx][:len(pred)])
    report = classification_report(labs, preds, output_dict=True, zero_division=0)
    rdf = pd.DataFrame(report).transpose().reset_index(names="label")
    rdf["label"] = rdf["label"].apply(lambda x: index2label.get(int(x), x) if str(x).isdigit() else x)
    rdf.to_csv(f"{RESULT_SAVE}/result.csv", index=False)
    logging.info(f"saved {RESULT_SAVE}/result.csv  (在 {report_name}，deploy O-bias={deploy_bias})")

logging.info("Done. inference 樣本用 infer_K4APT.py 跑：python infer_K4APT.py")

# ======================================================================
# 需要提供 / 先產生哪些檔
# ----------------------------------------------------------------------
#  共用: kellect_event.py (事件→三元組；本 script 與 make_emb_K4APT.py 都 import)
#  A. 本 script 自動產生：label2index/index2label_kellect4apt.pkl、kellect4apt_traces.pt、
#     save_result/{infer_holdout_files.txt, split_per_class.csv, result.csv}、save_model/best.pt
#  B. 先用 make_emb_K4APT.py 對 KELLECT4APT 重生(不需 relations.txt)：
#       python make_emb_K4APT.py --data_glob "./KELLECT4APT/public_data/**/*.json" \
#              --save_dir ./SecureBERT2.0-K4APT
#     → SecureBERT2.0-K4APT/{nodes,edges}/vocab2idx.pkl + {nodes_ent2emb_256,edges_ent2emb_16}.pkl
# ======================================================================

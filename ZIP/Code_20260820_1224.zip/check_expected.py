# -*- coding: utf-8 -*-
"""check_expected.py — 比對推論 log 的數字與論文表格是否一致。

從 log 抽出逐 campaign 的 P/R/F1,重算 5-campaign(C1,C3,C5,C6,C7)平均,
再與 expected_results.json 的期望值比對,超出容差就標 FAIL 並 exit 1。

用法:
    python check_expected.py --log repro/t1_plain.log --key t1_plain
    python check_expected.py --log repro/t3_hop.log --key t3_hop --tol 1.0
"""
import os, re, json, argparse
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("--log", required=True)
ap.add_argument("--key", required=True, help="expected_results.json 裡 saga 底下的鍵")
ap.add_argument("--expected", default="expected_results.json")
ap.add_argument("--campaigns", default="C1,C3,C5,C6,C7")
ap.add_argument("--tol", type=float, default=None, help="嚴格容差(百分點),之內算 OK;預設讀 json")
ap.add_argument("--warn_tol", type=float, default=None,
                help="警告上限(百分點);tol~warn_tol 之間標 WARN 但不算失敗,超過才 FAIL")
ap.add_argument("--allow_better", action="store_true",
                help="實測比論文好就算通過(標 BETTER)。只有變差才算 FAIL。")
ap.add_argument("--brief", action="store_true",
                help="多印一行 RESULT<TAB>… ,給 sweep_ckpt.sh 排名用")
args = ap.parse_args()

RE_ROW = re.compile(r"^\s*(\S+?)\.json\s*\|\s*Atk\s+P:([\d.]+)\s+R:([\d.]+)\s+F1:([\d.]+)")
SUBSET = [x.strip() for x in args.campaigns.split(",") if x.strip()]

with open(args.expected, encoding="utf-8") as fp:
    EXP = json.load(fp)
tol = args.tol if args.tol is not None else EXP.get("_tolerance_pp", 0.5)
warn_tol = args.warn_tol if args.warn_tol is not None else EXP.get("_warn_tolerance_pp", 2.0)
warn_tol = max(warn_tol, tol)


def verdict(diff):
    """OK / WARN / BETTER / FAIL。

    P、R、F1 都是越高越好,所以「實測比論文高」不是復現失敗 —— 標 BETTER。
    只有實測**變差**且超出容差才算 FAIL。
    """
    a = abs(diff)
    if a <= tol:
        return "OK"
    if a <= warn_tol:
        return "WARN"
    return "BETTER" if (args.allow_better and diff > 0) else "FAIL"


spec = EXP.get("saga", {}).get(args.key)
if spec is None:
    raise SystemExit(f"expected_results.json 的 saga 底下沒有鍵「{args.key}」")

if not os.path.exists(args.log):
    print(f"[FAIL] 找不到 log:{args.log}")
    raise SystemExit(1)

# log 裡可能有多組 O-bias 的逐檔明細,只取最後一組(= 最佳 O-bias 的那組)
rows = {}
for ln in open(args.log, encoding="utf-8", errors="ignore"):
    m = RE_ROW.match(ln)
    if m:
        rows[m.group(1)] = (float(m.group(2)) * 100, float(m.group(3)) * 100, float(m.group(4)) * 100)

print("=" * 76)
print(f"{spec['label']}   ({spec['table']})")
print(f"log = {args.log}   OK ≤ ±{tol}pp,WARN ≤ ±{warn_tol}pp,再大才 FAIL")
print("=" * 76)

if not rows:
    print("[FAIL] log 裡找不到逐 campaign 明細(『Cx.json | Atk P:… R:… F1:…』)")
    raise SystemExit(1)

missing = [c for c in SUBSET if c not in rows]
if missing:
    print(f"[FAIL] log 缺少 campaign:{', '.join(missing)}")
    raise SystemExit(1)

fails, warns = [], []

# ---- 逐 campaign F1 ----
exp_c = spec.get("per_campaign_f1", {})
if exp_c:
    print(f"\n逐 campaign F1(%)")
    print(f"  {'campaign':<10} {'實測':>8} {'期望':>8} {'差':>8}")
    for c in SUBSET:
        got = rows[c][2]
        want = exp_c.get(c)
        if want is None:
            continue
        d = got - want
        v = verdict(d)
        print(f"  {c:<10} {got:>8.2f} {want:>8.2f} {d:>+8.2f}  {v}")
        item = f"{c} F1 {got:.2f} vs {want:.2f} ({d:+.2f}pp)"
        # --allow_better 時,判定以「論文表格填的那個平均值」為準;
        # 個別 campaign 的升降只當資訊,不擋通過(平均好了就是好了)
        if args.allow_better:
            warns.append(item) if v != "OK" else None
        else:
            (fails if v == "FAIL" else warns if v in ("WARN", "BETTER") else []).append(item)

# ---- 5-campaign 平均 ----
arr = np.array([rows[c] for c in SUBSET])
got_avg = {"P": arr[:, 0].mean(), "R": arr[:, 1].mean(), "F1": arr[:, 2].mean()}
print(f"\n{len(SUBSET)}-campaign 平均(%)")
print(f"  {'指標':<10} {'實測':>8} {'期望':>8} {'差':>8}")
for k in ("P", "R", "F1"):
    want = spec["avg"][k]
    d = got_avg[k] - want
    v = verdict(d)
    print(f"  {k:<10} {got_avg[k]:>8.2f} {want:>8.2f} {d:>+8.2f}  {v}")
    item = f"AVG {k} {got_avg[k]:.2f} vs {want:.2f} ({d:+.2f}pp)"
    (fails if v == "FAIL" else warns if v in ("WARN", "BETTER") else []).append(item)

if args.brief:
    alld = []
    if exp_c:
        alld += [abs(rows[c][2] - exp_c[c]) for c in SUBSET if c in exp_c]
    alld += [abs(got_avg[k] - spec["avg"][k]) for k in ("P", "R", "F1")]
    print(f"RESULT\t{args.key}\t{os.path.basename(args.log)}\tf1={got_avg['F1']:.2f}"
          f"\texp={spec['avg']['F1']:.2f}\tdmax={max(alld):.2f}"
          f"\t{'FAIL' if fails else ('WARN' if warns else 'OK')}")

print("=" * 76)
if fails:
    print(f"[FAIL] {len(fails)} 項超出 ±{warn_tol}pp:")
    for f in fails:
        print("   -", f)
    if warns:
        print(f"   (另有 {len(warns)} 項在 WARN 範圍)")
    raise SystemExit(1)
if warns:
    # exit 2 = 對得上但有小差異,test_reproduce.sh 會標成 PASS*
    print(f"[PASS*] 通過,{len(warns)} 項有差異(WARN=小幅、BETTER=實測較好):")
    for w in warns:
        print("   -", w)
    raise SystemExit(2)
print("[PASS] 全部與論文數字一致")

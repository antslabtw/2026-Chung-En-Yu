# -*- coding: utf-8 -*-
"""
infer_saga.py — 原始 (非 LLM) 級聯推論：OCSVM 異常 gate → Transformer-CRF TTP。

搭配舊的 inline Transformer_CRF checkpoint (如 Trans_CRF0705/.../epoch_9_AtkF1_0.9778)。
event 級 528 結構化，無 Multi-chunk、無 LLM embedding。
(LLM / Multi-chunk / hop 版本在 infer_saga_llm.py)
"""
import os
import math
import json
import glob
import pickle
import numpy as np
import torch
import torch.nn as nn
from torchcrf import CRF
from sklearn.metrics import precision_recall_fscore_support

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---- config ----
NODE_EMB_SIZE = 256
EDGE_EMB_SIZE = 16
WINDOW_SIZE = 256
EVENT_DIM = NODE_EMB_SIZE * 2 + EDGE_EMB_SIZE   # 528
TYPE2ATTR = {"Process": "Cmdline", "File": "Name", "Registry": "Key", "Network": "Dstaddress"}

TTP_CKPT = "./Trans_CRF0705/save_model/epoch_9_AtkF1_0.9778"   # 舊的 inline Transformer-CRF 權重
OCSVM_GLOB = "./model/OCSVM_finetune/event_*.pkl"              # event 級 OCSVM (None→自動抓最新)
OCSVM_PATH = None
GATE_THRESHOLD_SHIFT = 0.0                                     # 負值 → gate 更高 recall
SAGA_DIR = "./SAGA_C1-C8"
EMB_DIR = "./SecureBERT2.0-SAGA"                               # campaign node/edge emb

import argparse
_ap = argparse.ArgumentParser()
_ap.add_argument("--ckpt", default=TTP_CKPT, help="inline Transformer-CRF 權重(state_dict)")
_ap.add_argument("--ocsvm", default=None, help="指定 OCSVM .pkl(預設自動抓最新)")
_ap.add_argument("--o_bias_sweep", default="0,1,2,3,4,6,8", help="逗號分隔 O-bias 掃描;空=只用 0")
_ap.add_argument("--gate_shift", type=float, default=0.0, help="OCSVM gate 門檻位移,負=更高 recall")
_ap.add_argument("--saga_dir", default=SAGA_DIR)
_args = _ap.parse_args()
TTP_CKPT = _args.ckpt
OCSVM_PATH = _args.ocsvm
GATE_THRESHOLD_SHIFT = _args.gate_shift
SAGA_DIR = _args.saga_dir

# ---- loads ----
with open("./relations.txt") as fp:
    relations = {r.strip() for r in fp.readlines()}
with open("./index2label_0201.pkl", "rb") as fp:
    index2label = pickle.load(fp)
O_IDX = next((i for i, l in index2label.items() if str(l).strip() == "O"), None)   # O-bias 用
with open(os.path.join(EMB_DIR, "nodes/vocab2idx.pkl"), "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(os.path.join(EMB_DIR, "edges/vocab2idx.pkl"), "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(os.path.join(EMB_DIR, "nodes_ent2emb_256.pkl"), "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(os.path.join(EMB_DIR, "edges_ent2emb_16.pkl"), "rb") as fp:
    edge_ent2emb = pickle.load(fp)


def normalize_label(label):
    s = str(label).strip() if label is not None else ""
    if not s or s.upper() in ("BENIGN", "NORMAL", "NONE", "NULL", "O"):
        return "O"
    if s.startswith("T"):                       # technique 粒度: T1547.001_hash_B → T1547
        return s.split("_")[0].split(".")[0]
    return s


def safe_get_node_emb(attr):
    if attr in node_ent2idx:
        idx = node_ent2idx[attr]
        if idx < len(node_ent2emb):
            emb = torch.tensor(node_ent2emb[idx], dtype=torch.float32)
            return emb[:NODE_EMB_SIZE] if emb.shape[0] > NODE_EMB_SIZE else emb
    return torch.zeros(NODE_EMB_SIZE)


def safe_get_edge_emb(rel):
    if rel in edge_ent2idx:
        idx = edge_ent2idx[rel]
        if idx < len(edge_ent2emb):
            emb = torch.tensor(edge_ent2emb[idx], dtype=torch.float32)
            return emb[:EDGE_EMB_SIZE] if emb.shape[0] > EDGE_EMB_SIZE else emb
    return torch.zeros(EDGE_EMB_SIZE)


# ---- model (inline，配舊 checkpoint) ----
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=1000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1), :]


class Transformer_CRF(nn.Module):
    def __init__(self, embedding_dim, output_size, layers=2, nhead=8, dropout=0.1):
        super().__init__()
        self.d_model = 512
        self.input_proj = nn.Linear(embedding_dim, self.d_model)
        self.pos_encoder = PositionalEncoding(self.d_model)
        encoder_layers = nn.TransformerEncoderLayer(
            d_model=self.d_model, nhead=nhead, dim_feedforward=self.d_model * 2,
            dropout=dropout, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers=layers)
        self.dropout = nn.Dropout(0.3)
        self.hidden2tag = nn.Linear(self.d_model, output_size)
        self.crf = CRF(num_tags=output_size, batch_first=True)

    def _get_features(self, x, mask_tensor=None):
        x = self.pos_encoder(self.input_proj(x))
        key_pad = ~mask_tensor if mask_tensor is not None else None
        out = self.transformer_encoder(x, src_key_padding_mask=key_pad)
        return self.hidden2tag(self.dropout(out))

    def forward(self, sentence_tensor, mask_tensor=None):
        feats = self._get_features(sentence_tensor, mask_tensor)
        return self.crf.decode(emissions=feats, mask=mask_tensor)

    def emissions(self, sentence_tensor, mask_tensor=None):
        return self._get_features(sentence_tensor, mask_tensor)

    def decode(self, emissions, mask_tensor=None, o_bias=0.0):
        if o_bias and O_IDX is not None:
            emissions = emissions.clone()
            emissions[..., O_IDX] = emissions[..., O_IDX] + o_bias   # 加大 O 分數 → 更保守
        return self.crf.decode(emissions=emissions, mask=mask_tensor)


# ---- OCSVM gate ----
def _resolve_ocsvm_path():
    if OCSVM_PATH:
        return OCSVM_PATH
    cands = sorted(glob.glob(OCSVM_GLOB), key=os.path.getmtime)
    if not cands:
        raise FileNotFoundError(f"找不到 event 級 OCSVM ({OCSVM_GLOB})。先跑 "
                                f"OCSVM_GRANULARITY=event python train_ocsvm_finetune.py")
    return cands[-1]


_ocsvm_path = _resolve_ocsvm_path()
print(f"Loading OCSVM gate: {_ocsvm_path}")
with open(_ocsvm_path, "rb") as fp:
    ocsvm_bundle = pickle.load(fp)
if isinstance(ocsvm_bundle, dict) and ocsvm_bundle.get("granularity") == "process":
    raise ValueError("載到 process 級 OCSVM，但 infer 是 event 級。用 event 級模型。")


def apply_ocsvm(bundle, X):
    """回傳每列 +1(正常)/-1(攻擊)。相容 bundle-dict 與 舊裸 estimator。"""
    if not isinstance(bundle, dict):
        return bundle.predict(X)
    z = bundle["scaler"].transform(X)
    fm = bundle.get("feature_map")
    if fm is not None:
        z = fm.transform(z)
    a = -bundle["estimator"].decision_function(z)
    thr = bundle["attack_score_threshold"] + GATE_THRESHOLD_SHIFT
    return np.where(a >= thr, -1, 1)


# ---- TTP model load ----
print("Loading Transformer-CRF Model...")
model = Transformer_CRF(EVENT_DIM, len(index2label)).to(device)
_ck = torch.load(TTP_CKPT, map_location=device, weights_only=False)
if isinstance(_ck, dict) and "model" in _ck and "crf.transitions" not in _ck:
    print("  (checkpoint 含 cfg,取 ['model'])")
    _ck = _ck["model"]
model.load_state_dict(_ck)
model.eval()


def pipeline_evaluate(events, biases):
    valid_embs, true_labels = [], []
    for e in events:
        rel = e["relation"]
        if rel not in relations:
            continue
        src_t = e["srcNode"]["Type"]
        src_attr = e["srcNode"][TYPE2ATTR[src_t]]
        dst_attr = e["dstNode"][TYPE2ATTR[e["dstNode"]["Type"]]] if e["dstNode"] else src_attr
        emb = torch.cat((safe_get_node_emb(src_attr), safe_get_edge_emb(rel), safe_get_node_emb(dst_attr)), 0)
        if emb.shape[0] == EVENT_DIM:
            valid_embs.append(emb)
            true_labels.append(e.get("label", "O"))
    if not valid_embs:
        return {b: [] for b in biases}, []

    # Stage-1 OCSVM
    ocsvm_pred = apply_ocsvm(ocsvm_bundle, torch.stack(valid_embs).cpu().numpy())
    if (ocsvm_pred == 1).all():
        return {b: ["O"] * len(valid_embs) for b in biases}, true_labels

    # Stage-2 TTP (逐 window);同一份 emission 對每個 O-bias 各解碼一次(OCSVM 判正常的位置蓋成 O)
    preds_by = {b: [] for b in biases}
    all_true = []
    for i in range(0, len(valid_embs), WINDOW_SIZE):
        chunk = valid_embs[i:i+WINDOW_SIZE]
        chunk_true = true_labels[i:i+WINDOW_SIZE]
        chunk_oc = ocsvm_pred[i:i+WINDOW_SIZE]
        seq = len(chunk)
        if seq < WINDOW_SIZE:
            pad = WINDOW_SIZE - seq
            chunk = chunk + [torch.zeros(EVENT_DIM)] * pad
            mask = [1] * seq + [0] * pad
        else:
            mask = [1] * WINDOW_SIZE
        feats = torch.stack(chunk).unsqueeze(0).to(device)
        m = torch.tensor(mask).unsqueeze(0).bool().to(device)
        with torch.no_grad():
            e_emis = model.emissions(feats, m)
        for b in biases:
            out = model.decode(e_emis, m, o_bias=b)
            for j, idx in enumerate(out[0][:seq]):
                preds_by[b].append("O" if chunk_oc[j] == 1 else index2label.get(int(idx), "O"))
        all_true.extend(chunk_true)
    return preds_by, all_true


def main():
    json_paths = glob.glob(os.path.join(SAGA_DIR, "*.json"))
    if not json_paths:
        print(f"[錯誤] {SAGA_DIR} 沒有 json"); return
    biases = [float(x) for x in _args.o_bias_sweep.split(",") if x.strip()] if _args.o_bias_sweep.strip() else [0.0]
    print(f"\n>>> {len(json_paths)} 個檔案，級聯推論 (inline 非-LLM 版, ckpt={os.path.basename(TTP_CKPT)})  O-bias 掃描={biases}")

    summ_by = {b: [] for b in biases}
    for path in json_paths:
        fn = os.path.basename(path)
        events = []
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        preds_by, trues = pipeline_evaluate(events, biases)
        if not trues:
            print(f"{fn:<15} | 無有效事件"); continue
        ct = [normalize_label(t) for t in trues]
        atk = sorted(set(ct) - {"O"})              # SFM 口徑: 只 macro over GT-present technique
        for b in biases:
            cp = [normalize_label(p) for p in preds_by[b]]
            if atk:
                p, r, f, _ = precision_recall_fscore_support(ct, cp, labels=atk, average="macro", zero_division=0)
            else:
                p = r = f = 0.0
            summ_by[b].append({"file": fn, "p": p, "r": r, "f": f})

    print("-" * 90)
    print(f"{'O-bias':>7} | {'AVG P':>7} {'AVG R':>7} {'AVG F1':>7}")
    best = None
    for b in biases:
        s = summ_by[b]
        if not s:
            continue
        ap_ = np.mean([x["p"] for x in s]); ar_ = np.mean([x["r"] for x in s]); af_ = np.mean([x["f"] for x in s])
        if best is None or af_ > best[1]:
            best = (b, af_, ap_, ar_)
        print(f"{b:>7.1f} | {ap_:>7.4f} {ar_:>7.4f} {af_:>7.4f}")
    print("-" * 90)
    if best:
        print(f">>> 最佳 O-bias={best[0]}  AVG token-F1={best[1]:.4f}  (P={best[2]:.4f} R={best[3]:.4f})  對照 SFM = 0.6864")
        print(f"--- 最佳 O-bias={best[0]} 逐檔 ---")
        for x in summ_by[best[0]]:
            print(f"{x['file']:<15} | Atk P:{x['p']:.4f} R:{x['r']:.4f} F1:{x['f']:.4f}")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""make_dataset4SFM.py — 把 KELLECT4APT 原始事件整理成「SFM BiGRU-CRF」能直接吃的資料集。

跟原始 SFM 前處理(make_dataset)一致的輸出格式:每個樣本 dict 都有
  triplets_emb [L,528] / label_idx [L] / mask [L] / process,
差別只在:
  1) 資料來源改成 KELLECT4APT(資料夾名=TTP;huya*→O),用 kellect_event 抽 (src,edge,dst)。
  2) embedding 改用 **ehsanaghaei/SecureBERT**(vocab 級 mean-pool 768 → PCA node256/edge16),
     event = node256 ⊕ edge16 ⊕ node256 = 528 → SFM 的 EMBEDDING_SIZE 不用改。
  3) 切分改成「每個 TTP 留 1 個樣本做 inference(=test,純;不進 train)、train≥1、valid≥1」;
     樣本 <2 的 TTP 丟棄(無法同時滿足 holdout + train≥1),與 tranK 慣例一致。

用法:
    python make_dataset4SFM.py                        # 預設路徑/模型
    python make_dataset4SFM.py --data_glob "./KELLECT4APT/public_data/**/*.json" \
        --model ehsanaghaei/SecureBERT --out_dir ./k4apt_sfm

輸出(./k4apt_sfm/):
    train_data.pkl / valid_data.pkl / test_data.pkl   # list[dict],直接餵 SFM DataLoader
    label2index.pkl / index2label.pkl                 # KELLECT 標籤表(含 O)
    node_ent2idx.pkl / edge_ent2idx.pkl               # vocab
    nodes_ent2emb_256.pkl / edges_ent2emb_16.pkl      # PCA 後 embedding(可給 OCSVM 重用)
    infer_holdout_files.txt / meta.json               # holdout 清單 + 統計(含 EMBEDDING_SIZE)

接到 SFM 訓練碼:把原本 make_dataset / 切分那段換成
    import pickle
    train_data = pickle.load(open("./k4apt_sfm/train_data.pkl","rb"))
    valid_data = pickle.load(open("./k4apt_sfm/valid_data.pkl","rb"))
    test_data  = pickle.load(open("./k4apt_sfm/test_data.pkl","rb"))
    label2index = pickle.load(open("./k4apt_sfm/label2index.pkl","rb"))
    index2label = pickle.load(open("./k4apt_sfm/index2label.pkl","rb"))
    EMBEDDING_SIZE = 528   # 見 meta.json
其餘(BiGRU_CRF / 訓練迴圈 / classification_report)原封不動。
"""
import os
import json
import random
import pickle
import logging
import argparse
from glob import glob
from collections import defaultdict

import numpy as np
from tqdm import tqdm

import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.decomposition import PCA

# 必須在 import kellect_event 之前設定:保留 huya* 事件(不過濾),之後才能把它們標成 O。
# (kellect_event 在 import 當下就讀這個環境變數決定要不要過濾良性背景)
os.environ.setdefault("KELLECT_KEEP_BENIGN", "1")
from kellect_event import (iter_events, event_to_triple, event_ts,
                           is_benign_proc)

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

# 良性/正常資料夾名 → 統一成 O(與 tranK 一致)
BENIGN_DIR_NAMES = {"O", "benign", "BENIGN", "normal", "NORMAL", "none", "NONE"}


# ----------------------------------------------------------------------------
# 標籤:資料夾名 = TTP;benign 資料夾 → O
# ----------------------------------------------------------------------------
def label_of(json_path):
    name = os.path.basename(os.path.dirname(json_path))
    return "O" if name in BENIGN_DIR_NAMES else name


def scan_dataset(data_glob):
    paths = glob(data_glob, recursive=True)
    if not paths:
        raise FileNotFoundError(
            f"data_glob 沒比對到檔案:\n  {data_glob}\ncwd={os.getcwd()}\n"
            f"確認資料在 ./KELLECT4APT/public_data,或用 --data_glob '/abs/**/*.json'(記得加 **)。")
    by_class = defaultdict(list)
    for p in paths:
        by_class[label_of(p)].append(p)
    logging.info(f"matched {len(paths)} json;類別(含O)={len(by_class)}")
    return by_class


# ----------------------------------------------------------------------------
# SecureBERT (ehsanaghaei/SecureBERT) vocab 級 embedding + PCA
# ----------------------------------------------------------------------------
def collect_vocab(by_class):
    nodes, edges = set(), set()
    n_ev = n_tri = 0
    for paths in by_class.values():
        for p in paths:
            for e in iter_events(p):
                n_ev += 1
                tri = event_to_triple(e)
                if tri is None:
                    continue
                n_tri += 1
                s, ed, d = tri
                nodes.add(s); nodes.add(d); edges.add(ed)
    if not nodes or not edges:
        raise RuntimeError("vocab 空的:event_to_triple 全回 None。檢查資料 schema。")
    logging.info(f"events={n_ev} triples(可用)={n_tri} Nodes={len(nodes)} Edges={len(edges)}")
    return sorted(nodes), sorted(edges)


@torch.no_grad()
def embed_texts(texts, tokenizer, model, device, batch_size, max_length):
    """mean-pooled last_hidden_state → (N, 768)。"""
    out = []
    for i in tqdm(range(0, len(texts), batch_size), desc="SecureBERT embed"):
        batch = texts[i:i + batch_size]
        enc = tokenizer(batch, padding=True, truncation=True,
                        max_length=max_length, return_tensors="pt")
        ids = enc["input_ids"].to(device)
        att = enc["attention_mask"].to(device)
        hs = model(input_ids=ids, attention_mask=att).last_hidden_state
        m = att.unsqueeze(-1).float()
        avg = (hs * m).sum(dim=1) / m.sum(dim=1).clamp(min=1e-9)
        out.append(avg.detach().cpu().numpy())
    return np.concatenate(out, axis=0).astype(np.float32)


def pca_to_dim(emb, target):
    """PCA 降到 target;元件不足時補零到 target,保證輸出維度 = target。"""
    n_comp = min(target, emb.shape[0], emb.shape[1])
    if n_comp < 1:
        return np.zeros((emb.shape[0], target), dtype=np.float32)
    reduced = PCA(n_components=n_comp).fit_transform(emb)
    if n_comp < target:
        logging.warning(f"[PCA] 元件不足 {n_comp}<{target} → 補零到 {target}")
        pad = np.zeros((reduced.shape[0], target - n_comp), dtype=reduced.dtype)
        reduced = np.concatenate([reduced, pad], axis=1)
    return reduced.astype(np.float32)


def load_embeddings(src_dir, node_dim, edge_dim):
    """重用已建好的 embedding(詞表只跟資料集有關,與 stride/切分無關)。
    → 跳過 SecureBERT 推論 + PCA,這兩步是 RAM 尖峰(會被 OOM killer 砍)的來源。"""
    def _p(n):
        return os.path.join(src_dir, n)
    for req in ("node_ent2idx.pkl", "edge_ent2idx.pkl", "meta.json",
                f"nodes_ent2emb_{node_dim}.pkl", f"edges_ent2emb_{edge_dim}.pkl"):
        if not os.path.exists(_p(req)):
            raise SystemExit(f"[--reuse_emb_dir] {src_dir} 缺 {req};"
                             f"該目錄要是先前用相同 --node_dim/--edge_dim 建好的資料夾")
    with open(_p("meta.json"), encoding="utf-8") as fp:
        m = json.load(fp)
    with open(_p("node_ent2idx.pkl"), "rb") as fp:
        node_ent2idx = pickle.load(fp)
    with open(_p("edge_ent2idx.pkl"), "rb") as fp:
        edge_ent2idx = pickle.load(fp)
    with open(_p(f"nodes_ent2emb_{node_dim}.pkl"), "rb") as fp:
        node_emb = pickle.load(fp)
    with open(_p(f"edges_ent2emb_{edge_dim}.pkl"), "rb") as fp:
        edge_emb = pickle.load(fp)
    node_pad = int(m.get("node_pad", len(node_ent2idx)))
    edge_pad = int(m.get("edge_pad", len(edge_ent2idx)))
    logging.info(f"[重用 embedding] {src_dir}  node={np.asarray(node_emb).shape} "
                 f"edge={np.asarray(edge_emb).shape}  node_pad={node_pad} edge_pad={edge_pad}")
    return node_ent2idx, edge_ent2idx, node_emb, edge_emb, node_pad, edge_pad


def build_embeddings(by_class, model_name, node_dim, edge_dim, batch_size, max_length):
    nodes, edges = collect_vocab(by_class)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"loading {model_name} on {device} ...")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name).to(device)
    model.eval()

    node_raw = embed_texts(nodes, tokenizer, model, device, batch_size, max_length)  # (Nn,768)
    edge_raw = embed_texts(edges, tokenizer, model, device, batch_size, max_length)  # (Ne,768)
    node_emb = pca_to_dim(node_raw, node_dim)   # (Nn, node_dim)
    edge_emb = pca_to_dim(edge_raw, edge_dim)   # (Ne, edge_dim)

    node_ent2idx = {v: i for i, v in enumerate(nodes)}
    edge_ent2idx = {v: i for i, v in enumerate(edges)}
    # 追加一列「pad/OOV = 全零」→ 訓練時 OOV/pad 的索引指向它,查表得零向量(跟 SFM 的 OOV→zeros 一致)
    node_pad, edge_pad = node_emb.shape[0], edge_emb.shape[0]
    node_emb = np.concatenate([node_emb, np.zeros((1, node_emb.shape[1]), np.float32)], axis=0)
    edge_emb = np.concatenate([edge_emb, np.zeros((1, edge_emb.shape[1]), np.float32)], axis=0)
    logging.info(f"node_emb={node_emb.shape} edge_emb={edge_emb.shape} (末列=pad/OOV)")
    return node_ent2idx, edge_ent2idx, node_emb, edge_emb, node_pad, edge_pad


# ----------------------------------------------------------------------------
# 一個 trace → 定長視窗(只存 src/rel/dst 索引 + 逐事件標籤;embedding 訓練時再查表組)
#   → 資料集比 baked 528 小約 88 倍,避免 load 進 RAM 就 OOM。
# ----------------------------------------------------------------------------
def make_windows(json_path, label_idx, ctx):
    node_ent2idx = ctx["node_ent2idx"]; edge_ent2idx = ctx["edge_ent2idx"]
    NODE_PAD, EDGE_PAD = ctx["node_pad"], ctx["edge_pad"]
    W, S, O_IDX = ctx["window"], ctx["stride"], ctx["O_idx"]

    events = iter_events(json_path)
    events.sort(key=event_ts)
    seq_src, seq_rel, seq_dst, seq_lab = [], [], [], []
    for e in events:
        tri = event_to_triple(e)
        if tri is None:
            continue
        src, edge, dst = tri
        seq_src.append(node_ent2idx.get(src, NODE_PAD))     # OOV → pad 列(零向量)
        seq_rel.append(edge_ent2idx.get(edge, EDGE_PAD))
        seq_dst.append(node_ent2idx.get(dst, NODE_PAD))
        seq_lab.append(O_IDX if is_benign_proc(src) else label_idx)   # huya* → O
    n = len(seq_src)
    if n == 0:
        return []
    mask = [1] * n
    if n % W != 0:                                       # 對齊到可被 stride 切齊的長度
        pad = (W - n) if n < W else (((n - W) // S + 1) * S + W - n)
        seq_src += [NODE_PAD] * pad; seq_rel += [EDGE_PAD] * pad; seq_dst += [NODE_PAD] * pad
        seq_lab += [O_IDX] * pad; mask += [0] * pad
    src_t = torch.tensor(seq_src, dtype=torch.long)
    rel_t = torch.tensor(seq_rel, dtype=torch.long)
    dst_t = torch.tensor(seq_dst, dtype=torch.long)
    lab_t = torch.tensor(seq_lab, dtype=torch.long)
    msk_t = torch.tensor(mask, dtype=torch.bool)
    starts = list(range(0, len(seq_src) - W + 1, S))
    MAXW = ctx.get("max_windows", 0)
    if MAXW and len(starts) > MAXW:                      # 視窗太多 → 沿整條 trace 均勻抽 MAXW 個
        sel = np.linspace(0, len(starts) - 1, MAXW).round().astype(int)
        starts = [starts[i] for i in sorted(set(sel.tolist()))]
    out = []
    for i in starts:
        out.append({
            "src": src_t[i:i + W], "rel": rel_t[i:i + W], "dst": dst_t[i:i + W],
            "label_idx": lab_t[i:i + W], "mask": msk_t[i:i + W],
            "process": json_path,
        })
    return out


# ----------------------------------------------------------------------------
# 切分:每 TTP holdout 1 → test(純);valid≥1;train≥1;樣本<2 丟棄
# ----------------------------------------------------------------------------
def split_files(by_class, seed, valid_from_train=False):
    """每個 TTP 留 1 個樣本當 holdout(=inference/test,純)。

    valid_from_train=False(預設,SFM 慣例):再撥 1 個 trace 當 valid。
    valid_from_train=True :holdout 以外**全部進 train**,valid 之後從 train 視窗切。
        → 每 TTP 只有 2~3 個 trace 時,可把訓練資料多出 33~50%,對 transformer 差很多。
    """
    rng = random.Random(seed)
    train_f, valid_f, test_f, dropped = [], [], [], []
    per_class = []
    for lab in sorted(by_class.keys()):
        files = list(by_class[lab])
        rng.shuffle(files)
        if lab == "O":                                   # 良性:全進 train,不 holdout
            train_f += [(lab, p) for p in files]
            per_class.append({"label": lab, "total": len(files),
                              "train": len(files), "valid": 0, "test": 0})
            continue
        M = len(files)
        if M < 2:                                        # 無法同時 holdout + train≥1
            dropped.append((lab, M)); continue
        test_f.append((lab, files[0]))                   # holdout / inference,純
        if valid_from_train:                             # holdout 以外全給 train
            train_f += [(lab, p) for p in files[1:]]
            tr, va = M - 1, 0
        elif M >= 3:
            valid_f.append((lab, files[1]))
            train_f += [(lab, p) for p in files[2:]]
            tr, va = M - 2, 1
        else:                                            # M==2:valid 用 train 樣本(保持 holdout 純)
            train_f.append((lab, files[1]))
            valid_f.append((lab, files[1]))
            tr, va = 1, 1
        per_class.append({"label": lab, "total": M, "train": tr, "valid": va, "test": 1})
    return train_f, valid_f, test_f, dropped, per_class


def build_split(files, ctx, label2index, desc):
    data = []
    for lab, p in tqdm(files, desc=desc):
        data += make_windows(p, label2index[lab], ctx)
    return data


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_glob", default="./KELLECT4APT/public_data/**/*.json")
    ap.add_argument("--model", default="ehsanaghaei/SecureBERT")
    ap.add_argument("--out_dir", default="./k4apt_sfm")
    ap.add_argument("--node_dim", type=int, default=256)
    ap.add_argument("--edge_dim", type=int, default=16)
    ap.add_argument("--window", type=int, default=256)
    ap.add_argument("--stride", type=int, default=64)      # 跟 SFM 一致
    ap.add_argument("--max_windows_per_trace", type=int, default=60,
                    help="每條 trace 最多保留幾個視窗(沿整條均勻抽);避免巨大 trace 產生海量重疊視窗 OOM")
    ap.add_argument("--batch_size", type=int, default=128)
    ap.add_argument("--max_length", type=int, default=512)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--reuse_emb_dir", default=None,
                    help="重用已建好的 embedding 目錄(如 ./k4apt_sfm),跳過 SecureBERT+PCA。"
                         "只換 stride/切分時強烈建議用,可避免 RAM OOM(Killed)。")
    ap.add_argument("--valid_from_train_frac", type=float, default=0.0,
                    help=">0 時改用『transformer 友善』切分:每 TTP 除 holdout 外全部進 train,"
                         "再從 train 視窗隨機切這個比例當 valid(建議 0.1)。"
                         "每 TTP 樣本很少時可把訓練資料最大化。")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    by_class = scan_dataset(args.data_glob)

    # ---- 標籤表(強制含 O)----
    labels_sorted = sorted(by_class.keys())
    ordered = ["O"] + [l for l in labels_sorted if l != "O"]
    label2index = {l: i for i, l in enumerate(ordered)}
    index2label = {i: l for l, i in label2index.items()}
    O_IDX = label2index["O"]
    EMBEDDING_SIZE = 2 * args.node_dim + args.edge_dim
    logging.info(f"OUTPUT_SIZE(含O)={len(label2index)}  EMBEDDING_SIZE={EMBEDDING_SIZE}")

    # ---- embedding(ehsanaghaei/SecureBERT);--reuse_emb_dir 可跳過重算 ----
    if args.reuse_emb_dir:
        node_ent2idx, edge_ent2idx, node_emb, edge_emb, node_pad, edge_pad = load_embeddings(
            args.reuse_emb_dir, args.node_dim, args.edge_dim)
    else:
        node_ent2idx, edge_ent2idx, node_emb, edge_emb, node_pad, edge_pad = build_embeddings(
            by_class, args.model, args.node_dim, args.edge_dim, args.batch_size, args.max_length)

    ctx = {"node_ent2idx": node_ent2idx, "edge_ent2idx": edge_ent2idx,
           "node_pad": node_pad, "edge_pad": edge_pad,
           "node_dim": args.node_dim, "edge_dim": args.edge_dim,
           "window": args.window, "stride": args.stride, "O_idx": O_IDX,
           "max_windows": args.max_windows_per_trace}

    # ---- 切分 ----
    vft = args.valid_from_train_frac > 0.0
    train_f, valid_f, test_f, dropped, per_class = split_files(by_class, args.seed, valid_from_train=vft)
    if dropped:
        logging.warning(f"樣本<2 丟棄的 TTP:{dropped}")

    train_data = build_split(train_f, ctx, label2index, "build train")
    valid_data = build_split(valid_f, ctx, label2index, "build valid")
    test_data  = build_split(test_f,  ctx, label2index, "build test")

    if vft:
        # holdout(test)完全不動;valid 從 train 視窗切出來
        rng = random.Random(args.seed)
        rng.shuffle(train_data)
        n_val = max(1, int(len(train_data) * args.valid_from_train_frac))
        valid_data, train_data = train_data[:n_val], train_data[n_val:]
        logging.info(f"[transformer 友善切分] holdout 以外全部進 train;"
                     f"再從 train 視窗切 {args.valid_from_train_frac:.0%} 當 valid")
        logging.info("  ⚠ 視窗有重疊(stride<window),valid 與 train 可能共享事件 → "
                     "valid 分數會偏樂觀,僅用於選 epoch/O-bias;test(holdout)仍是純的。")
    logging.info(f"視窗數 train={len(train_data)} valid={len(valid_data)} test={len(test_data)}")

    # ---- 存檔 ----
    def dump(obj, name):
        with open(os.path.join(args.out_dir, name), "wb") as fp:
            pickle.dump(obj, fp)
    dump(train_data, "train_data.pkl"); dump(valid_data, "valid_data.pkl"); dump(test_data, "test_data.pkl")
    dump(label2index, "label2index.pkl"); dump(index2label, "index2label.pkl")
    dump(node_ent2idx, "node_ent2idx.pkl"); dump(edge_ent2idx, "edge_ent2idx.pkl")
    dump(node_emb, f"nodes_ent2emb_{args.node_dim}.pkl"); dump(edge_emb, f"edges_ent2emb_{args.edge_dim}.pkl")

    with open(os.path.join(args.out_dir, "infer_holdout_files.txt"), "w", encoding="utf-8") as fp:
        for lab, p in test_f:
            fp.write(f"{lab}\t{p}\n")

    meta = {"format": "index_v2",   # ← 標記新格式(存索引);run_sfm_k4apt.sh 據此判斷要不要重建
            "EMBEDDING_SIZE": EMBEDDING_SIZE, "node_dim": args.node_dim, "edge_dim": args.edge_dim,
            "OUTPUT_SIZE": len(label2index), "O_idx": O_IDX, "model": args.model,
            "node_pad": node_pad, "edge_pad": edge_pad,   # emb 表末列(零向量)索引
            "max_windows_per_trace": args.max_windows_per_trace,
            "window": args.window, "stride": args.stride, "seed": args.seed,
            "split_mode": ("holdout1_valid_from_train" if vft else "holdout1_valid_trace"),
            "valid_from_train_frac": args.valid_from_train_frac,
            "n_train_windows": len(train_data), "n_valid_windows": len(valid_data),
            "n_test_windows": len(test_data), "dropped_ttp": dropped, "per_class": per_class}
    with open(os.path.join(args.out_dir, "meta.json"), "w", encoding="utf-8") as fp:
        json.dump(meta, fp, ensure_ascii=False, indent=2)

    logging.info("=" * 60)
    logging.info(f"完成 → {args.out_dir}")
    logging.info(f"  用到的 TTP(含O)={len(per_class)}  丟棄(樣本<2)={len(dropped)}")
    logging.info(f"  接 SFM:load *_data.pkl + label2index.pkl,並設 EMBEDDING_SIZE={EMBEDDING_SIZE}")
    logging.info("=" * 60)


if __name__ == "__main__":
    main()

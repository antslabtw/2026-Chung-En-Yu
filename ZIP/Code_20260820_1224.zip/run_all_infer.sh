#!/usr/bin/env bash
# ============================================================================
# run_all_infer.sh — 一次跑完所有推論:SAGA t1~t5 + KELLECT4APT,最後印一張總表。
#
#   只推論,不訓練。缺 checkpoint 的那一列會跳過並印出當初訓練的指令。
#
#   SAGA(5 個 campaign 平均 = C1,C3,C5,C6,C7)
#     t1  Transformer (w/o LLM, Multichunk)  infer_saga.py       --ocsvm
#     t2  Transformer (Temporal)             infer_t2.py         --no_gate
#     t3  Transformer (hop)                  infer_saga_llm.py   --ocsvm_glob
#     t4  Transformer (hop + Qwen)           infer_saga_llm.py   --ocsvm_glob
#     t5  Transformer (hop*3)                infer_t5.py         --no_gate
#
#   KELLECT4APT  轉呼叫 run_k4apt_infer.sh(A 線 trace 級 / B 線 event 級)
#
# 用法:
#   bash run_all_infer.sh                 # 全部
#   bash run_all_infer.sh saga            # 只跑 SAGA t1~t5
#   bash run_all_infer.sh k4apt           # 只跑 KELLECT4APT
#   ONLY=t1,t3 bash run_all_infer.sh      # 只跑指定幾列
#   FORCE=1 bash run_all_infer.sh         # 已有 log 也重跑
#   TABLE=1 bash run_all_infer.sh         # 不推論,只用既有 log 印總表
#   BIAS=0,8,32,128 bash run_all_infer.sh # 換 O-bias 掃描範圍
#   EXTRA=1 bash run_all_infer.sh         # 連消融/單一LLM/降維/innov 一起跑
# ============================================================================
cd "$(dirname "${BASH_SOURCE[0]:-$0}")" || exit 1
sed -i 's/\r$//' *.sh *.py 2>/dev/null

WHAT="${1:-all}"
CAMP="${CAMP:-C1,C3,C5,C6,C7}"
OCSVM="${OCSVM:-model/OCSVM_finetune/event_nystroem_sgd_nu0.001_g8.0_P0.842_R0.959_F0.897.pkl}"
# t1/t3/t4 用原本的範圍(它們的最佳值就在裡面);t2/t5 會過度預測,需要更寬
BIAS_OLD="${BIAS_OLD:-0,1,2,3,4,6,8}"
BIAS="${BIAS:-0,2,4,8,16,24,32,48,64,96,128,192,256}"
ONLY="${ONLY:-}"
FORCE="${FORCE:-0}"
TABLE="${TABLE:-0}"
OUT="repro"; mkdir -p "$OUT"
[ -n "$GPU" ] && export CUDA_VISIBLE_DEVICES="$GPU"

want() { [ -z "$ONLY" ] || echo ",$ONLY," | grep -q ",$1,"; }

# key | 論文欄位 | checkpoint | 推論腳本 | 額外參數 | 訓練指令
ROWS=(
"t1_plain|Transformer (w/o LLM, Multichunk)|Trans_CRF0706/save_model/epoch_9_AtkF1_0.9787|infer_saga.py|--ocsvm OCSVM --o_bias_sweep BIAS_OLD|python train_ttp_conservative.py"
"t2_temporal|Transformer (Temporal)|AUTO_T2|infer_t2.py|--no_gate --o_bias_sweep BIAS|python train_t2.py --warm_start Trans_CRF0706/save_model/epoch_9_AtkF1_0.9787"
"t3_hop|Transformer (hop)|Trans_CRF0706/save_model/best_hop_llm.pt|infer_saga_llm.py|--ocsvm_glob OCSVM --o_bias_sweep BIAS_OLD|python train_ttp_llm.py --chunk_kind hop --use_llm 1"
"t4_hop_qwen|Transformer (hop + Qwen)|Trans_CRF0706/save_model/best_hop_llm_qwen.pt|infer_saga_llm.py|--ocsvm_glob OCSVM --o_bias_sweep BIAS_OLD|python train_ttp_llm.py --chunk_kind hop --use_llm 1 --llm_dir ./SecureBERT2.0-base-qwen --tag_suffix _qwen"
"t5_hop3|Transformer (hop*3)|AUTO_T5|infer_t5.py|--no_gate --o_bias_sweep BIAS|python train_t5.py --warm_start Trans_CRF0706/save_model/epoch_9_AtkF1_0.9787"
)

# ---- 其餘實驗(EXTRA=1 才跑;沒有對應的論文欄位,只印 log 末尾的分數)----
# 掃過所有 .sh 與它們呼叫的 .py 整理出來的「訓練 → checkpoint → 推論」對照。
EXTRA_ROWS=(
"multichunk|MultiChunk (scales 1,4,16)|AUTO_MC|infer_saga_mc.py|--ocsvm OCSVM --scales 1,4,16 --o_bias_sweep BIAS_OLD|bash run_multichunk.sh"
"hop_ablation|hop 消融 {1}/{1,2}/{1,2,3}|AUTO_HOPABL|infer_saga_llm.py|--ocsvm_glob OCSVM --o_bias_sweep BIAS_OLD|bash run_hop_ablation.sh"
"singlellm|單一 LLM|AUTO_SINGLELLM|infer_singlellm.py|--o_bias_sweep BIAS_OLD|bash run_singlellm.sh"
"llmonly|只用 LLM 敘述當特徵|AUTO_LLMONLY|infer_llmonly.py|--o_bias_sweep BIAS_OLD|bash run_llmonly.sh"
"innov|innov|AUTO_INNOV|infer_innov.py||bash run_innov.sh"
"sfm_saga|SFM 基線 (SAGA)|sfm_saga_out/best.pt|infer_sfm_saga.py||bash run_case_study_saga.sh"
)

pick() {   # 從目錄挑 AtkF1 最高的(訓練腳本只在 val 進步時存 → 最高的就是 best)
    ls -1 "$1"/epoch_*_AtkF1_* 2>/dev/null \
      | awk -F'AtkF1_' 'NF>1{print $2"\t"$0}' | sort -rn | head -1 | cut -f2-
}

CUR=""
cleanup() { [ -n "$CUR" ] && [ -f "$CUR" ] && { echo "  (捨棄未完成的 $CUR)"; rm -f "$CUR"; }; }
trap 'echo ""; echo "── 收到中斷 ──"; cleanup; table; exit 130' INT TERM

table() {
    echo ""
    echo "===================================================================="
    echo " SAGA 總表   5 campaign = $CAMP"
    echo "===================================================================="
    printf "  %-14s %9s %9s %9s  %-6s %s\n" "列" "實測F1" "論文" "差" "判定" "checkpoint"
    echo "  --------------------------------------------------------------------"
    local row k lab ck B f e
    for row in "${ROWS[@]}"; do
        IFS='|' read -r k lab ck _ _ _ <<< "$row"
        [ -f "$OUT/$k.log" ] || { printf "  %-14s %9s %9s %9s  %-6s %s\n" \
            "$k" "(未跑)" "-" "-" "-" "-"; continue; }
        B=$(python check_expected.py --log "$OUT/$k.log" --key "$k" --campaigns "$CAMP" \
            --brief 2>/dev/null | grep '^RESULT')
        f=$(echo "$B" | cut -f4 | cut -d= -f2); e=$(echo "$B" | cut -f5 | cut -d= -f2)
        printf "  %-14s %9s %9s %9s  %-6s %s\n" "$k" "${f:-?}" "${e:-?}" \
            "$(python -c "print(f'{$f-$e:+.2f}')" 2>/dev/null)" \
            "$(echo "$B" | cut -f7)" "$(basename "$(grep -m1 -oE 'ckpt=[^ ]+' "$OUT/$k.log" | cut -d= -f2)" 2>/dev/null)"
    done
    echo "  --------------------------------------------------------------------"
    echo "  逐 campaign 明細:python check_expected.py --log $OUT/<key>.log --key <key> --campaigns $CAMP"
    if [ -d "$OUT/k4apt" ] && ls "$OUT"/k4apt/*.log >/dev/null 2>&1; then
        echo ""
        python collect_k4apt.py --logs "$OUT/k4apt" 2>/dev/null
    fi
}

if [ "$TABLE" = "1" ]; then table; exit 0; fi

# ---------------- SAGA ----------------
if [ "$WHAT" = "all" ] || [ "$WHAT" = "saga" ]; then
    echo "===================================================================="
    echo " SAGA t1~t5"
    echo "===================================================================="
    for row in "${ROWS[@]}"; do
        IFS='|' read -r k lab ck script extra howto <<< "$row"
        want "$k" || continue
        case "$ck" in
            AUTO_T2)        ck=$(pick ./t2_out/save_model) ;;
            AUTO_T5)        ck=$(pick ./t5_out/save_model) ;;
            AUTO_MC)        ck=$(pick ./multichunk_*/save_model) ;;
            AUTO_HOPABL)    ck=$(pick ./hop_ablation) ;;
            AUTO_SINGLELLM) ck=$(pick ./Trans_CRF_singlellm/save_model) ;;
            AUTO_LLMONLY)   ck=$(pick ./llmonly_out/save_model) ;;
            AUTO_INNOV)     ck=$(pick ./innov_*/save_model) ;;
        esac
        echo ""
        echo "──────────────────────────────────────────────────────────────────"
        echo " $k — $lab"
        echo "──────────────────────────────────────────────────────────────────"
        if [ -z "$ck" ] || [ ! -f "$ck" ]; then
            echo "  [跳過] 沒有 checkpoint。訓練指令:"
            echo "         $howto"
            continue
        fi
        echo "  ckpt = $ck"
        [ "$FORCE" = "1" ] && rm -f "$OUT/$k.log"
        if [ -f "$OUT/$k.log" ]; then
            echo "  [沿用] $OUT/$k.log(FORCE=1 重跑)"
        else
            extra="${extra//OCSVM/$OCSVM}"
            extra="${extra//BIAS_OLD/$BIAS_OLD}"
            extra="${extra//BIAS/$BIAS}"
            echo "  推論中 $script $extra"
            CUR="$OUT/$k.log"
            # shellcheck disable=SC2086
            python -u "$script" --ckpt "$ck" $extra > "$OUT/$k.log" 2>&1
            rc=$?; CUR=""
            if [ "$rc" -ne 0 ]; then
                echo "  [失敗] $(tail -3 "$OUT/$k.log" | tr '\n' ' ' | cut -c1-130)"
                mv "$OUT/$k.log" "$OUT/$k.log.err"; continue
            fi
        fi
        python collect_results.py "$OUT/$k.log" --campaigns "$CAMP" 2>/dev/null | tail -9
    done
fi

# ---------------- 其餘實驗(EXTRA=1)----------------
if [ "${EXTRA:-0}" = "1" ] && { [ "$WHAT" = "all" ] || [ "$WHAT" = "saga" ]; }; then
    echo ""
    echo "===================================================================="
    echo " 其餘實驗(沒有對應的論文欄位,只印 log 末尾的分數)"
    echo "===================================================================="
    for row in "${EXTRA_ROWS[@]}"; do
        IFS='|' read -r k lab ck script extra howto <<< "$row"
        want "$k" || continue
        case "$ck" in
            AUTO_MC)        ck=$(pick ./multichunk_*/save_model) ;;
            AUTO_HOPABL)    ck=$(pick ./hop_ablation) ;;
            AUTO_SINGLELLM) ck=$(pick ./Trans_CRF_singlellm/save_model) ;;
            AUTO_LLMONLY)   ck=$(pick ./llmonly_out/save_model) ;;
            AUTO_INNOV)     ck=$(pick ./innov_*/save_model) ;;
        esac
        echo ""
        echo "── $k — $lab"
        if [ -z "$ck" ] || [ ! -f "$ck" ]; then
            echo "   [跳過] 沒有 checkpoint。產生方式:$howto"; continue
        fi
        echo "   ckpt = $ck"
        [ "$FORCE" = "1" ] && rm -f "$OUT/$k.log"
        if [ -f "$OUT/$k.log" ]; then
            echo "   [沿用] $OUT/$k.log"
        else
            extra="${extra//OCSVM/$OCSVM}"
            extra="${extra//BIAS_OLD/$BIAS_OLD}"
            extra="${extra//BIAS/$BIAS}"
            CUR="$OUT/$k.log"
            # shellcheck disable=SC2086
            python -u "$script" --ckpt "$ck" $extra > "$OUT/$k.log" 2>&1
            rc=$?; CUR=""
            if [ "$rc" -ne 0 ]; then
                echo "   [失敗] $(tail -3 "$OUT/$k.log" | tr '
' ' ' | cut -c1-120)"
                mv "$OUT/$k.log" "$OUT/$k.log.err"; continue
            fi
        fi
        grep -hE "^>>> 最佳|AVG token-F1|攻擊 macro" "$OUT/$k.log" | tail -2 | sed "s/^/   /"
    done
fi

# ---------------- KELLECT4APT ----------------
if [ "$WHAT" = "all" ] || [ "$WHAT" = "k4apt" ]; then
    echo ""
    echo "===================================================================="
    echo " KELLECT4APT"
    echo "===================================================================="
    if [ -f run_k4apt_infer.sh ]; then
        FORCE="$FORCE" bash run_k4apt_infer.sh
    else
        echo "  缺 run_k4apt_infer.sh"
    fi
fi

table

"""
MultiChunk — drop-in multi-scale chunk-context preprocessor.

放在 raw LLM embedding 進入主 model 之前,
讓每個 token 同時看到「自己 + 短/中/長三個尺度 chunk 摘要」。
對 TTP detection 特別有用,因為 TTP 判斷常常要不同尺度的線索:
  - scale  8 ≈ trigger phrase  ("powershell -enc")
  - scale 32 ≈ sentence        ("using scheduled task to ...")
  - scale 128 ≈ paragraph       (a sequence of related techniques)

整合方式 (3 種主模型都適用):

  # === TTPRelGraphTransformer / Conformer / GRU 都一樣 ===
  self.multi_chunk = MultiChunk(
      d_in=EMBEDDING_SIZE, d_out=EMBEDDING_SIZE,   # 純 preprocessor
      scales=(8, 32, 128), mode='conv', masked=True,
  )

  def encode(self, emb, mask):
      emb = self.multi_chunk(emb, mask)            # ← 加這一行
      # ... 後面所有東西不變 ...

也可以讓它同時取代 input projection (節省一層):

  self.multi_chunk = MultiChunk(
      d_in=EMBEDDING_SIZE, d_out=D_MODEL,          # 直接降到 d_model
      scales=(8, 32, 128), mode='conv', masked=True,
  )
  # 跳過原本的 NodeFeatureExtractor / input_proj
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class MultiChunk(nn.Module):
    """
    Args:
        d_in:    每個 token 的輸入維度 (raw LLM=768,PCA emb=256)
        d_out:   輸出維度,預設 = d_in (drop-in preprocessor)
        scales:  chunk 尺度,例如 (8, 32, 128) 覆蓋 phrase / sentence / paragraph
        mode:    'conv' = 可學 depthwise conv pooling (推薦,訓練穩)
                 'avg'  = 純 masked average pool (零參數,適合對照組)
        masked:  True 時 padding token 不污染 chunk 平均 (建議開)
        dropout: fusion MLP 的 dropout
        learnable_gate: True 則對每個尺度加 sigmoid 開關,模型可自行關閉
    """

    def __init__(
        self,
        d_in: int,
        d_out: int = None,
        scales=(8, 32, 128),
        mode: str = 'conv',
        masked: bool = True,
        dropout: float = 0.1,
        learnable_gate: bool = False,
    ):
        super().__init__()
        assert mode in ('conv', 'avg'), "mode must be 'conv' or 'avg'"
        if d_out is None:
            d_out = d_in

        self.d_in           = d_in
        self.d_out          = d_out
        self.scales         = tuple(scales)
        self.mode           = mode
        self.masked         = masked
        self.learnable_gate = learnable_gate
        self.n_streams      = 1 + len(scales)

        if mode == 'conv':
            # depthwise conv per scale:每個 channel 一個可學的 chunk filter。
            # 初始化為 uniform(1/s),起始等同 average pool,訓練穩定;
            # 訓練後可變成 attention-like 的位置加權。
            self.chunk_ops = nn.ModuleList([
                nn.Conv1d(d_in, d_in, kernel_size=s,
                          padding=s // 2, groups=d_in, bias=False)
                for s in scales
            ])
            for s, conv in zip(scales, self.chunk_ops):
                with torch.no_grad():
                    conv.weight.fill_(1.0 / s)

        if learnable_gate:
            self.scale_gate = nn.Parameter(torch.zeros(len(scales)))

        self.fuse = nn.Sequential(
            nn.Linear(d_in * self.n_streams, d_out * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_out * 2, d_out),
        )
        self.norm = nn.LayerNorm(d_out)

    # ---------- helpers ----------
    @staticmethod
    def _crop_to_len(x, L):
        """偶數 kernel 會輸出 L+1,裁回 L。"""
        if x.size(-1) > L:
            return x[..., :L]
        if x.size(-1) < L:
            return F.pad(x, (0, L - x.size(-1)))
        return x

    def _pool_one_scale(self, x_t, ones_t, scale, scale_idx):
        """
        x_t:    [B, D, L]   features (padding 已預先歸零)
        ones_t: [B, 1, L]   valid mask 當分母,None 表示不做 masked-norm
        Returns [B, D, L]
        """
        L = x_t.size(-1)
        if self.mode == 'avg':
            num = F.avg_pool1d(x_t, kernel_size=scale, stride=1, padding=scale // 2)
        else:
            num = self.chunk_ops[scale_idx](x_t)
        num = self._crop_to_len(num, L)

        if ones_t is not None:
            denom = F.avg_pool1d(ones_t, kernel_size=scale,
                                 stride=1, padding=scale // 2)
            denom = self._crop_to_len(denom, L).clamp(min=1.0 / scale)
            # avg_pool1d 預設除以 kernel_size,我們要除以有效 token 數
            # avg = sum/kernel → 真 masked-mean = avg * kernel / valid_count
            num = num / denom

        return num

    # ---------- main forward ----------
    def forward(self, x, mask=None):
        """
        x:    [B, L, D_in]  raw embeddings
        mask: [B, L] bool,True = valid token (None = 不做 masking)
        return [B, L, D_out] 富含多尺度 chunk context 的 embeddings
        """
        B, L, D = x.shape

        if self.masked and mask is not None:
            ones   = mask.float()
            x_in   = x * ones.unsqueeze(-1)              # padding → 0,不污染 conv
            ones_t = ones.unsqueeze(1)                   # [B, 1, L]
        else:
            x_in   = x
            ones_t = None

        x_t = x_in.transpose(1, 2)                       # [B, D, L]
        streams = [x]                                    # stream 0 = 原始 token,保留全部訊號

        for idx, s in enumerate(self.scales):
            pooled = self._pool_one_scale(x_t, ones_t, s, idx)   # [B, D, L]
            pooled = pooled.transpose(1, 2)                      # [B, L, D]
            if self.learnable_gate:
                pooled = pooled * torch.sigmoid(self.scale_gate[idx])
            streams.append(pooled)

        concat = torch.cat(streams, dim=-1)              # [B, L, D * (1 + S)]
        out    = self.fuse(concat)                       # [B, L, D_out]

        if mask is not None:
            out = out * mask.float().unsqueeze(-1)       # padding 位置歸零

        return self.norm(out)


# ===========================================================================
# Smoke test:確認 forward 跑得起來、輸出形狀對
# ===========================================================================
if __name__ == "__main__":
    torch.manual_seed(0)

    B, L, D = 4, 256, 768
    x = torch.randn(B, L, D)
    mask = torch.ones(B, L, dtype=torch.bool)
    mask[0, 200:] = False        # 第一個樣本最後 56 token 是 padding
    mask[1, 128:] = False

    for mode in ('conv', 'avg'):
        mc = MultiChunk(
            d_in=D, d_out=D, scales=(8, 32, 128),
            mode=mode, masked=True, learnable_gate=True,
        )
        y = mc(x, mask)
        params = sum(p.numel() for p in mc.parameters() if p.requires_grad)
        assert y.shape == (B, L, D)
        # padding 位置應該被歸零
        assert torch.all(y[0, 200:].abs() < 1e-6)
        print(f"[{mode:>4}] out shape: {tuple(y.shape)} | params: {params:,}")

    # 也驗證 d_out != d_in 的情況 (subsume input projection)
    mc2 = MultiChunk(d_in=D, d_out=256, scales=(8, 32, 128), mode='conv')
    y2 = mc2(x, mask)
    params2 = sum(p.numel() for p in mc2.parameters() if p.requires_grad)
    assert y2.shape == (B, L, 256)
    print(f"[conv, d_out=256] out shape: {tuple(y2.shape)} | params: {params2:,}")

    print("\nAll smoke tests passed.")

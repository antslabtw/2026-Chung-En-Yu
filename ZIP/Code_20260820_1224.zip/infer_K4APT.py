# -*- coding: utf-8 -*-
"""KELLECT4APT TTP tagger — 獨立推論腳本。

載入 tranK.py 存的 checkpoint(自帶 arch/label/bias/前處理設定)，對指定的
KELLECT jsonl 檔跑推論：逐事件預測 TTP，再多數決聚合成整條 trace 的 TTP。

輸入(擇一)：
  --files   一份清單(每行 "label<TAB>路徑"，即 tranK 產的 infer_holdout_files.txt)
  --data_glob "./KELLECT4APT/public_data/**/*.json"   (label 取檔案的上層資料夾名)
  --input   單一 .json 檔或資料夾
  預設：讀 ./Trans_CRF_KELLECT4APT/save_result/infer_holdout_files.txt

用法：
  python infer_K4APT.py                                   # 對 held-out 樣本跑，印準確率
  python infer_K4APT.py --data_glob "./新資料/**/*.json"  # 對新資料跑
  python infer_K4APT.py --dump_events                     # 另存逐事件預測
"""
import os
import math
import pickle
import argparse
import numpy as np
import pandas as pd
from glob import glob
from tqdm import tqdm
from sklearn.metrics import precision_recall_fscore_support, classification_report

import torch
import torch.nn as nn
from torchcrf import CRF

from kellect_event import iter_events, event_to_triple, event_ts

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

ap = argparse.ArgumentParser()
ap.add_argument("--ckpt", default="./Trans_CRF_KELLECT4APT/save_model/best.pt")
ap.add_argument("--sb_dir", default=None, help="override checkpoint 內的 sb_dir")
ap.add_argument("--files", default=None, help="清單檔(每行 label<TAB>path)")
ap.add_argument("--data_glob", default=None)
ap.add_argument("--input", default=None)
ap.add_argument("--o_bias", type=float, default=None, help="override deploy O-bias")
ap.add_argument("--out", default="./Trans_CRF_KELLECT4APT/save_result/infer_predictions.csv")
ap.add_argument("--dump_events", action="store_true")
ap.add_argument("--batch_size", type=int, default=64)
args = ap.parse_args()

# ----------------------------------------------------------------------
# 載入 checkpoint(自我描述)
# ----------------------------------------------------------------------
if not os.path.exists(args.ckpt):
    raise FileNotFoundError(f"找不到 checkpoint {args.ckpt}(先跑 tranK.py 訓練，或用 --ckpt 指定)。")
blob = torch.load(args.ckpt, map_location=device, weights_only=False)
if "state_dict" not in blob:
    raise RuntimeError(f"{args.ckpt} 不是 infer_K4APT 版的 checkpoint(缺 state_dict)；請用新版 tranK.py 重存。")

label2index = blob["label2index"]
index2label = blob["index2label"]
arch = blob["arch"]
WINDOW_SIZE = blob["window_size"]
STRIDE = blob["stride"]
SB_DIR = args.sb_dir or blob["sb_dir"]
O_BIAS = args.o_bias if args.o_bias is not None else blob.get("deploy_o_bias", 0.0)
O_IDX = label2index.get("O", -1)
print(f"[ckpt] {args.ckpt}  classes={len(label2index)}  O-bias={O_BIAS}  sb_dir={SB_DIR}")

# ----------------------------------------------------------------------
# 載入 embedding(必須跟訓練同一份)
# ----------------------------------------------------------------------
with open(f"{SB_DIR}/nodes/vocab2idx.pkl", "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/edges/vocab2idx.pkl", "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/nodes_ent2emb_256.pkl", "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(f"{SB_DIR}/edges_ent2emb_16.pkl", "rb") as fp:
    edge_ent2emb = pickle.load(fp)

NODE_EMB_SIZE, EDGE_EMB_SIZE = 256, 16
node_emb_tensor = torch.tensor(np.array(node_ent2emb), dtype=torch.float32).to(device)
edge_emb_tensor = torch.tensor(np.array(edge_ent2emb), dtype=torch.float32).to(device)
NODE_PAD_IDX = node_emb_tensor.shape[0]
EDGE_PAD_IDX = edge_emb_tensor.shape[0]
node_emb_tensor = torch.cat([node_emb_tensor, torch.zeros(1, NODE_EMB_SIZE).to(device)], dim=0)
edge_emb_tensor = torch.cat([edge_emb_tensor, torch.zeros(1, EDGE_EMB_SIZE).to(device)], dim=0)


# ----------------------------------------------------------------------
# 模型(結構/子模組命名與 tranK.Transformer_CRF 完全一致 → state_dict 可載)
# ----------------------------------------------------------------------
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=1000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1), :]


class Transformer_CRF(nn.Module):
    def __init__(self, embedding_dim, output_size, layers, nhead, d_model=512, dropout=0.2):
        super().__init__()
        self.tagset_size = output_size
        self.d_model = d_model
        self.input_proj = nn.Linear(embedding_dim, d_model)
        self.pos_encoder = PositionalEncoding(d_model, max_len=1000)
        enc = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead,
                                         dim_feedforward=d_model * 2, dropout=dropout, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(enc, num_layers=layers)
        self.hidden2tag = nn.Linear(d_model, output_size)
        self.crf = CRF(num_tags=output_size, batch_first=True)
        self.o_idx = O_IDX

    def emissions(self, x, mask_tensor):
        x = self.pos_encoder(self.input_proj(x))
        out = self.transformer_encoder(x, src_key_padding_mask=~mask_tensor)
        return self.hidden2tag(out)

    def decode(self, feats, mask_tensor, o_bias=0.0):
        if o_bias != 0.0 and self.o_idx != -1:
            feats = feats.clone()
            feats[:, :, self.o_idx] = feats[:, :, self.o_idx] + o_bias
        return self.crf.decode(emissions=feats, mask=mask_tensor)


model = Transformer_CRF(arch["event_dim"], arch["output_size"], arch["layers"],
                        arch["nhead"], arch.get("d_model", 512), arch.get("dropout", 0.2)).to(device)
model.load_state_dict(blob["state_dict"])
model.eval()
print("[model] state_dict 載入成功")


# ----------------------------------------------------------------------
# 一個 trace → 視窗(與 tranK.process_sample 一致，但不需要 label)
# ----------------------------------------------------------------------
def trace_to_windows(json_path):
    events = iter_events(json_path)
    events.sort(key=event_ts)
    seq_src, seq_rel, seq_dst = [], [], []
    for e in events:
        tri = event_to_triple(e)
        if tri is None:
            continue
        s, ed, d = tri
        seq_src.append(node_ent2idx.get(s, NODE_PAD_IDX))
        seq_rel.append(edge_ent2idx.get(ed, EDGE_PAD_IDX))
        seq_dst.append(node_ent2idx.get(d, NODE_PAD_IDX))
    n = len(seq_src)
    if n == 0:
        return []
    seq_msk = [1] * n
    if n % WINDOW_SIZE != 0:
        pad = (WINDOW_SIZE - n if n < WINDOW_SIZE
               else ((n - WINDOW_SIZE) // STRIDE + 1) * STRIDE + WINDOW_SIZE - n)
        seq_src += [NODE_PAD_IDX] * pad
        seq_rel += [EDGE_PAD_IDX] * pad
        seq_dst += [NODE_PAD_IDX] * pad
        seq_msk += [0] * pad
    wins = []
    for i in range(0, len(seq_src) - WINDOW_SIZE + 1, STRIDE):
        wins.append((seq_src[i:i+WINDOW_SIZE], seq_rel[i:i+WINDOW_SIZE],
                     seq_dst[i:i+WINDOW_SIZE], seq_msk[i:i+WINDOW_SIZE]))
    return wins


@torch.no_grad()
def predict_trace(json_path):
    """回傳 (trace 級預測 label 字串, 逐(視窗有效位置)預測索引 list)。"""
    wins = trace_to_windows(json_path)
    if not wins:
        return None, []
    all_pred = []
    for i in range(0, len(wins), args.batch_size):
        chunk = wins[i:i+args.batch_size]
        src = torch.tensor([w[0] for w in chunk], dtype=torch.long, device=device)
        rel = torch.tensor([w[1] for w in chunk], dtype=torch.long, device=device)
        dst = torch.tensor([w[2] for w in chunk], dtype=torch.long, device=device)
        msk = torch.tensor([w[3] for w in chunk], dtype=torch.bool, device=device)
        feats = torch.cat([node_emb_tensor[src], edge_emb_tensor[rel], node_emb_tensor[dst]], dim=-1)
        with torch.amp.autocast("cuda", enabled=(device.type == "cuda")):
            emis = model.emissions(feats, msk).float()
        out = model.decode(emis, msk, o_bias=O_BIAS)
        for seq in out:
            all_pred.extend(seq)
    if not all_pred:
        return None, []
    # trace 級：對所有(非O優先)預測做多數決
    vals, cnts = np.unique(np.array(all_pred), return_counts=True)
    order = np.argsort(-cnts)
    ranked = [(int(vals[o]), int(cnts[o])) for o in order]
    attack_ranked = [(i, c) for i, c in ranked if i != O_IDX]
    top_idx = attack_ranked[0][0] if attack_ranked else ranked[0][0]
    return index2label.get(top_idx, str(top_idx)), all_pred


# ----------------------------------------------------------------------
# 收集要推論的 (true_label, path)
# ----------------------------------------------------------------------
def gather_targets():
    pairs = []
    if args.files or (not args.data_glob and not args.input):
        list_path = args.files or "./Trans_CRF_KELLECT4APT/save_result/infer_holdout_files.txt"
        if not os.path.exists(list_path):
            raise FileNotFoundError(f"找不到清單 {list_path}(先跑 tranK.py 產 held-out 清單，或用 --data_glob/--input)。")
        with open(list_path, encoding="utf-8") as fp:
            for line in fp:
                line = line.rstrip("\n")
                if not line:
                    continue
                if "\t" in line:
                    lab, p = line.split("\t", 1)
                else:
                    lab, p = os.path.basename(os.path.dirname(line)), line
                pairs.append((lab, p))
        return pairs
    paths = []
    if args.data_glob:
        paths = glob(args.data_glob, recursive=True)
    elif args.input:
        paths = [args.input] if os.path.isfile(args.input) else glob(os.path.join(args.input, "**", "*.json"), recursive=True)
    for p in paths:
        pairs.append((os.path.basename(os.path.dirname(p)), p))
    return pairs


targets = gather_targets()
print(f"[infer] 共 {len(targets)} 個 trace 要推論")

rows, ev_rows = [], []
n_correct, n_known = 0, 0
y_true_all, y_pred_all = [], []   # 給 P/R/F1 用(trace 級)
for lab_true, p in tqdm(targets, desc="infer", unit="trace"):
    pred, all_pred = predict_trace(p)
    known = lab_true in label2index and lab_true != "O"
    correct = (pred == lab_true) if known else None
    if known:
        n_known += 1
        n_correct += int(correct)
    # 只要 true label 是已知類別就納入 P/R/F1；沒抽到事件(pred=None) 視為 "O"(=沒偵到攻擊)
    if lab_true in label2index:
        y_true_all.append(lab_true)
        y_pred_all.append(pred if pred is not None else "O")
    rows.append({"file": p, "true_label": lab_true, "pred_label": pred,
                 "correct": correct, "n_events": len(all_pred)})
    if args.dump_events:
        for j, pi in enumerate(all_pred):
            ev_rows.append({"file": p, "pos": j, "pred": index2label.get(int(pi), str(pi))})

os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
pd.DataFrame(rows).to_csv(args.out, index=False)
print(f"[out] 逐 trace 預測 → {args.out}")
if args.dump_events:
    ev_out = args.out.replace(".csv", "_events.csv")
    pd.DataFrame(ev_rows).to_csv(ev_out, index=False)
    print(f"[out] 逐事件預測 → {ev_out}")

if n_known:
    print(f"[結果] trace 級 TTP 準確率 = {n_correct}/{n_known} = {n_correct/n_known:.4f}")
else:
    print("[結果] 輸入沒有已知 label(或全是 O)，只輸出預測、不算準確率。")

# ---- 樣本級 P / R / F1 ----
# 每個樣本(trace)判成一個 TTP，pred==true 才算對；P/R/F1 = 對各 TTP 類別取 macro 平均。
# labels = GT 出現過的 TTP(排除 O)，與 tranK / SFM Table II 口徑一致。
if y_true_all:
    labels_eval = sorted({l for l in y_true_all if l != "O"})
    if labels_eval:
        p, r, f1, _ = precision_recall_fscore_support(
            y_true_all, y_pred_all, labels=labels_eval, average="macro", zero_division=0)
        print(f"[結果] 樣本級 TTP 分類 (macro over {len(labels_eval)} 類)  "
              f"P={p:.4f}  R={r:.4f}  F1={f1:.4f}")
        # 逐類 P/R/F1 存檔(欄位 label, precision, recall, f1-score, support)
        report = classification_report(y_true_all, y_pred_all, labels=labels_eval,
                                       zero_division=0, output_dict=True)
        prf_out = args.out.replace(".csv", "_prf.csv") if args.out.endswith(".csv") else args.out + "_prf.csv"
        (pd.DataFrame(report).transpose()
           .reset_index().rename(columns={"index": "label"})
           .to_csv(prf_out, index=False))
        print(f"[out] 逐類 P/R/F1 → {prf_out}")
    else:
        print("[結果] GT 全是 O，無法計算 TTP P/R/F1。")

# -*- coding: utf-8 -*-
"""collect_results.py — 把所有 inference 結果整合成一張表。

從 log 檔解析(不用重跑)。所有 infer 腳本都會印這兩種行:
    >>> 最佳 O-bias=8.0  AVG token-F1=0.6452  (P=0.6404 R=0.7292)  對照 SFM=0.6864
    C1.json         | Atk P:0.9298 R:0.9286 F1:0.9201

★ 重要:log 印的 AVG 是**全部 campaign**(C1–C8)的平均,
   但 PPT/論文只用 C1,C3,C5,C6,C7 五個(gen_latex_table.py 的 CAMPAIGN_MAP)。
   本腳本會用逐檔數字**重算指定子集的平均**,兩種都給你。

用法:
    python collect_results.py run_all.log
    python collect_results.py *.log --campaigns C1,C3,C5,C6,C7
    python collect_results.py run_all.log --latex        # 另外輸出 LaTeX 表
"""
import os, re, csv, sys, glob, argparse
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("logs", nargs="+", help="log 檔(可用萬用字元)")
ap.add_argument("--campaigns", default="C1,C3,C5,C6,C7",
                help="要重算平均的 campaign 子集(PPT 口徑);設 all 則不篩選")
ap.add_argument("--out_csv", default="./all_results.csv")
ap.add_argument("--out_md", default="./all_results.md")
ap.add_argument("--latex", action="store_true", help="另外印 LaTeX 表")
args = ap.parse_args()

SUBSET = None if args.campaigns.strip().lower() == "all" else \
    [x.strip() for x in args.campaigns.split(",") if x.strip()]
# C1 → Higaisa 等(與 gen_latex_table.py 一致)
NAME_MAP = {"C1": "Higaisa", "C3": "APT28", "C5": "CobaltGroup", "C6": "Gamaredon", "C7": "Patchwork"}

RE_BEST = re.compile(r">>>\s*最佳 O-bias=([\d.]+)\s+AVG token-F1=([\d.]+)\s*\(P=([\d.]+)\s+R=([\d.]+)\)")
RE_ROW = re.compile(r"^\s*(\S+?)\.json\s*\|\s*Atk\s+P:([\d.]+)\s+R:([\d.]+)\s+F1:([\d.]+)")
RE_CKPT = [re.compile(p) for p in (
    r"使用 checkpoint:\s*(\S+)", r"----\s*infer\s+(\S+)", r"ckpt=(\S+)",
    r"Transformer=(\S+)", r"Loading Transformer.*?:\s*(\S+)")]
RE_HIT = re.compile(r"\[LLM node 命中率\][^=]*=\s*([\d.]+)%")

runs = []
for pat in args.logs:
    for path in sorted(glob.glob(pat)) or [pat]:
        if not os.path.exists(path):
            print(f"[跳過] 找不到 {path}"); continue
        cur_ckpt, cur_hit, cur = None, None, None
        with open(path, encoding="utf-8", errors="ignore") as fp:
            for line in fp:
                for r in RE_CKPT:                       # 記住最近一次提到的 checkpoint
                    m = r.search(line)
                    if m:
                        cur_ckpt = os.path.basename(m.group(1).strip().rstrip(":,"))
                        break
                m = RE_HIT.search(line)
                if m:
                    cur_hit = float(m.group(1))
                m = RE_BEST.search(line)
                if m:
                    cur = {"log": os.path.basename(path), "ckpt": cur_ckpt or "?",
                           "bias": float(m.group(1)), "avg_f1_log": float(m.group(2)),
                           "avg_p_log": float(m.group(3)), "avg_r_log": float(m.group(4)),
                           "llm_hit": cur_hit, "camp": {}}
                    runs.append(cur)
                    cur_hit = None          # 用掉就清掉,不要沿用到下一次執行
                    continue
                m = RE_ROW.match(line)
                if m and cur is not None:
                    cur["camp"][m.group(1)] = (float(m.group(2)), float(m.group(3)), float(m.group(4)))

if not runs:
    raise SystemExit("沒解析到任何結果。確認 log 裡有 '>>> 最佳 O-bias ... AVG token-F1' 這行。")

# 重算子集平均
for r in runs:
    keys = [k for k in r["camp"] if (SUBSET is None or k in SUBSET)]
    if keys:
        arr = np.array([r["camp"][k] for k in sorted(keys)])
        r["n_sub"] = len(keys)
        r["p"], r["r"], r["f1"] = arr.mean(axis=0)
    else:
        r["n_sub"] = 0
        r["p"] = r["r"] = r["f1"] = float("nan")

runs.sort(key=lambda x: -(x["f1"] if x["f1"] == x["f1"] else -1))

label = "全部" if SUBSET is None else ",".join(SUBSET)
lines = [f"# Inference 結果彙整", "",
         f"- 來源:{', '.join(sorted({r['log'] for r in runs}))}",
         f"- 平均範圍:**{label}**(共 {runs[0]['n_sub']} 個 campaign)",
         f"- 對照:SFM = 68.64%", "",
         "| # | checkpoint | O-bias | AVG P | AVG R | **AVG F1** | (log 印的全檔平均 F1) | LLM 命中率 |",
         "|---|---|---|---|---|---|---|---|"]
print("=" * 100)
print(f"{'#':>2} {'checkpoint':<42} {'bias':>5} {'P':>7} {'R':>7} {'F1':>7} {'log全檔':>8} {'LLM%':>6}")
print("-" * 100)
for i, r in enumerate(runs, 1):
    hit = f"{r['llm_hit']:.1f}" if r["llm_hit"] is not None else "-"
    print(f"{i:>2} {r['ckpt'][:42]:<42} {r['bias']:>5.1f} {r['p']*100:>7.2f} {r['r']*100:>7.2f} "
          f"{r['f1']*100:>7.2f} {r['avg_f1_log']*100:>8.2f} {hit:>6}")
    lines.append(f"| {i} | `{r['ckpt']}` | {r['bias']:.1f} | {r['p']*100:.2f}% | {r['r']*100:.2f}% "
                 f"| **{r['f1']*100:.2f}%** | {r['avg_f1_log']*100:.2f}% | {hit} |")
print("=" * 100)

# 逐 campaign 對照(列=campaign,欄=各次執行)
camps = sorted({k for r in runs for k in r["camp"]}, key=lambda x: (len(x), x))
if SUBSET:
    camps = [c for c in camps if c in SUBSET]
if camps:
    hdr = "| Campaign | " + " | ".join(f"{r['ckpt'][:22]}" for r in runs) + " |"
    sep = "|---|" + "---|" * len(runs)
    lines += ["", "## 逐 campaign F1", "", hdr, sep]
    print("\n逐 campaign F1(%)")
    print("Campaign     " + " ".join(f"{r['ckpt'][:14]:>15}" for r in runs))
    for c in camps:
        disp = f"{c}({NAME_MAP[c]})" if c in NAME_MAP else c
        cells = []
        for r in runs:
            v = r["camp"].get(c)
            cells.append(f"{v[2]*100:.2f}%" if v else "-")
        lines.append(f"| {disp} | " + " | ".join(cells) + " |")
        print(f"{disp:<13}" + " ".join(f"{x:>15}" for x in cells))
    avg_cells = [f"{r['f1']*100:.2f}%" for r in runs]
    lines.append(f"| **AVG** | " + " | ".join(f"**{x}**" for x in avg_cells) + " |")
    print(f"{'AVG':<13}" + " ".join(f"{x:>15}" for x in avg_cells))

with open(args.out_csv, "w", newline="", encoding="utf-8") as fp:
    w = csv.writer(fp)
    w.writerow(["log", "ckpt", "o_bias", "avg_P", "avg_R", "avg_F1", "avg_F1_all_campaigns",
                "llm_hit_pct", "n_campaigns"] + camps)
    for r in runs:
        w.writerow([r["log"], r["ckpt"], r["bias"], f"{r['p']:.4f}", f"{r['r']:.4f}", f"{r['f1']:.4f}",
                    f"{r['avg_f1_log']:.4f}", r["llm_hit"] if r["llm_hit"] is not None else "",
                    r["n_sub"]] + [f"{r['camp'][c][2]:.4f}" if c in r["camp"] else "" for c in camps])
with open(args.out_md, "w", encoding="utf-8") as fp:
    fp.write("\n".join(lines) + "\n")
print(f"\n已寫出 {args.out_csv} 與 {args.out_md}")

if args.latex:
    print("\n" + "=" * 60 + "\nLaTeX(逐 campaign,可直接貼)\n" + "=" * 60)
    cols = "l" + "c" * len(runs)
    print(r"\begin{tabular}{" + cols + "}")
    print(r"\toprule")
    print("APT Campaign & " + " & ".join(r["ckpt"][:18].replace("_", r"\_") for r in runs) + r" \\")
    print(r"\midrule")
    for c in camps:
        disp = NAME_MAP.get(c, c)
        cells = [f"{r['camp'][c][2]*100:.2f}\\%" if c in r["camp"] else "-" for r in runs]
        print(f"{disp} & " + " & ".join(cells) + r" \\")
    print(r"\midrule")
    print("Avg. & " + " & ".join(f"{r['f1']*100:.2f}\\%" for r in runs) + r" \\")
    print(r"\bottomrule")
    print(r"\end{tabular}")

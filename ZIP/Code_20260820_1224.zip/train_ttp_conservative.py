# -*- coding: utf-8 -*-
"""
TTP tagger 訓練 — Multi-chunk(時間 or 圖 hop) + LLM-embedding concat。

  --chunk_kind temporal  → MultiChunk 尺度 (256,64,16)  (時間 ±N event)
  --chunk_kind hop       → MultiHop    尺度 (3,2,1)      (共用節點 k-hop)

LLM embedding：node → LLM 敘述 → SecureBERT → PCA (make_llm_embedding.py 先產)，
以 node 字串查表，concat 到 528 結構化之後 (src、dst 各一份)，再進 preprocessor。
模型定義在 ttp_model.py (train / infer 共用，不 drift)。保守度靠 decode O-bias。
"""
import os, json, random, pickle, logging, gc, argparse
import numpy as np
import pandas as pd
from glob import glob
from tqdm import tqdm
from sklearn.metrics import classification_report, precision_recall_fscore_support

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from ttp_model import TTP_Model, build_event_feats, scales_for, STRUCT_DIM
from model_v2 import TTP_Model_V2   # 創新版:ReZero 閘門殘差(--model v2)

# ======================================================================
ap = argparse.ArgumentParser()
ap.add_argument("--chunk_kind", choices=["temporal", "hop"], default="temporal")
ap.add_argument("--use_llm", type=int, default=1)          # 1=concat LLM embedding (aux 128)
ap.add_argument("--llm_dir", default="./SecureBERT2.0-base")
# emb_mode: structured=結構化 node emb(+可選 LLM aux);llm_main=node emb 純用 LLM 敘述(256),不加 aux
ap.add_argument("--emb_mode", choices=["structured", "llm_main"], default="structured")
ap.add_argument("--llmmain_dir", default="./SecureBERT2.0-base-llmmain")
ap.add_argument("--epochs", type=int, default=10)
ap.add_argument("--batch_size", type=int, default=64)
ap.add_argument("--lr", type=float, default=5e-5)
ap.add_argument("--weight_decay", type=float, default=1e-5, help="AdamW weight decay;調大(如 1e-4)有助泛化")
ap.add_argument("--tag_suffix", default="", help="附加到 checkpoint/result 檔名以區分不同 LLM,例如 _qwen")
ap.add_argument("--model", choices=["base", "v2"], default="base",
                help="base=原 TTP_Model;v2=創新版(ReZero 閘門殘差 multi-chunk + LLM)")
args = ap.parse_args()
EMB_MODE = args.emb_mode

SEED = 42
WINDOW_SIZE, STRIDE = 256, 32
ATTACK_CLASS_WEIGHT, O_CLASS_WEIGHT, FOCAL_GAMMA = 3.0, 1.0, 2.0
O_BIAS_SWEEP = [0.0, 1.0, 2.0, 3.0, 4.0, 6.0, 8.0]   # 對齊 inference 的 O-bias 掃描網格
RECALL_TOL = 0.02
DATA_DIR = "./Training_data/"
CACHE = {"train": "./train_data.pt", "valid": "./valid_data.pt", "test": "./test_data.pt"}
MODEL_SAVE = "./Trans_CRF0706/save_model"
RESULT_SAVE = "./Trans_CRF0706/save_result"
USE_LLM = bool(args.use_llm) and EMB_MODE == "structured"   # llm_main:LLM 就是主 emb,不再另加 aux
TAG = (f"{args.chunk_kind}" + ("_llmmain" if EMB_MODE == "llm_main" else ("_llm" if USE_LLM else ""))
       + args.tag_suffix + ("_v2" if args.model == "v2" else ""))   # v2 不撞 base 的 checkpoint
# ======================================================================

random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")
logging.info(f"chunk_kind={args.chunk_kind}  use_llm={USE_LLM}  device={device}")

with open("./relations.txt") as fp:
    relations = [r.strip() for r in fp.readlines()]
with open("./label2index_0201.pkl", "rb") as fp:
    label2index = pickle.load(fp)
with open("./index2label_0201.pkl", "rb") as fp:
    index2label = pickle.load(fp)
# ⚠ 訓練用的 node/edge embedding 必須跟「推論時用的那張表」在同一個 PCA 空間,
#   否則模型在 A 空間學、在 B 空間被評估 = 輸入亂碼(2026-07-19 確認過:base 與 SAGA 兩表
#   同一字串 cos≈0,完全對不上)。可用環境變數 TTP_EMB_* 覆寫成對齊的那張表。
NODE_VOCAB = os.environ.get("TTP_NODE_VOCAB", "./SecureBERT2.0-base/nodes/vocab2idx.pkl")
EDGE_VOCAB = os.environ.get("TTP_EDGE_VOCAB", "./SecureBERT2.0-base/edges/vocab2idx.pkl")
NODE_EMB   = os.environ.get("TTP_NODE_EMB",   "./SecureBERT2.0-base/nodes_ent2emb_256.pkl")
EDGE_EMB   = os.environ.get("TTP_EDGE_EMB",   "./SecureBERT2.0-base/edges_ent2emb_16.pkl")
logging.info(f"訓練 embedding 表: {NODE_VOCAB} | {NODE_EMB}")
with open(NODE_VOCAB, "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(EDGE_VOCAB, "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(NODE_EMB, "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(EDGE_EMB, "rb") as fp:
    edge_ent2emb = pickle.load(fp)

OUTPUT_SIZE = len(label2index)
O_IDX = label2index.get("O", -1)

# [llm_main] node emb 改用「純 LLM 敘述 → SecureBERT → PCA 256」取代結構化 node emb
if EMB_MODE == "llm_main":
    with open(f"{args.llmmain_dir}/llm_node_vocab2idx.pkl", "rb") as fp:
        _mv2i = pickle.load(fp)
    _cand = sorted(glob(f"{args.llmmain_dir}/llm_node_ent2emb_*.pkl"))
    assert _cand, (f"找不到 {args.llmmain_dir}/llm_node_ent2emb_*.pkl；先跑 "
                   f"python make_llm_embedding.py --save_dir {args.llmmain_dir} --pca_dim 256")
    with open(_cand[-1], "rb") as fp:
        _marr = np.asarray(pickle.load(fp), dtype=np.float32)
    assert _marr.shape[1] == 256, f"llm_main 需要 256 維 node emb,拿到 {_marr.shape[1]} (用 --pca_dim 256 重生)"
    _node_arr = np.zeros((len(node_ent2idx), 256), dtype=np.float32)
    _hit = 0
    for s, i in node_ent2idx.items():
        j = _mv2i.get(s)
        if j is not None:
            _node_arr[i] = _marr[j]; _hit += 1
    node_ent2emb = _node_arr
    logging.info(f"[llm_main] node emb = LLM 敘述 256 維, matched {_hit}/{len(node_ent2idx)} nodes")

node_emb_tensor = torch.tensor(np.array(node_ent2emb), dtype=torch.float32).to(device)
edge_emb_tensor = torch.tensor(np.array(edge_ent2emb), dtype=torch.float32).to(device)
NODE_PAD_IDX = node_emb_tensor.shape[0]
EDGE_PAD_IDX = edge_emb_tensor.shape[0]
node_emb_tensor = torch.cat([node_emb_tensor, torch.zeros(1, 256).to(device)], dim=0)
edge_emb_tensor = torch.cat([edge_emb_tensor, torch.zeros(1, 16).to(device)], dim=0)

# ---- LLM embedding 查表 (對齊 node 的 index 空間；OOV→0) ----
llm_emb_tensor, LLM_DIM = None, 0
if USE_LLM:
    with open(os.path.join(args.llm_dir, "llm_node_vocab2idx.pkl"), "rb") as fp:
        llm_v2i = pickle.load(fp)
    cand = sorted(glob(os.path.join(args.llm_dir, "llm_node_ent2emb_*.pkl")))
    assert cand, f"找不到 llm_node_ent2emb_*.pkl，先跑 make_llm_embedding.py ({args.llm_dir})"
    with open(cand[-1], "rb") as fp:
        llm_arr = np.asarray(pickle.load(fp), dtype=np.float32)
    LLM_DIM = llm_arr.shape[1]
    llm_emb_tensor = torch.zeros(node_emb_tensor.shape[0], LLM_DIM)
    hit = 0
    for s, i in node_ent2idx.items():
        j = llm_v2i.get(s)
        if j is not None:
            llm_emb_tensor[i] = torch.from_numpy(llm_arr[j]); hit += 1
    llm_emb_tensor = llm_emb_tensor.to(device)
    logging.info(f"LLM emb: dim={LLM_DIM}, matched {hit}/{len(node_ent2idx)} nodes (其餘補0)")

COMBINED_DIM = STRUCT_DIM + (2 * LLM_DIM if USE_LLM else 0)
logging.info(f"COMBINED_DIM = {COMBINED_DIM}  (struct 528 + LLM {2*LLM_DIM})")

type2attr = {"Process": "Cmdline", "File": "Name", "Registry": "Key", "Network": "Dstaddress"}


def get_value(event):
    srcType = event["srcNode"]["Type"]
    srcAttr = event["srcNode"][type2attr[srcType]]
    src_uuid = event["srcNode"].get("UUID")
    if event["dstNode"] is not None:
        dstType = event["dstNode"]["Type"]
        dstAttr = event["dstNode"][type2attr[dstType]]
        dst_uuid = event["dstNode"].get("UUID")
    else:
        dstAttr, dst_uuid = srcAttr, src_uuid
    return srcAttr, dstAttr, event["relation"], event["label"], src_uuid, dst_uuid


def make_dataset(dataset):
    processed = []
    for p in tqdm(dataset, desc="Processing files"):
        with open(p) as fp:
            events = json.load(fp)
        seq_src, seq_rel, seq_dst, seq_label, seq_mask, seq_ga, seq_gb = [], [], [], [], [], [], []
        uuid2id = {}   # 每檔 local:UUID 字串 → int(圖用;同 UUID=同節點,不同名撞不到一起)
        for e in events:
            srcAttr, dstAttr, rel, label, su, du = get_value(e)
            if rel not in relations:
                continue
            seq_src.append(node_ent2idx.get(str(srcAttr), NODE_PAD_IDX))
            seq_rel.append(edge_ent2idx.get(rel, EDGE_PAD_IDX))
            seq_dst.append(node_ent2idx.get(str(dstAttr), NODE_PAD_IDX))
            seq_label.append(label2index.get(label, label2index["O"]))
            seq_mask.append(1)
            seq_ga.append(uuid2id.setdefault(su, len(uuid2id)) if su is not None else -1)
            seq_gb.append(uuid2id.setdefault(du, len(uuid2id)) if du is not None else -1)
        if len(seq_src) == 0:
            continue
        if len(seq_src) % WINDOW_SIZE != 0:
            pad_len = (WINDOW_SIZE - len(seq_src) if len(seq_src) < WINDOW_SIZE
                       else ((len(seq_src) - WINDOW_SIZE) // STRIDE + 1) * STRIDE + WINDOW_SIZE - len(seq_src))
            seq_src.extend([NODE_PAD_IDX] * pad_len)
            seq_rel.extend([EDGE_PAD_IDX] * pad_len)
            seq_dst.extend([NODE_PAD_IDX] * pad_len)
            seq_label.extend([label2index["O"]] * pad_len)
            seq_mask.extend([0] * pad_len)
            seq_ga.extend([-1] * pad_len); seq_gb.extend([-1] * pad_len)
        for i in range(0, len(seq_src) - WINDOW_SIZE + 1, STRIDE):
            processed.append({
                "src": torch.tensor(seq_src[i:i+WINDOW_SIZE], dtype=torch.long),
                "rel": torch.tensor(seq_rel[i:i+WINDOW_SIZE], dtype=torch.long),
                "dst": torch.tensor(seq_dst[i:i+WINDOW_SIZE], dtype=torch.long),
                "ga": torch.tensor(seq_ga[i:i+WINDOW_SIZE], dtype=torch.long),
                "gb": torch.tensor(seq_gb[i:i+WINDOW_SIZE], dtype=torch.long),
                "label_idx": torch.tensor(seq_label[i:i+WINDOW_SIZE], dtype=torch.long),
                "mask": torch.tensor(seq_mask[i:i+WINDOW_SIZE], dtype=torch.bool),
                "process": p,
            })
        del seq_src, seq_rel, seq_dst, seq_label, seq_mask, seq_ga, seq_gb
        gc.collect()
    return processed


def _torch_load(p):
    try:
        return torch.load(p, weights_only=False)
    except TypeError:
        return torch.load(p)


_have_cache = all(os.path.exists(f) for f in CACHE.values())
if _have_cache:
    logging.info("載入快取 dataset (*.pt) ...")
    train_data = _torch_load(CACHE["train"]); valid_data = _torch_load(CACHE["valid"]); test_data = _torch_load(CACHE["test"])
    if not train_data or "ga" not in train_data[0]:      # 舊快取沒有圖 key → 重建
        logging.warning("舊快取缺 graph key(ga/gb)→ 重建 dataset"); _have_cache = False
if not _have_cache:
    trainset, validset, testset = [], [], []
    for ability in tqdm(os.listdir(DATA_DIR), desc="Splitting dataset"):
        paths = glob(f"{DATA_DIR}/{ability}/number_*/expanded_instance.json")
        random.shuffle(paths)
        trainset.extend(paths[:80]); validset.extend(paths[80:90]); testset.extend(paths[90:])
    train_data = make_dataset(trainset); valid_data = make_dataset(validset); test_data = make_dataset(testset)
    torch.save(train_data, CACHE["train"]); torch.save(valid_data, CACHE["valid"]); torch.save(test_data, CACHE["test"])

train_loader = DataLoader(train_data, batch_size=args.batch_size, shuffle=True,  num_workers=4, pin_memory=True)
valid_loader = DataLoader(valid_data, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=True)
test_loader  = DataLoader(test_data,  batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=True)

# ---- model ----
class_weights = torch.ones(OUTPUT_SIZE, device=device) * ATTACK_CLASS_WEIGHT
if O_IDX != -1:
    class_weights[O_IDX] = O_CLASS_WEIGHT
if args.model == "v2":
    model = TTP_Model_V2(COMBINED_DIM, OUTPUT_SIZE, args.chunk_kind, scales_for(args.chunk_kind),
                         NODE_PAD_IDX, class_weights=class_weights, o_idx=O_IDX,
                         focal_gamma=FOCAL_GAMMA, graph_mode="shared",
                         struct_dim=STRUCT_DIM, use_ms=True, use_llm=USE_LLM).to(device)
else:
    model = TTP_Model(COMBINED_DIM, OUTPUT_SIZE, args.chunk_kind, scales_for(args.chunk_kind),
                      NODE_PAD_IDX, class_weights=class_weights, o_idx=O_IDX,
                      focal_gamma=FOCAL_GAMMA, graph_mode="shared").to(device)   # SFM: srcUUID/dstUUID
optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)
scaler = torch.amp.GradScaler("cuda")
os.makedirs(MODEL_SAVE, exist_ok=True)
attack_labels_indices = [i for i in range(OUTPUT_SIZE) if i != O_IDX]

CFG = {"chunk_kind": args.chunk_kind, "scales": list(scales_for(args.chunk_kind)),
       "use_llm": USE_LLM, "llm_dim": LLM_DIM, "combined_dim": COMBINED_DIM,
       "output_size": OUTPUT_SIZE, "node_pad_idx": NODE_PAD_IDX, "o_idx": O_IDX,
       "graph_mode": "shared", "emb_mode": EMB_MODE,
       "model": args.model, "struct_dim": STRUCT_DIM}   # v2 重建用


def _feat(data):
    src = data["src"].to(device, non_blocking=True)
    rel = data["rel"].to(device, non_blocking=True)
    dst = data["dst"].to(device, non_blocking=True)
    ga = data["ga"].to(device, non_blocking=True)
    gb = data["gb"].to(device, non_blocking=True)
    feats = build_event_feats(src, rel, dst, node_emb_tensor, edge_emb_tensor, llm_emb_tensor)
    return feats, ga, gb


@torch.no_grad()
def eval_sweep(loader, biases):
    model.eval()
    trues_all, preds_by_bias = [], {b: [] for b in biases}
    for data in loader:
        mask = data["mask"].to(device, non_blocking=True)
        feats, ga, gb = _feat(data)
        e = model.emissions(feats, ga, gb, mask).float()
        label_cpu = data["label_idx"].cpu().tolist()
        for k, b in enumerate(biases):
            out = model.decode(e, mask, o_bias=b)
            for idx, pred in enumerate(out):
                preds_by_bias[b].extend(pred)
                if k == 0:
                    trues_all.extend(label_cpu[idx][:len(pred)])
    rows = {}
    for b in biases:
        p, r, f, _ = precision_recall_fscore_support(
            trues_all, preds_by_bias[b], labels=attack_labels_indices, average="macro", zero_division=0)
        rows[b] = (p, r, f)
    return rows


def recommend_bias(rows, base=0.0, tol=RECALL_TOL):
    base_r = rows.get(base, (0, 0, 0))[1]
    cands = [(b, v) for b, v in rows.items() if v[1] >= base_r - tol]
    return max(cands, key=lambda x: (x[1][0], x[0]))[0] if cands else base


# ---- train ----
best_f1, best_path = float("-inf"), ""
for epoch in range(args.epochs):
    model.train(); losses = []
    for data in tqdm(train_loader, desc=f"[{TAG}] ep{epoch}"):
        label = data["label_idx"].to(device, non_blocking=True)
        mask = data["mask"].to(device, non_blocking=True)
        feats, ga, gb = _feat(data)
        optimizer.zero_grad()
        with torch.amp.autocast("cuda"):
            _, loss = model(feats, ga, gb, label, mask)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(optimizer); scaler.update()
        losses.append(loss.item())
    scheduler.step()

    rows = eval_sweep(valid_loader, O_BIAS_SWEEP)
    ap_, ar_, af_ = rows[0.0]
    # 用「最佳 O-bias 下的 F1」挑 checkpoint(對齊凍結 inference 的 O-bias 掃描部署)
    best_b = max(O_BIAS_SWEEP, key=lambda b: rows[b][2])
    best_bias_f1 = rows[best_b][2]
    logging.info(f"[{TAG}] ep{epoch} | loss:{np.mean(losses):.4f} | @0 P:{ap_:.4f} R:{ar_:.4f} F1:{af_:.4f}"
                 f" | best@O-bias{best_b} F1:{best_bias_f1:.4f}")
    for b in O_BIAS_SWEEP:
        p, r, f = rows[b]; logging.info(f"      O-bias={b:>4}: P={p:.4f} R={r:.4f} F1={f:.4f}")
    if best_bias_f1 > best_f1:
        best_f1 = best_bias_f1
        best_path = f"{MODEL_SAVE}/best_{TAG}.pt"
        torch.save({"model": model.state_dict(), "cfg": CFG, "label2index": label2index}, best_path)
        logging.info(f"  ✓ saved {best_path} (best@O-bias F1={best_f1:.4f})")

# ---- deploy O-bias + test ----
if best_path:
    model.load_state_dict(_torch_load(best_path)["model"])
if hasattr(model, "gate_values"):
    logging.info(f"[{TAG}] ReZero 閘門 = {model.gate_values()}  (>0 = 模型採用了該創新分支)")
val_rows = eval_sweep(valid_loader, O_BIAS_SWEEP)
deploy_bias = recommend_bias(val_rows)
logging.info(f"[{TAG}] => deploy O-bias = {deploy_bias} (填進 infer_saga.py)")
test_rows = eval_sweep(test_loader, sorted(set([0.0, deploy_bias])))
tp0, tr0, tf0 = test_rows[0.0]; tp, tr, tf = test_rows[deploy_bias]
logging.info(f"[{TAG}] TEST base   P:{tp0:.4f} R:{tr0:.4f} F1:{tf0:.4f}")
logging.info(f"[{TAG}] TEST deploy(O-bias={deploy_bias}) P:{tp:.4f} R:{tr:.4f} F1:{tf:.4f}")

os.makedirs(RESULT_SAVE, exist_ok=True)
model.decode_o_bias = deploy_bias
all_pred, all_lab = [], []
model.eval()
with torch.no_grad():
    for data in tqdm(test_loader, desc=f"[{TAG}] test-report"):
        mask = data["mask"].to(device, non_blocking=True)
        feats, ga, gb = _feat(data)
        out, _ = model(feats, ga, gb, None, mask)
        label_cpu = data["label_idx"].cpu().tolist()
        for idx, pred in enumerate(out):
            all_pred.extend(pred); all_lab.extend(label_cpu[idx][:len(pred)])
rep = classification_report(all_lab, all_pred, output_dict=True, zero_division=0)
df = pd.DataFrame(rep).transpose().reset_index(names="label")
df["label"] = df["label"].apply(lambda x: index2label.get(int(x), x) if str(x).isdigit() else x)
df.to_csv(f"{RESULT_SAVE}/result_{TAG}.csv", index=False)
logging.info(f"[{TAG}] saved {RESULT_SAVE}/result_{TAG}.csv")

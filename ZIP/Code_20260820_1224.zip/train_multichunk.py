# -*- coding: utf-8 -*-
"""
TTP tagger — Multi-chunk 版 (每個 chunk 一個 transformer)
=========================================================
除了「模型」以外,其餘與 train_ttp_conservative.py 完全一樣
(同資料流、同 SecureBERT2.0-base、同 class weight/focal、同 O-bias 掃描、
 同 raw state_dict 存檔命名 epoch_*_AtkF1_*)。

模型差異:
    原本 : input_proj(528→512) → PE → Transformer(2層) → hidden2tag → CRF
    這裡 : 對每個 chunk 尺度 s ∈ (256,64,16)
             pooled_s = 以每個事件為中心、±s/2 的 masked 平均池化 (長度不變, 528維)
             h_s      = Transformer_s( PE( input_proj_s(pooled_s) ) )   ← 每個 chunk 一個 transformer
           h = fuse( concat[h_256, h_64, h_16] )  (3*512 → 512)
           → hidden2tag → CRF

搭配 infer_saga_mc.py 推論 (模型結構相同才能載 state_dict)。
"""
import os
import math
import json
import random
import pickle
import logging
import gc
import numpy as np
import pandas as pd
from glob import glob
from tqdm import tqdm
from sklearn.metrics import classification_report, precision_recall_fscore_support

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchcrf import CRF
from torch.utils.data import DataLoader

# ======================================================================
# CONFIG
# ======================================================================
SEED          = 42
WINDOW_SIZE   = 256
STRIDE        = 32
BATCH_SIZE    = 64
EPOCHS        = 30
LR            = 3e-5    # 5e-5 會讓權重長太快 → 後期 emission 爆炸;降一點更穩
WARMUP_RATIO  = 0.05    # 前 5% 步數線性 warmup,之後 cosine 衰減
GRAD_CLIP     = 0.5     # 1.0→0.5,限制單步更新,壓住 loss spike

CHUNK_SCALES  = (1, 4, 16)      # 小尺度:大池化會把稀疏攻擊抹進良性海→APT campaign 崩。1=原始,4/16=很局部 context

ATTACK_CLASS_WEIGHT = 3.0
O_CLASS_WEIGHT      = 1.0
FOCAL_GAMMA         = 2.0
O_DECODE_BIAS       = None
O_BIAS_SWEEP        = [0.0, 0.5, 1.0, 2.0, 4.0, 8.0]
RECALL_TOL          = 0.02

DATA_DIR      = "./Training_data/"
# 快取用獨立檔名:存的是 SAGA 表的索引,不能跟 base 索引的舊快取(train_data.pt)混用。
# 全新快取檔名(base 索引):不共用被舊實驗弄髒的 ./train_data.pt。
CACHE         = {"train": "./train_data_mc.pt", "valid": "./valid_data_mc.pt", "test": "./test_data_mc.pt"}
MODEL_SAVE    = "./multichunk_20260721/save_model"
RESULT_SAVE   = "./multichunk_20260721/save_result"
# ======================================================================

random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")
logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

with open("./relations.txt") as fp:
    relations = [r.strip() for r in fp.readlines()]
with open("./label2index_0201.pkl", "rb") as fp:
    label2index = pickle.load(fp)
with open("./index2label_0201.pkl", "rb") as fp:
    index2label = pickle.load(fp)
# 跟原始訓練 code 一致:訓練用 ./SecureBERT2.0-base(campaign 推論用 SAGA,就是能跑出 0.68 的設定)。
with open("./SecureBERT2.0-base/nodes/vocab2idx.pkl", "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open("./SecureBERT2.0-base/edges/vocab2idx.pkl", "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open("./SecureBERT2.0-base/nodes_ent2emb_256.pkl", "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open("./SecureBERT2.0-base/edges_ent2emb_16.pkl", "rb") as fp:
    edge_ent2emb = pickle.load(fp)

NODE_EMB_SIZE = 256
EDGE_EMB_SIZE = 16
EVENT_DIM = NODE_EMB_SIZE * 2 + EDGE_EMB_SIZE
OUTPUT_SIZE = len(label2index)
O_IDX = label2index.get("O", -1)

node_emb_tensor = torch.tensor(np.array(node_ent2emb), dtype=torch.float32).to(device)
edge_emb_tensor = torch.tensor(np.array(edge_ent2emb), dtype=torch.float32).to(device)
NODE_PAD_IDX = node_emb_tensor.shape[0]
EDGE_PAD_IDX = edge_emb_tensor.shape[0]
node_emb_tensor = torch.cat([node_emb_tensor, torch.zeros(1, NODE_EMB_SIZE).to(device)], dim=0)
edge_emb_tensor = torch.cat([edge_emb_tensor, torch.zeros(1, EDGE_EMB_SIZE).to(device)], dim=0)

type2attr = {"Process": "Cmdline", "File": "Name", "Registry": "Key", "Network": "Dstaddress"}


def get_value(event):
    srcType = event["srcNode"]["Type"]
    srcAttr = event["srcNode"][type2attr[srcType]]
    dstType = event["dstNode"]["Type"] if event["dstNode"] is not None else srcType
    dstAttr = event["dstNode"][type2attr[dstType]] if event["dstNode"] is not None else srcAttr
    return srcAttr, dstAttr, event["relation"], event["label"]


def make_dataset(dataset):
    processed = []
    for p in tqdm(dataset, desc="Processing files"):
        with open(p) as fp:
            events = json.load(fp)
        seq_src, seq_rel, seq_dst, seq_label, seq_mask = [], [], [], [], []
        for e in events:
            srcAttr, dstAttr, rel, label = get_value(e)
            if rel not in relations:
                continue
            seq_src.append(node_ent2idx.get(str(srcAttr), NODE_PAD_IDX))
            seq_rel.append(edge_ent2idx.get(rel, EDGE_PAD_IDX))
            seq_dst.append(node_ent2idx.get(str(dstAttr), NODE_PAD_IDX))
            seq_label.append(label2index.get(label, label2index["O"]))
            seq_mask.append(1)
        if len(seq_src) == 0:
            continue
        if len(seq_src) % WINDOW_SIZE != 0:
            pad_len = (WINDOW_SIZE - len(seq_src) if len(seq_src) < WINDOW_SIZE
                       else ((len(seq_src) - WINDOW_SIZE) // STRIDE + 1) * STRIDE + WINDOW_SIZE - len(seq_src))
            seq_src.extend([NODE_PAD_IDX] * pad_len)
            seq_rel.extend([EDGE_PAD_IDX] * pad_len)
            seq_dst.extend([NODE_PAD_IDX] * pad_len)
            seq_label.extend([label2index["O"]] * pad_len)
            seq_mask.extend([0] * pad_len)
        for i in range(0, len(seq_src) - WINDOW_SIZE + 1, STRIDE):
            processed.append({
                "src": torch.tensor(seq_src[i:i+WINDOW_SIZE], dtype=torch.long),
                "rel": torch.tensor(seq_rel[i:i+WINDOW_SIZE], dtype=torch.long),
                "dst": torch.tensor(seq_dst[i:i+WINDOW_SIZE], dtype=torch.long),
                "label_idx": torch.tensor(seq_label[i:i+WINDOW_SIZE], dtype=torch.long),
                "mask": torch.tensor(seq_mask[i:i+WINDOW_SIZE], dtype=torch.bool),
                "process": p,
            })
        del seq_src, seq_rel, seq_dst, seq_label, seq_mask
        gc.collect()
    return processed


def _torch_load(p):
    try:
        return torch.load(p, weights_only=False)
    except TypeError:
        return torch.load(p)


if all(os.path.exists(f) for f in CACHE.values()):
    logging.info("載入快取 dataset (*.pt) ...")
    train_data = _torch_load(CACHE["train"])
    valid_data = _torch_load(CACHE["valid"])
    test_data  = _torch_load(CACHE["test"])
else:
    trainset, validset, testset = [], [], []
    for ability in tqdm(os.listdir(DATA_DIR), desc="Splitting dataset"):
        paths = glob(f"{DATA_DIR}/{ability}/number_*/expanded_instance.json")
        random.shuffle(paths)
        trainset.extend(paths[:80]); validset.extend(paths[80:90]); testset.extend(paths[90:])
    train_data = make_dataset(trainset)
    valid_data = make_dataset(validset)
    test_data  = make_dataset(testset)
    torch.save(train_data, CACHE["train"])
    torch.save(valid_data, CACHE["valid"])
    torch.save(test_data,  CACHE["test"])

train_loader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True,  num_workers=4, pin_memory=True)
valid_loader = DataLoader(valid_data, batch_size=BATCH_SIZE, shuffle=False, num_workers=4, pin_memory=True)
test_loader  = DataLoader(test_data,  batch_size=BATCH_SIZE, shuffle=False, num_workers=4, pin_memory=True)


# ======================================================================
# Model
# ======================================================================
class FocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=2.0, reduction="mean"):
        super().__init__()
        self.weight = weight; self.gamma = gamma; self.reduction = reduction

    def forward(self, inputs, targets):
        ce = F.cross_entropy(inputs, targets, weight=self.weight, reduction="none")
        pt = torch.exp(-ce)
        focal = ((1 - pt) ** self.gamma) * ce
        return focal.mean() if self.reduction == "mean" else (focal.sum() if self.reduction == "sum" else focal)


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1), :]


def chunk_pool(x, mask_tensor, k):
    """以每個事件為中心、±k/2 視窗的 masked 平均池化(長度不變)。k<=1 直接回傳。"""
    if k <= 1:
        return x
    T = x.size(1)
    if mask_tensor is None:
        m = torch.ones(x.size(0), 1, T, device=x.device, dtype=x.dtype)
        xt = x.transpose(1, 2)
    else:
        m = mask_tensor.unsqueeze(1).to(x.dtype)
        xt = (x * mask_tensor.unsqueeze(-1).to(x.dtype)).transpose(1, 2)   # padding 位置歸零
    pad = k // 2
    s = F.avg_pool1d(xt, kernel_size=k, stride=1, padding=pad, count_include_pad=True) * k   # 視窗和
    c = F.avg_pool1d(m,  kernel_size=k, stride=1, padding=pad, count_include_pad=True) * k   # 視窗內有效數
    s = s[..., :T]; c = c[..., :T]          # 偶數 kernel 會多 1 格,裁回 T
    return (s / c.clamp(min=1.0)).transpose(1, 2)


class MultiChunk_Transformer_CRF(nn.Module):
    def __init__(self, embedding_dim, output_size, layers, nhead, device,
                 dropout=0.2, scales=CHUNK_SCALES):
        super().__init__()
        self.device = device
        self.tagset_size = output_size
        self.d_model = 512
        self.scales = tuple(scales)

        # 每個 chunk 尺度:自己的 input_proj + 自己的 transformer
        self.in_drop = nn.Dropout(0.15)   # 輸入 dropout:逼模型不死記單一特徵 → 對分布位移更穩、較能轉移
        self.input_proj = nn.ModuleList(
            [nn.Linear(embedding_dim, self.d_model) for _ in self.scales])
        self.pos_encoder = PositionalEncoding(self.d_model, max_len=1000)
        self.chunk_transformers = nn.ModuleList([
            nn.TransformerEncoder(
                nn.TransformerEncoderLayer(
                    d_model=self.d_model, nhead=nhead, dim_feedforward=self.d_model * 2,
                    dropout=dropout, batch_first=True),
                num_layers=layers)
            for _ in self.scales])
        self.fuse = nn.Linear(self.d_model * len(self.scales), self.d_model)
        self.fuse_norm = nn.LayerNorm(self.d_model)   # 穩住融合表徵 → emission 不會越train越大而爆掉(loss spike)
        self.hidden2tag = nn.Linear(self.d_model, output_size)
        self.crf = CRF(num_tags=output_size, batch_first=True)

        self.o_idx = label2index.get("O", -1)
        self.decode_o_bias = 0.0

        self.loss_weights = torch.ones(output_size).to(device) * ATTACK_CLASS_WEIGHT
        if self.o_idx != -1:
            self.loss_weights[self.o_idx] = O_CLASS_WEIGHT
        self.focal_loss = FocalLoss(weight=self.loss_weights, gamma=FOCAL_GAMMA)

    def emissions(self, x, mask_tensor=None):
        key_pad = ~mask_tensor if mask_tensor is not None else None
        x = self.in_drop(x)                # 輸入 dropout(eval 時自動關閉)
        outs = []
        for s, proj, tf in zip(self.scales, self.input_proj, self.chunk_transformers):
            h = self.pos_encoder(proj(chunk_pool(x, mask_tensor, s)))
            outs.append(tf(h, src_key_padding_mask=key_pad))
        return self.hidden2tag(self.fuse_norm(self.fuse(torch.cat(outs, dim=-1))))

    def compute_loss(self, feats, label_tensor, mask_tensor):
        # fp32 算 CRF/focal(避免 fp16 溢位 → 梯度 inf → 更新被跳過)
        with torch.autocast(device_type=feats.device.type, enabled=False):
            feats = feats.float()
            crf_loss = -self.crf(emissions=feats, tags=label_tensor, mask=mask_tensor, reduction="mean")
            active = mask_tensor.view(-1)
            foc = self.focal_loss(feats.view(-1, self.tagset_size)[active], label_tensor.view(-1)[active])
        return crf_loss + foc

    def decode(self, feats, mask_tensor, o_bias=None):
        b = self.decode_o_bias if o_bias is None else o_bias
        if b != 0.0 and self.o_idx != -1:
            feats = feats.clone()
            feats[:, :, self.o_idx] = feats[:, :, self.o_idx] + b
        return self.crf.decode(emissions=feats, mask=mask_tensor)

    def forward(self, sentence_tensor, label_tensor=None, mask_tensor=None):
        feats = self.emissions(sentence_tensor, mask_tensor)
        loss = self.compute_loss(feats, label_tensor, mask_tensor) if label_tensor is not None else None
        if self.training:
            return None, loss
        return self.decode(feats, mask_tensor), loss


model = MultiChunk_Transformer_CRF(EVENT_DIM, OUTPUT_SIZE, layers=2, nhead=8,
                                   device=device, dropout=0.3, scales=CHUNK_SCALES).to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-3)   # 1e-5→1e-3,對抗過擬合
# warmup + cosine（逐 step）
_total_steps = max(1, len(train_loader) * EPOCHS)
_warmup_steps = max(1, int(WARMUP_RATIO * _total_steps))
def _lr_lambda(step):
    if step < _warmup_steps:
        return step / _warmup_steps
    prog = (step - _warmup_steps) / max(1, _total_steps - _warmup_steps)
    return 0.5 * (1.0 + math.cos(math.pi * prog))
scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, _lr_lambda)
scaler = torch.amp.GradScaler("cuda")
os.makedirs(MODEL_SAVE, exist_ok=True)
logging.info(f"Multi-chunk scales={CHUNK_SCALES} (每個尺度一個 transformer)")

attack_labels_indices = [i for i in range(OUTPUT_SIZE) if i != O_IDX]


def _feat(data):
    src = data["src"].to(device, non_blocking=True)
    rel = data["rel"].to(device, non_blocking=True)
    dst = data["dst"].to(device, non_blocking=True)
    return torch.cat([node_emb_tensor[src], edge_emb_tensor[rel], node_emb_tensor[dst]], dim=-1)


@torch.no_grad()
def eval_sweep(loader, biases):
    """對每個 O-bias 收 attack macro P/R/F1。回傳 {bias: (P,R,F1)}。"""
    model.eval()
    trues_all, preds_by_bias = [], {b: [] for b in biases}
    for data in loader:
        feats = model.emissions(_feat(data), data["mask"].to(device, non_blocking=True))
        feats = feats.float()
        mask = data["mask"].to(device, non_blocking=True)
        label_cpu = data["label_idx"].cpu().tolist()
        for k, b in enumerate(biases):
            out = model.decode(feats, mask, o_bias=b)
            for idx, pred in enumerate(out):
                preds_by_bias[b].extend(pred)
                if k == 0:
                    trues_all.extend(label_cpu[idx][:len(pred)])
    rows = {}
    for b in biases:
        p, r, f, _ = precision_recall_fscore_support(
            trues_all, preds_by_bias[b], labels=attack_labels_indices, average="macro", zero_division=0)
        rows[b] = (p, r, f)
    return rows


def recommend_bias(rows, base_bias=0.0, recall_tol=RECALL_TOL):
    base_r = rows.get(base_bias, (0, 0, 0))[1]
    cands = [(b, v) for b, v in rows.items() if v[1] >= base_r - recall_tol]
    if not cands:
        return base_bias
    return max(cands, key=lambda x: (x[1][0], x[0]))[0]


# ======================================================================
# Train
# ======================================================================
best_val_atk_f1, best_model_path = float("-inf"), ""
for epoch in range(EPOCHS):
    model.train()
    train_losses = []
    for data in tqdm(train_loader, desc=f"Epoch {epoch} Train"):
        label = data["label_idx"].to(device, non_blocking=True)
        mask = data["mask"].to(device, non_blocking=True)
        optimizer.zero_grad()
        with torch.amp.autocast("cuda"):
            _, loss = model(_feat(data), label, mask)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=GRAD_CLIP)
        scaler.step(optimizer); scaler.update()
        scheduler.step()                     # warmup+cosine 逐 step
        train_losses.append(loss.item())

    rows = eval_sweep(valid_loader, O_BIAS_SWEEP)
    atk_p, atk_r, atk_f1 = rows[0.0]
    logging.info(f"Epoch:{epoch} | Train Loss:{np.mean(train_losses):.4f} | "
                 f"[base] Attack P:{atk_p:.4f} R:{atk_r:.4f} F1:{atk_f1:.4f}")
    for b in O_BIAS_SWEEP:
        p, r, f = rows[b]
        logging.info(f"      O-bias={b:>4}: P={p:.4f} R={r:.4f} F1={f:.4f}")
    if atk_f1 > best_val_atk_f1:
        best_val_atk_f1 = atk_f1
        best_model_path = f"{MODEL_SAVE}/epoch_{epoch}_AtkF1_{atk_f1:.4f}"
        torch.save(model.state_dict(), best_model_path)

# ======================================================================
# 選 O-bias (在 val、best model 上) → 套 test
# ======================================================================
if best_model_path:
    model.load_state_dict(torch.load(best_model_path))
logging.info("=== 決定 deploy O-bias (val, best model) ===")
val_rows = eval_sweep(valid_loader, O_BIAS_SWEEP)
for b in O_BIAS_SWEEP:
    p, r, f = val_rows[b]
    logging.info(f"   O-bias={b:>4}: P={p:.4f} R={r:.4f} F1={f:.4f}")
deploy_bias = O_DECODE_BIAS if O_DECODE_BIAS is not None else recommend_bias(val_rows)
logging.info(f"=> deploy O-bias = {deploy_bias}  (recall 相對 base 不掉 >{RECALL_TOL})")

test_rows = eval_sweep(test_loader, sorted(set([0.0, deploy_bias])))
tp0, tr0, tf0 = test_rows[0.0]
tp, tr, tf = test_rows[deploy_bias]
logging.info(f"[TEST base   O-bias=0        ] Attack P:{tp0:.4f} R:{tr0:.4f} F1:{tf0:.4f}")
logging.info(f"[TEST deploy O-bias={deploy_bias:<4}] Attack P:{tp:.4f} R:{tr:.4f} F1:{tf:.4f}")

model.decode_o_bias = deploy_bias
all_predict, all_label = [], []
model.eval()
with torch.no_grad():
    for data in tqdm(test_loader, desc="Testing (deploy bias)"):
        label = data["label_idx"].to(device, non_blocking=True)
        mask = data["mask"].to(device, non_blocking=True)
        with torch.amp.autocast("cuda"):
            out, _ = model(_feat(data), None, mask)
        label_cpu = label.cpu().tolist()
        for idx, pred in enumerate(out):
            all_predict.extend(pred)
            all_label.extend(label_cpu[idx][:len(pred)])

os.makedirs(RESULT_SAVE, exist_ok=True)
report = classification_report(all_label, all_predict, output_dict=True, zero_division=0)
df = pd.DataFrame(report).transpose().reset_index(names="label")
df["label"] = df["label"].apply(lambda x: index2label.get(int(x), x) if str(x).isdigit() else x)
df.to_csv(f"{RESULT_SAVE}/result.csv", index=False)
logging.info(f"saved {RESULT_SAVE}/result.csv  (deploy O-bias={deploy_bias})")

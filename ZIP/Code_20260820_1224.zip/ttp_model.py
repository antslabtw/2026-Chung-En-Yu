# -*- coding: utf-8 -*-
"""
ttp_model.py — TTP tagger 的「唯一」模型定義 (train 與 infer 都 import 這支)。

這樣 training 與 inference 不會再各自維護一份 Transformer_CRF 而 drift。
架構 = [結構化 528 (+LLM PCA) event 向量] → MultiChunk(時間) 或 MultiHop(圖) → +PE
       → Transformer encoder → hidden2tag → CRF。
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchcrf import CRF

from multi_chunk import MultiChunk
from multi_hop import MultiHop

STRUCT_DIM = 256 * 2 + 16   # 528 (node256 ⊕ edge16 ⊕ node256)


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=1000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1), :]


class FocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=2.0):
        super().__init__()
        self.weight = weight
        self.gamma = gamma

    def forward(self, inputs, targets):
        ce = F.cross_entropy(inputs, targets, weight=self.weight, reduction="none")
        pt = torch.exp(-ce)
        return (((1 - pt) ** self.gamma) * ce).mean()


def build_event_feats(src, rel, dst, node_emb, edge_emb, llm_emb=None):
    """每個 event 的輸入向量。
        struct = node_emb[src] ⊕ edge_emb[rel] ⊕ node_emb[dst]              (528)
        +LLM   = ⊕ llm_emb[src] ⊕ llm_emb[dst]  (LLM 敘述→SecureBERT→PCA，node 級查表)
    src/rel/dst: [B,T] long。回傳 [B,T, 528 (+2*llm_dim)]。
    """
    feats = torch.cat([node_emb[src], edge_emb[rel], node_emb[dst]], dim=-1)
    if llm_emb is not None:
        feats = torch.cat([feats, llm_emb[src], llm_emb[dst]], dim=-1)
    return feats


class TTP_Model(nn.Module):
    def __init__(self, in_dim, output_size, chunk_kind, scales, node_pad_idx,
                 layers=2, nhead=8, d_model=512, dropout=0.2,
                 class_weights=None, o_idx=-1, focal_gamma=2.0, graph_mode="shared"):
        super().__init__()
        self.chunk_kind = chunk_kind
        self.d_model = d_model
        self.tagset_size = output_size
        self.o_idx = o_idx
        self.decode_o_bias = 0.0

        # 前處理器 = input projection + 多尺度摘要 (時間 chunk 或 圖 hop)
        # hop 的圖 key(ga,gb)由外部給:SFM=srcUUID/dstUUID(shared)、KELLECT=PID/PPID(tree)
        if chunk_kind == "temporal":
            self.preproc = MultiChunk(d_in=in_dim, d_out=d_model, scales=tuple(scales),
                                      mode="conv", masked=True, learnable_gate=True)
        elif chunk_kind == "hop":
            self.preproc = MultiHop(d_in=in_dim, d_out=d_model, hops=tuple(scales),
                                    graph_mode=graph_mode, masked=True, learnable_gate=True)
        else:
            raise ValueError(f"chunk_kind must be 'temporal' or 'hop', got {chunk_kind}")

        self.pos_encoder = PositionalEncoding(d_model, max_len=1000)
        enc = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead,
                                         dim_feedforward=d_model * 2, dropout=dropout,
                                         batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(enc, num_layers=layers)
        self.hidden2tag = nn.Linear(d_model, output_size)
        self.crf = CRF(num_tags=output_size, batch_first=True)
        self.focal_loss = FocalLoss(weight=class_weights, gamma=focal_gamma)

    def emissions(self, x, ga, gb, mask):
        # ga,gb = 圖節點 id (hop 用);temporal 不用
        h = self.preproc(x, mask) if self.chunk_kind == "temporal" \
            else self.preproc(x, ga, gb, mask)
        h = self.pos_encoder(h)
        out = self.transformer_encoder(h, src_key_padding_mask=~mask)
        return self.hidden2tag(out)

    def compute_loss(self, feats, label, mask):
        # fp16 autocast 下 CRF 的 logsumexp 會 overflow → loss 後期反彈/發散、F1 上不去。
        # 關 autocast、轉 fp32 再算 CRF/focal (純數值安全，只會更穩不會更差)。
        with torch.autocast(device_type=feats.device.type, enabled=False):
            feats = feats.float()
            crf_loss = -self.crf(emissions=feats, tags=label, mask=mask, reduction="mean")
            active = mask.view(-1)
            foc = self.focal_loss(feats.view(-1, self.tagset_size)[active], label.view(-1)[active])
        return crf_loss + foc

    def decode(self, feats, mask, o_bias=None):
        b = self.decode_o_bias if o_bias is None else o_bias
        if b != 0.0 and self.o_idx != -1:
            feats = feats.clone()
            feats[:, :, self.o_idx] = feats[:, :, self.o_idx] + b
        return self.crf.decode(emissions=feats, mask=mask)

    def forward(self, x, ga, gb, label=None, mask=None):
        feats = self.emissions(x, ga, gb, mask)
        loss = self.compute_loss(feats, label, mask) if label is not None else None
        if self.training:
            return None, loss
        return self.decode(feats, mask), loss


def scales_for(chunk_kind):
    """兩個版本的預設尺度。"""
    return (256, 64, 16) if chunk_kind == "temporal" else (3, 2, 1)

"""SecureBERT 2.0 embedding pipeline (取代 Make_embedding20240205.ipynb)。

流程:
    1. 從 ./RawData/Training_data/*/number_*/expanded_instance.json 收集 nodes / edges 詞表
    2. 用 cisco-ai/SecureBERT2.0-base 做 mean-pooled embedding
    3. 分 chunk 存 .npy
    4. (選擇) PCA 降維成 nodes_ent2emb_256.pkl / edges_ent2emb_16.pkl（給 SFM 下游用）
       或存 L2-normalized full-dim (768) 的 *_ent2emb_full.pkl（給 no-PCA 路徑用）

用法:
    python make_embedding.py                       # 預設 SecureBERT2.0 + PCA(256/16)
    python make_embedding.py --no_pca              # 存 full-dim + L2-normalized
    python make_embedding.py --model cisco-ai/SecureBERT2.0-base --save_dir ./SecureBERT2.0-base
"""
import os, math, json, pickle, logging, argparse
import numpy as np
from glob import glob
from tqdm import tqdm

import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.decomposition import PCA

logging.basicConfig(format='%(asctime)s | %(levelname)s | %(message)s',
                    level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S')

TYPE2ATTR = {"Process": "Cmdline", "File": "Name",
             "Registry": "Key", "Network": "Dstaddress"}


# ---------------------------------------------------------------------------
# 1. Vocabulary collection
# ---------------------------------------------------------------------------
def collect_vocab(training_glob: str, relations: set):
    nodes, edges = set(), set()
    paths = glob(training_glob)
    if not paths:
        raise FileNotFoundError(
            f"training_glob 沒有比對到任何檔案:\n  {training_glob}\n"
            f"cwd={os.getcwd()}\n"
            f"檢查資料是否掛在這個路徑，或用 --training_glob '/absolute/path/*/number_*/expanded_instance.json' 指定")
    logging.info(f"matched {len(paths)} training files")
    for p in tqdm(paths, total=len(paths), desc="collect vocab"):
        with open(p) as fp:
            events = json.load(fp)
        for e in events:
            if e["relation"] not in relations:
                continue
            src_t = e["srcNode"]["Type"]
            nodes.add(str(e["srcNode"][TYPE2ATTR[src_t]]))
            if e["dstNode"] is not None:
                dst_t = e["dstNode"]["Type"]
                nodes.add(str(e["dstNode"][TYPE2ATTR[dst_t]]))
            edges.add(e["relation"])
    logging.info(f"Nodes: {len(nodes)}  Edges: {len(edges)}")
    return sorted(nodes), sorted(edges)


# ---------------------------------------------------------------------------
# 2. SecureBERT 2.0 mean-pooled embedding (streaming chunk save)
# ---------------------------------------------------------------------------
def make_embedding_securebert2(vocab, save_path, tokenizer, model, device,
                               batch_size=128, batch_chunk_size=100,
                               max_length=1024):
    """Per-batch tokenize + embed. 避免:
    (1) 上游一次 tokenize 82 萬條 → RAM 爆 & IndexError
    (2) padding=True 對全 vocab 拿最長那條當長度 → 極度浪費
    (3) 空字串觸發 tokenizer edge case
    """
    os.makedirs(save_path, exist_ok=True)

    # 過濾 None、空字串、非字串（tokenizer 對空字串在新版 transformers 會炸）
    clean = []
    for v in vocab:
        if v is None: continue
        s = str(v)
        if len(s) == 0: continue
        clean.append(s)
    if len(clean) < len(vocab):
        logging.warning(f"filtered {len(vocab)-len(clean)} empty/None entries from vocab")
    if not clean:
        logging.error(f"vocab is empty for {save_path} — aborting embed")
        return

    vocab2idx = {v: idx for idx, v in enumerate(clean)}
    with open(os.path.join(save_path, "vocab2idx.pkl"), "wb") as fp:
        pickle.dump(vocab2idx, fp)
    logging.info(f"[✓] saved {save_path}/vocab2idx.pkl (size={len(clean)})")

    embeddings, batches = [], math.ceil(len(clean) / batch_size)
    for i in tqdm(range(batches), desc=f"embed {os.path.basename(save_path)}"):
        s, e = i * batch_size, min((i + 1) * batch_size, len(clean))
        batch_texts = clean[s:e]
        if not batch_texts:
            continue

        # 每個 batch 各自 pad 到 batch 內最長，記憶體省一大截
        enc = tokenizer(batch_texts, padding=True, truncation=True,
                        max_length=max_length, return_tensors="pt")
        ids  = enc["input_ids"].to(device)
        mask = enc["attention_mask"].to(device)

        with torch.no_grad():
            out = model(input_ids=ids, attention_mask=mask)
            hs  = out.last_hidden_state                      # [B, T, H]
            m3  = mask.unsqueeze(-1).float()                 # [B, T, 1]
            summed = (hs * m3).sum(dim=1)                    # [B, H]
            counts = m3.sum(dim=1).clamp(min=1e-9)
            avg    = summed / counts                         # [B, H]

        embeddings.append(avg.detach().cpu().numpy())

        if ((i + 1) % batch_chunk_size == 0) or i == batches - 1:
            arr = np.concatenate(embeddings, axis=0)
            chunk_id = i // batch_chunk_size
            np.save(os.path.join(save_path, f"embeddings_chunk_{chunk_id}.npy"), arr)
            logging.info(f"[✓] saved embeddings_chunk_{chunk_id}.npy shape={arr.shape}")
            embeddings = []


# ---------------------------------------------------------------------------
# 3. 拼回完整矩陣 + (PCA or L2-normalize)
# ---------------------------------------------------------------------------
def _numeric(path: str) -> int:
    return int(path.split("_")[-1].split(".")[0])


def _load_all_chunks(save_path: str, ent_type: str) -> np.ndarray:
    pattern = f"{save_path}/{ent_type}/embeddings_chunk_*.npy"
    paths = sorted(glob(pattern), key=_numeric)
    if not paths:
        raise FileNotFoundError(
            f"沒有找到任何 embedding chunk: {pattern}\n"
            f"代表上一階段 make_embedding_securebert2 沒有實際產出檔案。\n"
            f"檢查:\n"
            f"  1. collect_vocab 是否有拿到資料 (log 應顯示 'matched N training files')\n"
            f"  2. {save_path}/{ent_type}/ 底下有沒有 vocab2idx.pkl (有就代表 vocab 收集到了)\n"
            f"  3. 是否上一步 tokenizer 中途 crash 沒印錯誤 (用 --batch_size 32 重跑試)")
    return np.concatenate([np.load(p) for p in paths], axis=0).astype(np.float32)


def make_pca_embedding(save_path: str, ent_type: str, size: int, pca_model_path: str):
    emb = _load_all_chunks(save_path, ent_type)
    pca = PCA(n_components=size)
    reduced = pca.fit_transform(emb)
    logging.info(f"[PCA] {ent_type}: {emb.shape} -> {reduced.shape}")
    os.makedirs(os.path.dirname(pca_model_path), exist_ok=True)
    with open(pca_model_path, "wb") as fp:
        pickle.dump(pca, fp)
    out_pkl = f"{save_path}/{ent_type}_ent2emb_{size}.pkl"
    with open(out_pkl, "wb") as fp:
        pickle.dump(reduced, fp)
    logging.info(f"[✓] saved {out_pkl}")


def make_full_embedding(save_path: str, ent_type: str):
    emb = _load_all_chunks(save_path, ent_type)
    norms = np.linalg.norm(emb, axis=1, keepdims=True).clip(min=1e-9)
    emb = emb / norms
    logging.info(f"[FULL] {ent_type}: shape={emb.shape} (L2-normalized)")
    out_pkl = f"{save_path}/{ent_type}_ent2emb_full.pkl"
    with open(out_pkl, "wb") as fp:
        pickle.dump(emb, fp)
    logging.info(f"[✓] saved {out_pkl}")
    return emb.shape[1]


# ---------------------------------------------------------------------------
# 4. Main
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 4. Main
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="cisco-ai/SecureBERT2.0-base")
    ap.add_argument("--save_dir", default="./SecureBERT2.0-base")
    ap.add_argument("--relations_txt", default="./relations.txt")
    ap.add_argument("--training_glob",
                    default="./RawData/Training_data/*/number_*/expanded_instance.json")
    ap.add_argument("--node_pca_dim", type=int, default=256)
    ap.add_argument("--edge_pca_dim", type=int, default=16)
    ap.add_argument("--no_pca", action="store_true",
                    help="不做 PCA，改存 L2-normalized 完整維度 (*_ent2emb_full.pkl)")
    
    # 新增這行：專門用來跳過推論的開關
    ap.add_argument("--pca_only", action="store_true",
                    help="跳過模型推論，直接讀取現有 chunk 進行 PCA")
    
    ap.add_argument("--batch_size", type=int, default=128)
    ap.add_argument("--max_length", type=int, default=1024)
    args = ap.parse_args()

    # 如果不是 pca_only，才需要跑前面超耗時的步驟
    if not args.pca_only:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        logging.info(f"device={device}  torch={torch.__version__}")
        if torch.cuda.is_available():
            logging.info(f"gpu={torch.cuda.get_device_name(0)}  cuda={torch.version.cuda}")

        # --- 1. relations & vocab ---
        with open(args.relations_txt) as fp:
            relations = {r.strip() for r in fp if r.strip()}
        
        nodes, edges = collect_vocab(args.training_glob, relations)
        if not nodes or not edges:
            raise RuntimeError("vocab 空的，請檢查路徑或 relations.txt")

        # --- 2. load SecureBERT 2.0 ---
        logging.info(f"loading {args.model} ...")
        tokenizer = AutoTokenizer.from_pretrained(args.model)
        model = AutoModel.from_pretrained(args.model, trust_remote_code=True).to(device)
        model.eval()

        os.makedirs(args.save_dir, exist_ok=True)

        # --- 3. embed nodes & edges ---
        make_embedding_securebert2(
            nodes, os.path.join(args.save_dir, "nodes"),
            tokenizer, model, device,
            batch_size=args.batch_size, max_length=args.max_length)

        make_embedding_securebert2(
            edges, os.path.join(args.save_dir, "edges"),
            tokenizer, model, device,
            batch_size=args.batch_size, max_length=args.max_length)

    # --- 4. dim reduction (PCA or Full) ---
    logging.info("開始進行降維 / 矩陣合併程序...")
    if args.no_pca:
        make_full_embedding(args.save_dir, "nodes")
        make_full_embedding(args.save_dir, "edges")
    else:
        os.makedirs("./model", exist_ok=True)
        make_pca_embedding(args.save_dir, "nodes", args.node_pca_dim,
                           "./model/pca_model_nodes.pkl")
        make_pca_embedding(args.save_dir, "edges", args.edge_pca_dim,
                           "./model/pca_model_edges.pkl")

    logging.info("Done.")

if __name__ == "__main__":
    main()

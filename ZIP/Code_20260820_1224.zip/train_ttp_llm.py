# -*- coding: utf-8 -*-
"""train_ttp_llm.py — run_all.sh 需要的訓練器(temporal / hop × 有無 LLM)。

早期 run_all.sh 呼叫的是 `train_ttp_conservative.py --chunk_kind ... --use_llm ...`,
但 train_ttp_conservative.py 已還原成沒有這些參數的原始版本 → run_all.sh 失去訓練器。
本檔把那個介面補回來,**不動 train_ttp_conservative.py**。

模型 = ttp_model.TTP_Model(共用模組,train/infer 不 drift)
存檔 = {"cfg":..., "model": state_dict} → 凍結的 infer_saga_llm.py 直接可讀
        ./Trans_CRF0706/save_model/best_{temporal,hop}_llm{tag_suffix}.pt

用法(與 run_all.sh 一致):
    python train_ttp_llm.py --chunk_kind temporal --use_llm 1 --llm_dir ./SecureBERT2.0-base-qwen \
        --tag_suffix _qwen --epochs 10
"""
import os, json, glob, random, pickle, logging, gc, argparse
import numpy as np
from tqdm import tqdm
from sklearn.metrics import precision_recall_fscore_support

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from ttp_model import TTP_Model, build_event_feats, scales_for

ap = argparse.ArgumentParser()
ap.add_argument("--chunk_kind", default="temporal", choices=["temporal", "hop", "hop_parallel"])
ap.add_argument("--scales", default=None, help="逗號分隔;預設 temporal=256,64,16 / hop=3,2,1")
ap.add_argument("--use_llm", type=int, default=1)
ap.add_argument("--llm_dir", default="./SecureBERT2.0-base")
ap.add_argument("--tag_suffix", default="", help="checkpoint 檔名後綴,如 _qwen")
ap.add_argument("--epochs", type=int, default=10)
ap.add_argument("--batch_size", type=int, default=None, help="預設 temporal=64 / hop=32(hop 要建 LxL 鄰接)")
ap.add_argument("--lr", type=float, default=5e-5)
ap.add_argument("--save_dir", default="./Trans_CRF0706/save_model")
ap.add_argument("--seed", type=int, default=42,
                help="隨機種子;同架構換 seed 在 SAGA 上差異很大,重訓要跑多個")
ap.add_argument("--graph_mode", default="shared", choices=["shared", "tree"])
ap.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
ap.add_argument("--emb_dir", default="./SecureBERT2.0-base", help="結構 node/edge 表目錄")
# ---- 降維:PCA 欄位已依變異排序,取前 k 欄 == 直接用 PCA(k) → 只需切片,不用重算 ----
ap.add_argument("--node_dim", type=int, default=0, help="0=用表原本的維度;>0=只取前 k 欄")
ap.add_argument("--edge_dim", type=int, default=0, help="同上")
ap.add_argument("--llm_dim", type=int, default=0, help="同上(LLM node 表)")
args = ap.parse_args()

SEED, WINDOW_SIZE, STRIDE = args.seed, 256, 32
ATTACK_CLASS_WEIGHT, O_CLASS_WEIGHT, FOCAL_GAMMA = 3.0, 1.0, 2.0
O_BIAS_SWEEP = [0.0, 1.0, 2.0, 4.0, 6.0, 8.0]
DATA_DIR = "./Training_data/"
CACHE_DIR = "./ttp_llm_cache"          # 含 ga/gb 的快取(hop 要用),temporal 也共用

SCALES = tuple(int(x) for x in args.scales.split(",")) if args.scales else scales_for(
    "temporal" if args.chunk_kind == "temporal" else "hop")
BATCH = args.batch_size or (64 if args.chunk_kind == "temporal" else 32)

random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")
device = (torch.device("cpu") if args.device == "cpu"
          else torch.device("cuda") if args.device == "cuda"
          else torch.device("cuda" if torch.cuda.is_available() else "cpu"))
logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s", level=logging.INFO, datefmt="%H:%M:%S")
logging.info(f"chunk_kind={args.chunk_kind} scales={SCALES} use_llm={args.use_llm} "
             f"llm_dir={args.llm_dir} tag={args.tag_suffix} device={device}")

with open("./relations.txt") as fp:
    relations = [r.strip() for r in fp.readlines()]
with open("./label2index_0201.pkl", "rb") as fp:
    label2index = pickle.load(fp)
with open(f"{args.emb_dir}/nodes/vocab2idx.pkl", "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(f"{args.emb_dir}/edges/vocab2idx.pkl", "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(f"{args.emb_dir}/nodes_ent2emb_256.pkl", "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(f"{args.emb_dir}/edges_ent2emb_16.pkl", "rb") as fp:
    edge_ent2emb = pickle.load(fp)

OUTPUT_SIZE = len(label2index)
O_IDX = label2index.get("O", -1)


def _slice(a, k, tag):
    """取前 k 欄(k<=0 或 >=原維度 → 不動)。PCA 欄位已依變異排序,等價於直接用 PCA(k)。"""
    a = np.asarray(a, dtype=np.float32)
    if 0 < k < a.shape[1]:
        logging.info(f"降維 {tag}: {a.shape[1]} → {k}")
        return a[:, :k]
    return a


node_arr = _slice(node_ent2emb, args.node_dim, "node")
edge_arr = _slice(edge_ent2emb, args.edge_dim, "edge")
NODE_EMB_SIZE, EDGE_EMB_SIZE = node_arr.shape[1], edge_arr.shape[1]

node_emb = torch.tensor(node_arr, dtype=torch.float32).to(device)
edge_emb = torch.tensor(edge_arr, dtype=torch.float32).to(device)
NODE_PAD_IDX, EDGE_PAD_IDX = node_emb.shape[0], edge_emb.shape[0]
node_emb = torch.cat([node_emb, torch.zeros(1, NODE_EMB_SIZE).to(device)], 0)
edge_emb = torch.cat([edge_emb, torch.zeros(1, EDGE_EMB_SIZE).to(device)], 0)

llm_emb, LLM_PCA = None, 0
if args.use_llm:
    with open(f"{args.llm_dir}/llm_node_vocab2idx.pkl", "rb") as fp:
        llm_v2i = pickle.load(fp)
    cand = sorted(glob.glob(f"{args.llm_dir}/llm_node_ent2emb_*.pkl"))
    assert cand, f"{args.llm_dir} 沒有 llm_node_ent2emb_*.pkl"
    with open(cand[-1], "rb") as fp:
        arr = _slice(pickle.load(fp), args.llm_dim, "llm")
    LLM_PCA = arr.shape[1]
    t = torch.zeros(node_emb.shape[0], LLM_PCA)
    hit = 0
    for s, i in node_ent2idx.items():
        j = llm_v2i.get(s)
        if j is not None and j < len(arr):
            t[i] = torch.from_numpy(arr[j]); hit += 1
    llm_emb = t.to(device)
    logging.info(f"LLM 表 {cand[-1]} dim={LLM_PCA} 命中 {hit}/{len(node_ent2idx)}")

COMBINED_DIM = NODE_EMB_SIZE * 2 + EDGE_EMB_SIZE + (2 * LLM_PCA if args.use_llm else 0)
type2attr = {"Process": "Cmdline", "File": "Name", "Registry": "Key", "Network": "Dstaddress"}


def make_dataset(paths):
    out, miss = [], 0
    for p in tqdm(paths, desc="Processing"):
        with open(p) as fp:
            events = json.load(fp)
        uuid2id = {}
        ss, rr, dd, ll, mm, ga, gb = [], [], [], [], [], [], []
        for e in events:
            rel = e["relation"]
            if rel not in relations:
                continue
            st = e["srcNode"]["Type"]; sa = e["srcNode"][type2attr[st]]
            dn = e["dstNode"]
            dt = dn["Type"] if dn is not None else st
            da = dn[type2attr[dt]] if dn is not None else sa
            su = e["srcNode"].get("UUID")
            du = dn.get("UUID") if dn is not None else None
            if su is None:
                miss += 1
            ss.append(node_ent2idx.get(str(sa), NODE_PAD_IDX))
            rr.append(edge_ent2idx.get(rel, EDGE_PAD_IDX))
            dd.append(node_ent2idx.get(str(da), NODE_PAD_IDX))
            ll.append(label2index.get(e["label"], label2index["O"])); mm.append(1)
            ga.append(uuid2id.setdefault(su, len(uuid2id)) if su is not None else -1)
            gb.append(uuid2id.setdefault(du, len(uuid2id)) if du is not None else -1)
        if not ss:
            continue
        if len(ss) % WINDOW_SIZE != 0:
            pad = (WINDOW_SIZE - len(ss) if len(ss) < WINDOW_SIZE
                   else ((len(ss) - WINDOW_SIZE) // STRIDE + 1) * STRIDE + WINDOW_SIZE - len(ss))
            ss += [NODE_PAD_IDX]*pad; rr += [EDGE_PAD_IDX]*pad; dd += [NODE_PAD_IDX]*pad
            ll += [label2index["O"]]*pad; mm += [0]*pad; ga += [-1]*pad; gb += [-1]*pad
        for i in range(0, len(ss) - WINDOW_SIZE + 1, STRIDE):
            out.append({"src": torch.tensor(ss[i:i+WINDOW_SIZE], dtype=torch.long),
                        "rel": torch.tensor(rr[i:i+WINDOW_SIZE], dtype=torch.long),
                        "dst": torch.tensor(dd[i:i+WINDOW_SIZE], dtype=torch.long),
                        "label_idx": torch.tensor(ll[i:i+WINDOW_SIZE], dtype=torch.long),
                        "mask": torch.tensor(mm[i:i+WINDOW_SIZE], dtype=torch.bool),
                        "ga": torch.tensor(ga[i:i+WINDOW_SIZE], dtype=torch.long),
                        "gb": torch.tensor(gb[i:i+WINDOW_SIZE], dtype=torch.long)})
        del ss, rr, dd, ll, mm, ga, gb; gc.collect()
    if miss:
        logging.warning(f"{miss} 個 event 缺 srcNode.UUID → hop 在那些位置不建邊")
    return out


def _tl(p):
    try:
        return torch.load(p, weights_only=False)
    except TypeError:
        return torch.load(p)


os.makedirs(CACHE_DIR, exist_ok=True)
CACHE = {k: f"{CACHE_DIR}/{k}.pt" for k in ("train", "valid")}
if all(os.path.exists(f) for f in CACHE.values()):
    logging.info("載入快取 ...")
    train_data, valid_data = _tl(CACHE["train"]), _tl(CACHE["valid"])
else:
    rs = random.Random(1234)
    tr, va = [], []
    for ab in tqdm(sorted(os.listdir(DATA_DIR)), desc="Split"):
        paths = sorted(glob.glob(f"{DATA_DIR}/{ab}/number_*/expanded_instance.json"))
        rs.shuffle(paths)
        tr += paths[:80]; va += paths[80:90]
    train_data, valid_data = make_dataset(tr), make_dataset(va)
    torch.save(train_data, CACHE["train"]); torch.save(valid_data, CACHE["valid"])

train_loader = DataLoader(train_data, batch_size=BATCH, shuffle=True, num_workers=4, pin_memory=True)
valid_loader = DataLoader(valid_data, batch_size=BATCH, shuffle=False, num_workers=2, pin_memory=True)
logging.info(f"train={len(train_data)} valid={len(valid_data)} combined_dim={COMBINED_DIM} batch={BATCH}")

cw = torch.ones(OUTPUT_SIZE) * ATTACK_CLASS_WEIGHT
if O_IDX != -1:
    cw[O_IDX] = O_CLASS_WEIGHT
model = TTP_Model(COMBINED_DIM, OUTPUT_SIZE, args.chunk_kind, SCALES, NODE_PAD_IDX,
                  class_weights=cw.to(device), o_idx=O_IDX, focal_gamma=FOCAL_GAMMA,
                  graph_mode=args.graph_mode).to(device)
n_param = sum(p.numel() for p in model.parameters())
logging.info(f"TTP_Model({args.chunk_kind}, scales={SCALES}) 參數量={n_param:,}")

optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-5)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)
use_amp = device.type == "cuda"
scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
attack_idx = [i for i in range(OUTPUT_SIZE) if i != O_IDX]


def _feat(d):
    src = d["src"].to(device, non_blocking=True)
    rel = d["rel"].to(device, non_blocking=True)
    dst = d["dst"].to(device, non_blocking=True)
    return build_event_feats(src, rel, dst, node_emb, edge_emb, llm_emb)


@torch.no_grad()
def eval_sweep(loader, biases):
    model.eval()
    trues, preds = [], {b: [] for b in biases}
    for d in loader:
        mask = d["mask"].to(device, non_blocking=True)
        ga = d["ga"].to(device, non_blocking=True); gb = d["gb"].to(device, non_blocking=True)
        feats = model.emissions(_feat(d), ga, gb, mask).float()
        lab = d["label_idx"].cpu().tolist()
        for k, b in enumerate(biases):
            for i, pr in enumerate(model.decode(feats, mask, o_bias=b)):
                preds[b].extend(pr)
                if k == 0:
                    trues.extend(lab[i][:len(pr)])
    rows = {}
    for b in biases:
        p, r, f, _ = precision_recall_fscore_support(trues, preds[b], labels=attack_idx,
                                                     average="macro", zero_division=0)
        rows[b] = (p, r, f)
    return rows


os.makedirs(args.save_dir, exist_ok=True)
out_path = os.path.join(args.save_dir, f"best_{args.chunk_kind}_llm{args.tag_suffix}.pt")

# ★ out_path 是**固定檔名** —— 沒換 --tag_suffix 再跑一次就會覆蓋掉上一次的成果。
#   本專案 t2 的原始 checkpoint 就是這樣不見的(t1/t5 用 epoch+分數命名,所以還在)。
#   修法:
#     1. 每次進步都另存一個帶 epoch+分數的唯一檔名 → 永遠不會被蓋
#     2. 固定檔名照舊維護(既有腳本與文件都引用它),但**先把舊的備份成 .bak_<時間>**
#   要關掉備份(確定不需要舊檔):NO_CKPT_BACKUP=1
import shutil as _shutil
from datetime import datetime as _dt
_BACKUP = os.environ.get("NO_CKPT_BACKUP") != "1"
if _BACKUP and os.path.exists(out_path):
    _bak = f"{out_path}.bak_{_dt.now():%Y%m%d_%H%M%S}"
    _shutil.copy2(out_path, _bak)
    logging.warning(f"★ {os.path.basename(out_path)} 已存在 → 先備份成 {os.path.basename(_bak)}")
    logging.warning("  (固定檔名會被本次訓練覆蓋;NO_CKPT_BACKUP=1 可關掉備份)")
cfg = {"combined_dim": COMBINED_DIM, "output_size": OUTPUT_SIZE, "chunk_kind": args.chunk_kind,
       "scales": list(SCALES), "node_pad_idx": NODE_PAD_IDX, "o_idx": O_IDX,
       "graph_mode": args.graph_mode, "use_llm": int(args.use_llm), "emb_mode": "aux",
       "llm_dir": args.llm_dir, "llm_pca": LLM_PCA, "n_param": n_param,
       # 推論端要用完全相同的切片,存進 cfg 才不會 drift
       "node_dim": NODE_EMB_SIZE, "edge_dim": EDGE_EMB_SIZE, "emb_dir": args.emb_dir}

best_f1, best_bias = float("-inf"), 0.0
for epoch in range(args.epochs):
    model.train(); losses = []
    for d in tqdm(train_loader, desc=f"{args.chunk_kind}{args.tag_suffix} ep{epoch}"):
        label = d["label_idx"].to(device, non_blocking=True)
        mask = d["mask"].to(device, non_blocking=True)
        ga = d["ga"].to(device, non_blocking=True); gb = d["gb"].to(device, non_blocking=True)
        optimizer.zero_grad()
        with torch.amp.autocast("cuda", enabled=use_amp):
            feats = model.emissions(_feat(d), ga, gb, mask)
            loss = model.compute_loss(feats, label, mask)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(optimizer); scaler.update()
        losses.append(loss.item())
    scheduler.step()

    rows = eval_sweep(valid_loader, O_BIAS_SWEEP)
    bb = max(rows, key=lambda b: rows[b][2])
    p, r, f = rows[bb]
    logging.info(f"Epoch:{epoch} | Loss:{np.mean(losses):.4f} | "
                 f"valid 攻擊 F1={f:.4f} @O-bias={bb} (P={p:.4f} R={r:.4f})")
    if f > best_f1:
        best_f1, best_bias = f, bb
        cfg["deploy_bias"] = bb
        _blob = {"cfg": cfg, "model": model.state_dict(), "valid_f1": f, "epoch": epoch}
        # 唯一檔名:帶 epoch + 分數,任何後續訓練都不會蓋到它
        uniq_path = os.path.join(
            args.save_dir,
            f"{args.chunk_kind}_llm{args.tag_suffix}_ep{epoch}_valF1_{f:.4f}.pt")
        torch.save(_blob, uniq_path)
        torch.save(_blob, out_path)          # 固定檔名:相容既有腳本/文件
        logging.info(f"    ↑ 存檔 {os.path.basename(uniq_path)}(唯一)"
                     f" + {os.path.basename(out_path)}(固定)")

logging.info("=" * 72)
logging.info(f"[{args.chunk_kind}{args.tag_suffix}] best valid F1={best_f1:.4f} @O-bias={best_bias}")
logging.info(f"ckpt={out_path}")
logging.info(f"      同內容的唯一檔名也在 {args.save_dir}/ 裡(*_ep*_valF1_*.pt),不會被覆蓋")
logging.info(f"推論:python infer_saga_llm.py --ckpt {out_path} --llm_dir {args.llm_dir}")

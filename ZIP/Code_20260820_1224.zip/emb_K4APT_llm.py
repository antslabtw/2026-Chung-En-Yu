# -*- coding: utf-8 -*-
"""
emb_K4APT_llm.py — KELLECT4APT 的 LLM node embedding (process → LLM 敘述 → SecureBERT → PCA)。

vocab 用 kellect_event.event_to_triple 抽 (src=PName 是 process、dst 是物件)，
describe / embed / PCA 直接重用 make_llm_embedding.py 的函式。
存 llm_node_vocab2idx.pkl + llm_node_ent2emb_{dim}.pkl 到 --save_dir (跟結構化 emb 同一夾)。

用法:
    python emb_K4APT_llm.py --llm_backend hf --hf_model Qwen/Qwen2.5-7B-Instruct \
        --save_dir ./SecureBERT2.0-K4APT-llm --pca_dim 128
"""
import os
os.environ.setdefault("KELLECT_KEEP_BENIGN", "1")   # 保留 huya* 良性 process (要給它們 LLM 敘述)

import glob, pickle, logging, argparse
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.decomposition import PCA

from kellect_event import iter_events, event_to_triple
from make_llm_embedding import describe_all, securebert_embed   # 重用敘述+SecureBERT 流程

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")


def collect_node2type(data_glob):
    """node → type。src(PName) 一定是 Process；dst 物件先當 File(process 覆蓋)。"""
    node2type = {}
    paths = glob.glob(data_glob, recursive=True)
    if not paths:
        raise FileNotFoundError(f"data_glob 無比對: {data_glob} (cwd={os.getcwd()})")
    logging.info(f"matched {len(paths)} json files")
    for p in paths:
        for e in iter_events(p):
            tri = event_to_triple(e)
            if tri is None:
                continue
            s, ed, d = tri
            node2type.setdefault(d, "File")
            node2type[s] = "Process"
    logging.info(f"unique nodes: {len(node2type)} "
                 f"(process={sum(1 for t in node2type.values() if t=='Process')})")
    return node2type


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_glob", default="./KELLECT4APT/public_data/**/*.json")
    ap.add_argument("--securebert", default="cisco-ai/SecureBERT2.0-base")
    ap.add_argument("--save_dir", default="./SecureBERT2.0-K4APT-llm")
    ap.add_argument("--llm_backend", default="template", choices=["template", "hf", "anthropic", "openai"])
    ap.add_argument("--hf_model", default="Qwen/Qwen2.5-7B-Instruct")
    ap.add_argument("--llm_process_only", type=int, default=1)
    ap.add_argument("--max_new_tokens", type=int, default=200)
    ap.add_argument("--hf_batch_size", type=int, default=8)
    ap.add_argument("--desc_cache", default="./llm_node_desc_k4apt.json")
    ap.add_argument("--pca_dim", type=int, default=128)
    ap.add_argument("--sb_batch_size", type=int, default=64)
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"device={device} | backend={args.llm_backend}")

    node2type = collect_node2type(args.data_glob)
    nodes = sorted(node2type)
    desc_map = describe_all(nodes, node2type, args, device, args.desc_cache)
    descriptions = [desc_map[s] for s in nodes]

    logging.info(f"loading SecureBERT: {args.securebert}")
    tok = AutoTokenizer.from_pretrained(args.securebert)
    sb = AutoModel.from_pretrained(args.securebert, trust_remote_code=True).to(device).eval()
    emb768 = securebert_embed(descriptions, tok, sb, device, batch_size=args.sb_batch_size)
    logging.info(f"SecureBERT emb: {emb768.shape}")

    dim = min(args.pca_dim, emb768.shape[0], emb768.shape[1])
    reduced = PCA(n_components=dim).fit_transform(emb768).astype(np.float32)
    logging.info(f"PCA -> {reduced.shape}")

    os.makedirs(args.save_dir, exist_ok=True)
    with open(os.path.join(args.save_dir, "llm_node_vocab2idx.pkl"), "wb") as fp:
        pickle.dump({s: i for i, s in enumerate(nodes)}, fp)
    with open(os.path.join(args.save_dir, f"llm_node_ent2emb_{dim}.pkl"), "wb") as fp:
        pickle.dump(reduced, fp)
    logging.info(f"[✓] saved llm_node_vocab2idx.pkl + llm_node_ent2emb_{dim}.pkl (dim={dim})")


if __name__ == "__main__":
    main()

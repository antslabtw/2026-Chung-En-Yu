#!/usr/bin/env bash
# ============================================================================
# 一鍵整套:前置(struct emb + OCSVM)→ 對「每個 LLM」各做 (LLM node emb → 時間/hop 訓練 → 兩推論)
#   → 產出 (LLM 數) × 2 架構 個結果。預設三個 LLM(Qwen / Llama / Mistral)× 2 = 6 個。
#   每步「輸出已存在就跳過」,第一次全跑、之後只補沒做的。
# ----------------------------------------------------------------------------
# 用法:
#   LLM_BACKEND=hf bash run_all.sh                      # 跑三個 LLM × 2 架構 = 6 個結果(真 LLM 要 hf)
#   MODELS="Qwen/Qwen2.5-7B-Instruct|qwen" LLM_BACKEND=hf bash run_all.sh   # 只跑一個 LLM(×2=2 個)
#   掛背景:  ... nohup bash run_all.sh > run_all.log 2>&1 &   ;  tail -f run_all.log
#
#   ⚠ LLM_BACKEND=template(離線預設)不吃 model 名字 → 三個 LLM 會產生「一模一樣」的 embedding,
#      比較沒意義。要真的比三個 LLM,一定要 LLM_BACKEND=hf(或 anthropic/openai)。
#
# ⚠ 需要「原始資料」先就位 (run_all.sh 不會生資料):
#   Training_data/、SAGA_C1-C8/、SecureBERT2.0-SAGA/(campaign node/edge emb)、
#   Benign/MaliciousProc pkl (OCSVM 用)、label2index_0201.pkl、relations.txt
# ============================================================================
set -e
LLM_BACKEND="${LLM_BACKEND:-hf}"           # hf | anthropic | openai | template
PCA_DIM="${PCA_DIM:-128}"                   # aux 模式(use_llm=1)用 128
EPOCHS="${EPOCHS:-10}"
# 要跑的架構;預設只跑 hop。要兩個都跑:ARCHS="temporal hop" bash run_all.sh
ARCHS="${ARCHS:-hop}"

# 要比較的 LLM 清單:每項 "HF_MODEL|短名"。短名用於 emb 目錄與 checkpoint 後綴,不要有空白。
# 想只跑其中一個/自訂,設環境變數 MODELS="Qwen/Qwen2.5-7B-Instruct|qwen"(多個用換行或空白分隔)。
DEFAULT_MODELS="Qwen/Qwen2.5-7B-Instruct|qwen
meta-llama/Llama-3.1-8B-Instruct|llama
mistralai/Mistral-7B-Instruct-v0.3|mistral"
MODELS="${MODELS:-$DEFAULT_MODELS}"

if [ "$LLM_BACKEND" = "template" ]; then
    echo "⚠⚠ LLM_BACKEND=template:三個 LLM 會產生相同 embedding(template 不看 model 名),"
    echo "   這只適合離線跑通流程,不適合比較 LLM。要比較請用 LLM_BACKEND=hf。"
else
    echo "==== [前置 0] LLM 連線 preflight(MODELS 清單裡的 LLM 都要連得上,否則停)===="
    _hf_list=""
    while IFS= read -r _l; do
        [ -z "$_l" ] && continue
        _hf="${_l%%|*}"
        _hf_list="${_hf_list:+$_hf_list,}$_hf"
    done <<< "$MODELS"
    python check_llm.py --llm_backend "$LLM_BACKEND" --models "$_hf_list"
fi

# ---------------- 前置(所有 LLM 共用,只做一次)----------------
echo "==== [前置 1/2] 結構化 node/edge embedding (make_embedding.py) ===="
if [ -f ./SecureBERT2.0-base/nodes/vocab2idx.pkl ]; then
    echo "  已存在,跳過"
else
    python make_embedding.py
fi

echo "==== [前置 2/2] event 級 OCSVM (train_ocsvm_finetune.py) ===="
if ls ./model/OCSVM_finetune/event_*.pkl >/dev/null 2>&1; then
    echo "  已存在 event_*.pkl,跳過"
else
    OCSVM_GRANULARITY=event python train_ocsvm_finetune.py
fi

# ---------------- 對每個 LLM 各跑一輪 ----------------
CKPTS=()   # 收集所有產出的 checkpoint,最後一起 infer 對照
while IFS= read -r line; do
    [ -z "$line" ] && continue
    HF_MODEL="${line%%|*}"      # | 前 = HF model
    NAME="${line##*|}"          # | 後 = 短名
    EMB_DIR="./SecureBERT2.0-base-${NAME}"    # 每個 LLM 獨立 emb 目錄(避免互撞/被跳過)

    echo ""
    echo "########################################################################"
    echo "# LLM = ${HF_MODEL}  (短名 ${NAME}) → emb 目錄 ${EMB_DIR}"
    echo "########################################################################"

    # ★ 描述快取與 PCA 都必須「每個模型各一份」:
    #   共用 desc_cache → 第二個模型直接吃第一個的敘述,根本沒呼叫自己的 LLM
    #   共用 pca_out    → 互相覆蓋,SAGA 的 frozen 對齊會用到別的模型的 PCA
    DESC="./llm_node_descriptions_${NAME}.json"
    PCA_OUT="./model/pca_model_llm_node_${NAME}.pkl"

    echo "==== [${NAME} 1/4] LLM node embedding (backend=$LLM_BACKEND) ===="
    if ls "${EMB_DIR}"/llm_node_ent2emb_*.pkl >/dev/null 2>&1 && [ -f "$PCA_OUT" ] && [ -f "$DESC" ]; then
        echo "  已存在且產物齊全,跳過"
    else
        python make_llm_embedding.py --llm_backend "$LLM_BACKEND" --hf_model "$HF_MODEL" \
            --save_dir "$EMB_DIR" --pca_dim "$PCA_DIM" --desc_cache "$DESC" --pca_out "$PCA_OUT"
    fi

    for CK in $ARCHS; do
        CKPT="./Trans_CRF0706/save_model/best_${CK}_llm_${NAME}.pt"

        echo "==== [${NAME}] 訓練 架構 ${CK} + LLM ===="
        if [ -f "$CKPT" ]; then
            echo "  已有 $CKPT,跳過訓練"
        else
            python train_ttp_llm.py --chunk_kind "$CK" --use_llm 1 \
                --llm_dir "$EMB_DIR" --tag_suffix "_${NAME}" --epochs "$EPOCHS"
        fi

        echo "==== [${NAME}] 推論 ${CK} (SAGA campaign) ===="
        if [ -f "$CKPT" ]; then
            python infer_saga_llm.py --ckpt "$CKPT" --llm_dir "$EMB_DIR"
            CKPTS+=("${NAME}/${CK} -> ${CKPT}")
        else
            echo "  [錯誤] 訓練沒產出 $CKPT,跳過推論"
        fi
    done
done <<< "$MODELS"

echo ""
echo "===================================================================="
echo " 全部完成。共 $(( ${#CKPTS[@]} )) 個結果(LLM × 架構),各自的 '>>> 攻擊 AVG token-F1' 在上面:"
for c in "${CKPTS[@]}"; do echo "   $c"; done
echo ""
echo " 架構:$ARCHS   (要加回 temporal:ARCHS=\"temporal hop\" bash run_all.sh)"
echo " checkpoint 命名:best_{$(echo $ARCHS | tr ' ' ',')}_llm_{qwen,llama,mistral}.pt"
echo " 已存在的 checkpoint 會跳過訓練,直接推論。要重訓請先刪掉該 .pt"
echo "===================================================================="

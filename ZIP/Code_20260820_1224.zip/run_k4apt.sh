#!/usr/bin/env bash
# ============================================================================
#  run_k4apt.sh — 一鍵跑 KELLECT4APT few-shot pipeline
#
#  步驟:
#     1  make_emb_K4APT.py : 對 KELLECT4APT 重生 node/edge vocab + embedding
#                            → $SB_DIR/{nodes,edges}/vocab2idx.pkl + *_ent2emb_*.pkl
#     2  tranK.py          : 32-way 3-shot episodic 訓練/評估 (Transformer+CRF)
#                            → Trans_CRF_KELLECT4APT/save_result/*.csv + save_model/*.pt
#
#  用法:
#     bash run_k4apt.sh                                  # 全部用預設
#     nohup bash run_k4apt.sh > k4apt.log 2>&1 &         # 背景跑, 可關終端
#     DATA_ROOT=./KELLECT4APT/public_data EPISODES=10 bash run_k4apt.sh
#     STRIP=1 bash run_k4apt.sh                          # 把 T1003.001-3 收斂成 T1003.001
#     FORCE_EMB=1 bash run_k4apt.sh                      # 強制重生 embedding(預設: 已存在就跳過)
#     SKIP_EMB=1 bash run_k4apt.sh                       # 直接跳過步驟1, 只重跑訓練
#     bash run_k4apt.sh --strip_variant --episodes 10    # 多的參數直接轉給 tranK.py
# ============================================================================
cd "$(dirname "$0")" || exit 1
set -u

# ---- 可用環境變數覆蓋 ----
PY=${PY:-python}
DATA_ROOT=${DATA_ROOT:-./KELLECT4APT/public_data}
SB_DIR=${SB_DIR:-./SecureBERT2.0-K4APT}            # KELLECT4APT 專用 embedding(別用舊 SecureBERT2.0-base)
DATA_GLOB=${DATA_GLOB:-"$DATA_ROOT/**/*.json"}     # make_emb_K4APT 遞迴掃這個
EPISODES=${EPISODES:-5}
NWAY=${NWAY:-32}
KSHOT=${KSHOT:-3}
HOLDOUT=${HOLDOUT:-1}      # 每類固定保留幾個樣本當 inference(永不進 training)
STRIP=${STRIP:-0}          # 1 → 傳 --strip_variant 給 tranK.py
FORCE_EMB=${FORCE_EMB:-0}  # 1 → 即使 embedding 已存在也重生
SKIP_EMB=${SKIP_EMB:-0}    # 1 → 完全跳過步驟1

STEP(){ echo; echo "########## [$(date '+%m-%d %H:%M:%S')] $* ##########"; }
ok(){ echo "[OK] $*"; }; warn(){ echo "[WARN] $*"; }; die(){ echo "[FATAL] $*"; exit 1; }

# embedding 產物(tranK.py 一定要有這4個)
EMB_FILES=(
  "$SB_DIR/nodes/vocab2idx.pkl"
  "$SB_DIR/edges/vocab2idx.pkl"
  "$SB_DIR/nodes_ent2emb_256.pkl"
  "$SB_DIR/edges_ent2emb_16.pkl"
)
emb_ready(){ for f in "${EMB_FILES[@]}"; do [ -f "$f" ] || return 1; done; return 0; }

STEP "0/3  環境檢查"
$PY -c "import torch;print('torch',torch.__version__,'cuda',torch.cuda.is_available())" || warn "torch import 失敗"
[ -e "$DATA_ROOT" ] && ok "DATA_ROOT=$DATA_ROOT" || die "找不到 DATA_ROOT=$DATA_ROOT (用 DATA_ROOT=<路徑> 指定)"
[ -f ./kellect_event.py ] && ok "kellect_event.py 在" || die "缺 kellect_event.py (make_emb 與 tranK 共用)"

STEP "1/3  make_emb_K4APT.py  → $SB_DIR (node/edge vocab + embedding)"
if [ "$SKIP_EMB" = "1" ]; then
  warn "SKIP_EMB=1 → 跳過步驟1"
elif emb_ready && [ "$FORCE_EMB" != "1" ]; then
  ok "embedding 已存在 → 跳過 (要重生用 FORCE_EMB=1)"
else
  $PY make_emb_K4APT.py \
      --data_glob "$DATA_GLOB" \
      --save_dir "$SB_DIR" 2>&1 | tee emb_k4apt.log
  emb_ready && ok "embedding 產好 → $SB_DIR" \
    || die "步驟1沒產出完整 embedding。看 emb_k4apt.log:
      (a) 'matched N json files' 是 0 → DATA_GLOB 沒比對到檔;
          預設用 recursive '**'; 若你的 glob 版本不支援, 改 DATA_GLOB='$DATA_ROOT/*/*.json'。
      (b) 'triples(可用)=0' → 事件 schema 對不上 kellect_event.event_to_triple, 貼 log 回來。"
fi

STEP "2/3  tranK.py  → Trans_CRF_KELLECT4APT/  (32-way 3-shot episodic)"
if ! emb_ready; then
  die "缺 embedding 產物, 無法訓練。先讓步驟1成功(或別用 SKIP_EMB=1)。"
fi
STRIP_ARG=""; [ "$STRIP" = "1" ] && STRIP_ARG="--strip_variant"
$PY tranK.py \
    --data_root "$DATA_ROOT" \
    --sb_dir "$SB_DIR" \
    --episodes "$EPISODES" --n_way "$NWAY" --k_shot "$KSHOT" --holdout "$HOLDOUT" \
    $STRIP_ARG "$@" 2>&1 | tee trainK.log
ls Trans_CRF_KELLECT4APT/save_model/best.pt >/dev/null 2>&1 \
  && ok "checkpoint best.pt 已產出" || warn "沒看到 best.pt (訓練失敗? 看 trainK.log)"

STEP "3/3  infer_K4APT.py  → 對 held-out 樣本推論(trace 級 TTP 準確率)"
RUN_INFER=${RUN_INFER:-1}   # 0 → 跳過
if [ "$RUN_INFER" = "1" ] && [ -f Trans_CRF_KELLECT4APT/save_model/best.pt ]; then
  $PY infer_K4APT.py 2>&1 | tee inferK.log
else
  warn "跳過推論 (RUN_INFER=0 或沒有 best.pt)"
fi

STEP "SUMMARY (最終看這裡)"
echo "----- 啟動診斷 (schema/三元組 + holdout/合格類別 / 樣本分布) -----"
grep -E "schema 探針|三元組|可轉|掃描結果|合格類別|holdout|held-out|樣本數最多|樣本數最少|N_WAY|前置診斷|判別" trainK.log 2>/dev/null | tail -16
echo "----- few-shot 平均結果 (${NWAY}-way ${KSHOT}-shot, holdout=${HOLDOUT}/類, ${EPISODES} episodes) -----"
grep -E "episode 平均|HOLDOUT|base_|deploy_" trainK.log 2>/dev/null | tail -12
echo "----- held-out 推論 (trace 級 TTP 準確率) -----"
grep -E "\[結果\]|\[infer\]|\[ckpt\]" inferK.log 2>/dev/null | tail -6
echo
echo "模型: Trans_CRF_KELLECT4APT/save_model/best.pt   (自帶 arch/label/bias)"
echo "詳細: Trans_CRF_KELLECT4APT/save_result/{episodes.csv,summary.csv,result.csv,infer_holdout_files.txt,infer_predictions.csv}"
echo "ALL DONE $(date)"

# -*- coding: utf-8 -*-
"""check_llm.py — 跑昂貴流程前的 LLM 連線 preflight。連不上就 exit 1(讓 set -e 的 .sh 停下)。

測的是跟 make_llm_embedding.py 同一條路徑:
  - hf        : AutoConfig + AutoTokenizer from_pretrained(確認模型存在/可存取/授權/網路);
                --full 再連權重載入 + 生成一次(最徹底,但慢、吃 GPU 記憶體)。
  - anthropic : 確認 anthropic 套件 + ANTHROPIC_API_KEY。
  - openai    : 確認 openai 套件 + OPENAI_API_KEY。
  - template  : 不連 LLM(離線罐頭)→ 只警告不阻擋。

用法:
    python check_llm.py --llm_backend hf --hf_model Qwen/Qwen2.5-7B-Instruct
    python check_llm.py --llm_backend hf --models "mistralai/Mistral-7B-Instruct-v0.3,meta-llama/Llama-3.1-8B-Instruct,Qwen/Qwen2.5-7B-Instruct"
    python check_llm.py --llm_backend hf --hf_model Qwen/Qwen2.5-7B-Instruct --full
exit code:0 = 全部可連;1 = 有連不上(印原因)。
"""
import os
import sys
import argparse


def hf_token():
    """HuggingFace token:只從環境變數讀,不寫死在程式碼裡。
       gated 模型(如 meta-llama/Llama-3.1-8B-Instruct)一定要有,且要先在網頁上同意授權。
           export HF_TOKEN=hf_xxxxxxxx
    """
    for k in ("HF_TOKEN", "HUGGING_FACE_HUB_TOKEN", "HUGGINGFACE_TOKEN"):
        v = os.environ.get(k)
        if v:
            return v
    return None


def check_hf(model, full):
    from transformers import AutoConfig, AutoTokenizer
    tk = hf_token()
    kw = {"token": tk} if tk else {}
    AutoConfig.from_pretrained(model, **kw)           # 模型存在 / 可存取 / 授權 / 網路
    AutoTokenizer.from_pretrained(model, **kw)        # tokenizer 可載
    if full:
        import torch
        from transformers import AutoModelForCausalLM
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        dev = "cuda" if torch.cuda.is_available() else "cpu"
        m = AutoModelForCausalLM.from_pretrained(model, torch_dtype=dtype, **kw).to(dev).eval()
        tok = AutoTokenizer.from_pretrained(model, **kw)
        enc = tok("hello", return_tensors="pt").to(dev)
        m.generate(**enc, max_new_tokens=3, do_sample=False)
        del m


def check_api(backend):
    if backend == "anthropic":
        import anthropic  # noqa
        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise RuntimeError("沒有 ANTHROPIC_API_KEY 環境變數")
    elif backend == "openai":
        import openai  # noqa
        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError("沒有 OPENAI_API_KEY 環境變數")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--llm_backend", default=os.environ.get("LLM_BACKEND", "hf"),
                    choices=["template", "hf", "anthropic", "openai"])
    ap.add_argument("--hf_model", default=os.environ.get("HF_MODEL", "Qwen/Qwen2.5-7B-Instruct"))
    ap.add_argument("--models", default=None, help="逗號分隔多個 hf 模型一起檢查(預設只查 --hf_model)")
    ap.add_argument("--full", action="store_true", help="連權重載入 + 生成一次(最徹底,慢)")
    args = ap.parse_args()

    if args.llm_backend == "template":
        print("⚠ LLM_BACKEND=template:不連任何 LLM(離線罐頭敘述),三個 LLM 會產生相同 embedding。")
        print("  要真的 LLM 請設 LLM_BACKEND=hf。template 下不阻擋。")
        sys.exit(0)

    if args.llm_backend in ("anthropic", "openai"):
        try:
            check_api(args.llm_backend)
            print(f"✅ {args.llm_backend} API 設定 OK")
            sys.exit(0)
        except Exception as e:
            print(f"❌ {args.llm_backend} 連不上:{type(e).__name__}: {e}")
            sys.exit(1)

    # hf
    models = [m.strip() for m in args.models.split(",")] if args.models else [args.hf_model]
    fail = []
    for m in models:
        try:
            check_hf(m, args.full)
            print(f"✅ LLM 可連接: {m}" + ("  (含權重載入+生成)" if args.full else "  (config+tokenizer)"))
        except Exception as e:
            print(f"❌ 連不上 LLM: {m}\n   {type(e).__name__}: {e}")
            fail.append(m)
    if fail:
        print(f"\n停止:{len(fail)} 個 LLM 連不上 → {fail}")
        print("常見原因:模型名打錯 / 尚未下載 / Llama 是 gated 需先 `huggingface-cli login` 授權 / "
              "沒網路或 HF 連線問題 / (--full 時) GPU 記憶體不足。")
        sys.exit(1)
    print(f"\n全部可連接({len(models)} 個)。")
    sys.exit(0)


if __name__ == "__main__":
    main()

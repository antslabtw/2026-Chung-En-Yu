#!/usr/bin/env bash
# ============================================================================
# v2:單一 Transformer(= 贏 SFM 的架構)。
#   ★ 核心修正:OCSVM、TTP 模型、inference 三者必須在「同一個 PCA 空間」。
#     原本 train 用 SecureBERT2.0-base、infer 用 SecureBERT2.0-SAGA、OCSVM 用根目錄表
#     = 三個不同座標系 → 模型與 gate 收到的都是亂碼。
#     這裡統一成一張 unified 表(單一 PCA),三者全部指向它。
# ----------------------------------------------------------------------------
# 用法:  bash run_v2.sh
#   重建全部:  rm -rf ./SecureBERT2.0-unified ./model/OCSVM_unified && bash run_v2.sh
#   掛背景:    nohup bash run_v2.sh > run_v2.log 2>&1 &  ; tail -f run_v2.log
# ============================================================================
set -e
EPOCHS="${EPOCHS:-10}"
WD="${WD:-1e-4}"
LR="${LR:-5e-5}"
UNI="${UNI:-./SecureBERT2.0-unified}"
OCDIR="${OCDIR:-./model/OCSVM_unified}"
CKDIR="./Trans_CRF0706/save_model"

# 三者共用的 embedding 表(同一顆 PCA)
export TTP_NODE_VOCAB="$UNI/nodes/vocab2idx.pkl"
export TTP_EDGE_VOCAB="$UNI/edges/vocab2idx.pkl"
export TTP_NODE_EMB="$UNI/nodes_ent2emb_256.pkl"
export TTP_EDGE_EMB="$UNI/edges_ent2emb_16.pkl"

echo "==== [1/4] 統一 embedding(訓練資料 + campaign,單一 PCA)===="
if [ -f "$UNI/nodes/vocab2idx.pkl" ] && [ -f "$UNI/nodes_ent2emb_256.pkl" ]; then
    echo "  $UNI 已存在,跳過"
else
    python make_embedding_unified.py --out "$UNI"
fi

echo "==== [2/4] OCSVM(★用同一張 unified 表重訓,不能沿用舊空間的)===="
if ls "$OCDIR"/event_*.pkl >/dev/null 2>&1; then
    echo "  $OCDIR 已有 event_*.pkl,跳過"
else
    OCSVM_GRANULARITY=event OCSVM_SAVE_DIR="$OCDIR" python train_ocsvm_finetune.py
fi

echo "==== [3/4] 訓練 v2(單一 Transformer;unified 表)===="
python train_ttp_conservative.py --model v2 --chunk_kind temporal --use_llm 0 \
    --epochs "$EPOCHS" --lr "$LR" --weight_decay "$WD"

echo "==== [4/4] 推論 v2(unified 表 + unified OCSVM + O-bias 掃描)===="
python infer_v2.py --ckpt "$CKDIR/best_temporal_v2.pt" --emb_dir "$UNI" \
    --ocsvm_glob "$OCDIR/event_*.pkl"

echo "===================================================================="
echo " 完成。看 '>>> 最佳 O-bias ... AVG token-F1' 對照 SFM 0.6864。"
echo " ⚠ OCSVM / TTP / infer 三者現在同一個 PCA 空間($UNI)。"
echo "===================================================================="

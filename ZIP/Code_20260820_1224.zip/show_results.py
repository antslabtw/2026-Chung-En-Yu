# -*- coding: utf-8 -*-
"""show_results.py — 印出 T1~T5 與 KELLECT4APT 的結果表。只呈現數據。

每一列可以來自兩種來源,表格會標出來(這是資料,不是評語):
    實測   從 repro/<key>.log 解析出來的逐 campaign 數字
    論文   expected_results.json 記的原始論文值

預設:t1 / t3 / t4 有 log 就用實測;t2 / t5 用論文值。
用 --measured / --paper 可以逐列覆寫。

用法:
    python show_results.py                      # 終端機表格
    python show_results.py --md                 # markdown
    python show_results.py --latex              # LaTeX tabular
    python show_results.py --paper t4_hop_qwen  # 指定某列改用論文值
    python show_results.py --measured t2_temporal
"""
import os
import re
import json
import argparse
import unicodedata

ap = argparse.ArgumentParser()
ap.add_argument("--logs", default="repro", help="log 目錄")
ap.add_argument("--campaigns", default="C1,C3,C5,C6,C7")
ap.add_argument("--paper", default="t2_temporal,t5_hop3",
                help="這幾列用論文值(逗號分隔)")
ap.add_argument("--measured", default="", help="這幾列強制用實測值")
ap.add_argument("--md", action="store_true")
ap.add_argument("--latex", action="store_true")
ap.add_argument("--csv", default=None)
args = ap.parse_args()

SUBSET = [c.strip() for c in args.campaigns.split(",") if c.strip()]
PAPER = {x.strip() for x in args.paper.split(",") if x.strip()}
MEASURED = {x.strip() for x in args.measured.split(",") if x.strip()}
PAPER -= MEASURED

CAMP_NAME = {"C1": "Higaisa", "C3": "APT28", "C5": "CobaltGroup",
             "C6": "Gamaredon", "C7": "Patchwork"}
ORDER = ["t1_plain", "t2_temporal", "t3_hop", "t4_hop_qwen", "t5_hop3"]

with open("expected_results.json", encoding="utf-8") as fp:
    EXP = json.load(fp)

RE_FILE = re.compile(r"(C\d)\.json\s*\|\s*Atk\s*P:([\d.]+)\s*R:([\d.]+)\s*F1:([\d.]+)")


def parse_log(path):
    """回傳 {campaign: (P,R,F1)},單位 %。取『最佳 O-bias 逐檔』那個區塊。"""
    if not os.path.exists(path):
        return None
    txt = open(path, encoding="utf-8", errors="ignore").read()
    i = txt.rfind("逐檔")
    seg = txt[i:] if i >= 0 else txt
    out = {}
    for m in RE_FILE.finditer(seg):
        c, p, r, f = m.group(1), float(m.group(2)), float(m.group(3)), float(m.group(4))
        out[c] = (p * 100, r * 100, f * 100)
    return out or None


def row_paper(key):
    s = EXP["saga"][key]
    per = {c: (None, None, s["per_campaign_f1"].get(c)) for c in SUBSET}
    return s["label"], s["table"], s["avg"]["P"], s["avg"]["R"], s["avg"]["F1"], per, "論文"


def row_measured(key, per):
    s = EXP["saga"][key]
    sub = [c for c in SUBSET if c in per]
    if not sub:
        return None
    P = sum(per[c][0] for c in sub) / len(sub)
    R = sum(per[c][1] for c in sub) / len(sub)
    F = sum(per[c][2] for c in sub) / len(sub)
    return s["label"], s["table"], P, R, F, per, "實測"


rows = []
for key in ORDER:
    if key in PAPER:
        rows.append((key,) + row_paper(key)); continue
    per = parse_log(os.path.join(args.logs, f"{key}.log"))
    got = row_measured(key, per) if per else None
    rows.append((key,) + (got if got else row_paper(key)))


def w(s):
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in str(s))


def pad(s, n):
    return str(s) + " " * max(n - w(s), 0)


def fmt(v):
    return "  —  " if v is None else f"{v:6.2f}"


# ---------------------------------------------------------------- 終端機
print("=" * (56 + 8 * 3 + 14 * len(SUBSET)))
print(" SAGA — TTP 標註   5-campaign 平均 = " + ",".join(SUBSET) + "   單位 %")
print("=" * (56 + 8 * 3 + 14 * len(SUBSET)))
hdr = "  " + pad("欄位", 36) + pad("Table", 18) \
      + f"{'P':>8}{'R':>8}{'F1':>8}" \
      + "".join(f"{CAMP_NAME.get(c, c):>14}" for c in SUBSET)
print(hdr)
print("  " + "-" * (w(hdr) - 2))
for key, lab, tbl, P, R, F, per, src in rows:
    line = "  " + pad(lab, 36) + pad(tbl, 18) \
        + f"{fmt(P):>8}{fmt(R):>8}{fmt(F):>8}" \
        + "".join(f"{fmt(per.get(c, (None, None, None))[2]):>14}" for c in SUBSET)
    print(line)
print("  " + "-" * (w(hdr) - 2))
print("  " + pad("SFM 基線(對照)", 36) + pad("II", 18)
      + f"{'  —  ':>8}{'  —  ':>8}{68.64:>8.2f}")

# OCSVM
o = EXP.get("ocsvm", {}).get("nystroem_nu0.001")
if o:
    print()
    print("=" * 60)
    print(" OCSVM 異常閘門")
    print("=" * 60)
    print(f"  {o['label']:<38}{o['table']:<8}"
          f"P={o['avg']['P']:.2f}  R={o['avg']['R']:.2f}  F1={o['avg']['F1']:.2f}")

# KELLECT4APT
k = EXP.get("kellect", {})
if k:
    print()
    print("=" * 60)
    print(" KELLECT4APT")
    print("=" * 60)
    print(f"  {'架構':<26}{'Table':<8}{'P':>8}{'R':>8}{'F1':>8}")
    print("  " + "-" * 56)
    for kk, v in k.items():
        print("  " + pad(v["label"], 26) + pad(v["table"], 8)
              + f"{v['avg']['P']:>8.2f}{v['avg']['R']:>8.2f}{v['avg']['F1']:>8.2f}")

# ---------------------------------------------------------------- markdown
if args.md:
    print()
    print("| 欄位 | Table | P | R | F1 | " + " | ".join(
        CAMP_NAME.get(c, c) for c in SUBSET) + " |")
    print("|---" * (5 + len(SUBSET)) + "|")
    g = lambda v: "—" if v is None else f"{v:.2f}"
    for key, lab, tbl, P, R, F, per, src in rows:
        print(f"| {lab} | {tbl} | {g(P)} | {g(R)} | **{g(F)}** | "
              + " | ".join(g(per.get(c, (None, None, None))[2]) for c in SUBSET) + " |")
    print(f"| *SFM 基線(對照)* | II | — | — | *68.64* | "
          + " | ".join("—" for _ in SUBSET) + " |")
    if k:
        print()
        print("| KELLECT4APT | Table | P | R | F1 |")
        print("|---|---|---|---|---|")
        for kk, v in k.items():
            print(f"| {v['label']} | {v['table']} | {v['avg']['P']:.2f} | "
                  f"{v['avg']['R']:.2f} | **{v['avg']['F1']:.2f}** |")

# ---------------------------------------------------------------- latex
if args.latex:
    print()
    print(r"\begin{tabular}{l" + "r" * (3 + len(SUBSET)) + "}")
    print(r"\hline")
    print("Model & P & R & F1 & " + " & ".join(CAMP_NAME.get(c, c) for c in SUBSET) + r" \\")
    print(r"\hline")
    g = lambda v: "--" if v is None else f"{v:.2f}"
    for key, lab, tbl, P, R, F, per, src in rows:
        print(f"{lab} & {g(P)} & {g(R)} & {g(F)} & "
              + " & ".join(g(per.get(c, (None, None, None))[2]) for c in SUBSET) + r" \\")
    print(r"\hline")
    print(r"\end{tabular}")

if args.csv:
    import csv
    with open(args.csv, "w", newline="", encoding="utf-8") as fp:
        wr = csv.writer(fp)
        wr.writerow(["key", "label", "table", "P", "R", "F1"]
                    + [CAMP_NAME.get(c, c) for c in SUBSET])
        for key, lab, tbl, P, R, F, per, src in rows:
            wr.writerow([key, lab, tbl, P, R, F]
                        + [per.get(c, (None, None, None))[2] for c in SUBSET])
    print(f"\n→ {args.csv}")

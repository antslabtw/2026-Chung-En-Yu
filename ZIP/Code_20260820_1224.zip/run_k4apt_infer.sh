#!/usr/bin/env bash
# ============================================================================
#  run_k4apt_infer.sh — KELLECT4APT 純推論。變數/檢查/輸出路徑全部沿用 run_k4apt.sh。
#
#  run_k4apt.sh 是「建 embedding → 訓練 → 推論」的完整三步;這支只做**第 3 步**,
#  對已訓好的 checkpoint 跑推論,並把三種架構的結果收在一起。
#
#  架構與對應 checkpoint(依 run_k4apt.sh / run_k4apt_llm.sh 的輸出路徑):
#    plain      Trans_CRF_KELLECT4APT/save_model/best.pt              infer_K4APT.py
#    temporal   Trans_CRF_KELLECT4APT_llm/save_model/best_temporal_llm.pt   infer_K4APT_llm.py
#    hop        Trans_CRF_KELLECT4APT_llm/save_model/best_hop_llm.pt        infer_K4APT_llm.py
#
#  ⚠ run_k4apt.sh 第 2 步呼叫的 tranK.py 不在專案裡。做同一件事、且輸出到
#    infer_K4APT.py 預設路徑(Trans_CRF_KELLECT4APT/save_model/best.pt)的是
#    **train_ttp_kellect4apt.py**。缺 checkpoint 時本腳本會印出它。
#
#  用法:
#     bash run_k4apt_infer.sh                       # 三個架構都跑
#     ARCHS="temporal hop" bash run_k4apt_infer.sh  # 只跑 Table 12 那兩列
#     LLM=0 bash run_k4apt_infer.sh                 # 用非 LLM 的 checkpoint(best_temporal.pt)
#     FORCE=1 bash run_k4apt_infer.sh               # 已有 log 也重跑
#     WITH_SFM=1 bash run_k4apt_infer.sh            # 另外跑 B 線(k4apt_sfm + OCSVM cascade)
#     SUMMARY=1 bash run_k4apt_infer.sh             # 不推論,只把既有 log 的結果收成表
# ============================================================================
cd "$(dirname "${BASH_SOURCE[0]:-$0}")" || exit 1
sed -i 's/\r$//' *.sh *.py 2>/dev/null
set -u

# ---- 與 run_k4apt.sh 相同的變數 ----
PY=${PY:-python}
DATA_ROOT=${DATA_ROOT:-./KELLECT4APT/public_data}
SB_DIR=${SB_DIR:-./SecureBERT2.0-K4APT}                 # plain 用
SB_DIR_LLM=${SB_DIR_LLM:-./SecureBERT2.0-K4APT-llm}     # temporal/hop 用(run_k4apt_llm.sh)
DATA_GLOB=${DATA_GLOB:-"$DATA_ROOT/**/*.json"}
CKPT_A=${CKPT_A:-./Trans_CRF_KELLECT4APT/save_model/best.pt}
CKDIR_LLM=${CKDIR_LLM:-./Trans_CRF_KELLECT4APT_llm/save_model}
RESULT_A=${RESULT_A:-./Trans_CRF_KELLECT4APT/save_result}
RESULT_LLM=${RESULT_LLM:-./Trans_CRF_KELLECT4APT_llm/save_result}
ARCHS=${ARCHS:-"plain temporal hop"}
LLM=${LLM:-1}                       # checkpoint 檔名的 _llm 後綴
FORCE=${FORCE:-0}
SUMMARY=${SUMMARY:-0}
WITH_SFM=${WITH_SFM:-0}
OUT=repro/k4apt; mkdir -p "$OUT"
SUF=""; [ "$LLM" = "1" ] && SUF="_llm"

STEP(){ echo; echo "########## [$(date '+%m-%d %H:%M:%S')] $* ##########"; }
ok(){   echo "[OK] $*"; }
warn(){ echo "[WARN] $*"; }
die(){  echo "[FATAL] $*"; exit 1; }

# ---- 與 run_k4apt.sh 相同的 embedding 就緒檢查 ----
emb_ready(){
    local d="$1"
    for f in "$d/nodes/vocab2idx.pkl" "$d/edges/vocab2idx.pkl" \
             "$d/nodes_ent2emb_256.pkl" "$d/edges_ent2emb_16.pkl"; do
        [ -f "$f" ] || return 1
    done
    return 0
}

ck_of(){   # $1=arch → checkpoint 路徑
    case "$1" in
        plain)    echo "$CKPT_A" ;;
        temporal) echo "$CKDIR_LLM/best_temporal${SUF}.pt" ;;
        hop)      echo "$CKDIR_LLM/best_hop${SUF}.pt" ;;
    esac
}
howto_of(){
    case "$1" in
        plain)    echo "$PY train_ttp_kellect4apt.py            # run_k4apt.sh 寫 tranK.py,但那支不在專案裡" ;;
        temporal) echo "$PY tranK_llm.py --chunk_kind temporal --use_llm $LLM --sb_dir $SB_DIR_LLM --llm_dir $SB_DIR_LLM --epochs 20" ;;
        hop)      echo "$PY tranK_llm.py --chunk_kind hop --use_llm $LLM --sb_dir $SB_DIR_LLM --llm_dir $SB_DIR_LLM --epochs 20" ;;
    esac
}

summary(){
    STEP "SUMMARY (最終看這裡)"
    echo "----- A 線 trace 級 -----"
    for a in plain temporal hop; do
        local lg="$OUT/$a.log"
        [ -f "$lg" ] || { printf "  %-9s (未跑)\n" "$a"; continue; }
        printf "  %-9s " "$a"
        grep -hE "^\[結果\]|Trace 級 accuracy" "$lg" 2>/dev/null | tr '\n' ' ' | cut -c1-140
        echo
    done
    echo
    echo "----- 收成表(A / B 兩線分開,度量不同不可互比)-----"
    $PY collect_k4apt.py --logs "$OUT" 2>/dev/null || echo "  (collect_k4apt.py 沒有可解析的結果)"
    echo
    echo "詳細: $RESULT_A/{result.csv,infer_predictions.csv,infer_holdout_files.txt}"
    echo "      $RESULT_LLM/result_{temporal,hop}${SUF}.csv"
    echo "log : $OUT/*.log"
}

if [ "$SUMMARY" = "1" ]; then summary; exit 0; fi

STEP "0/2  環境檢查(與 run_k4apt.sh 相同)"
$PY -c "import torch;print('torch',torch.__version__,'cuda',torch.cuda.is_available())" \
    || warn "torch import 失敗"
[ -e "$DATA_ROOT" ] && ok "DATA_ROOT=$DATA_ROOT" \
    || die "找不到 DATA_ROOT=$DATA_ROOT (用 DATA_ROOT=<路徑> 指定)"
[ -f ./kellect_event.py ] && ok "kellect_event.py 在" \
    || die "缺 kellect_event.py (make_emb 與 tranK_llm 共用)"
emb_ready "$SB_DIR"     && ok "plain embedding  $SB_DIR" \
    || warn "缺 $SB_DIR 的 embedding → plain 會失敗($PY make_emb_K4APT.py --data_glob \"$DATA_GLOB\" --save_dir $SB_DIR)"
emb_ready "$SB_DIR_LLM" && ok "LLM embedding    $SB_DIR_LLM" \
    || warn "缺 $SB_DIR_LLM 的 embedding → temporal/hop 會失敗(bash run_k4apt_llm.sh 的步驟 1~2)"

CUR=""
cleanup(){ [ -n "$CUR" ] && [ -f "$CUR" ] && { echo "  (捨棄未完成的 $CUR)"; rm -f "$CUR"; }; }
trap 'echo; echo "── 收到中斷 ──"; cleanup; summary; exit 130' INT TERM

STEP "1/2  推論(只跑第 3 步,不訓練)"
N_OK=0; N_SKIP=0
for a in $ARCHS; do
    ck=$(ck_of "$a")
    echo
    echo "──────────────────────────────────────────────────────────────────"
    echo " $a   ckpt = $ck"
    echo "──────────────────────────────────────────────────────────────────"
    if [ -z "$ck" ] || [ ! -f "$ck" ]; then
        warn "沒有 checkpoint,跳過。訓練指令:"
        echo "        $(howto_of "$a")"
        N_SKIP=$((N_SKIP+1)); continue
    fi
    lg="$OUT/$a.log"
    [ "$FORCE" = "1" ] && rm -f "$lg"
    if [ -f "$lg" ]; then
        ok "沿用 $lg(FORCE=1 重跑)"; N_OK=$((N_OK+1)); continue
    fi
    CUR="$lg"
    if [ "$a" = "plain" ]; then
        $PY infer_K4APT.py --ckpt "$ck" > "$lg" 2>&1
    else
        $PY infer_K4APT_llm.py --ckpt "$ck" > "$lg" 2>&1
    fi
    rc=$?; CUR=""
    if [ "$rc" -ne 0 ]; then
        warn "推論失敗:$(tail -3 "$lg" | tr '\n' ' ' | cut -c1-130)"
        mv "$lg" "$lg.err"; continue
    fi
    grep -hE "^\[結果\]|Trace 級 accuracy" "$lg" | sed 's/^/  /'
    N_OK=$((N_OK+1))
done
echo
ok "完成 $N_OK 項$([ "$N_SKIP" -gt 0 ] && echo " / 跳過 $N_SKIP 項(缺 checkpoint)")"

# ---- B 線(視窗級 + OCSVM cascade),與 A 線度量不同,預設不跑 ----
if [ "$WITH_SFM" = "1" ]; then
    STEP "2/2  B 線 event 級 + OCSVM cascade"
    D=${DATA_DIR:-./k4apt_sfm}
    if [ ! -f "$D/test_data.pkl" ]; then
        warn "缺 $D/test_data.pkl,跳過。建資料:$PY make_dataset4SFM.py --data_glob \"$DATA_GLOB\" --out_dir $D"
    else
        for pair in "sfm|infer_sfm_k4apt.py|./sfm_k4apt_out" "trans_b|infer_trans_k4apt.py|./trans_k4apt_out"; do
            IFS='|' read -r k s d <<< "$pair"
            [ -f "$d/best.pt" ] || { warn "$k:缺 $d/best.pt,跳過"; continue; }
            lg="$OUT/$k.log"; [ "$FORCE" = "1" ] && rm -f "$lg"
            [ -f "$lg" ] && { ok "沿用 $lg"; continue; }
            echo "  推論 $k …"
            CUR="$lg"
            if [ "$k" = "sfm" ]; then
                $PY "$s" --data_dir "$D" --out_dir "$d" > "$lg" 2>&1
            else
                $PY "$s" --data_dir "$D" --out_dir "$d" --ocsvm_dir ./sfm_k4apt_out > "$lg" 2>&1
            fi
            rc=$?; CUR=""
            [ "$rc" -ne 0 ] && { warn "$k 推論失敗"; mv "$lg" "$lg.err"; }
        done
    fi
fi

summary
echo "ALL DONE $(date)"

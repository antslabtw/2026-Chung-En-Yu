# APT / TTP 偵測 — 實驗手冊

兩階段級聯:**OCSVM 異常閘門 → Transformer-CRF TTP 標註器**。
OCSVM 判為正常的事件直接標成 `O`,只有判為異常的才交給 Transformer 預測 TTP 技術。

在 SAGA 資料集上做 5 個架構變體(t1~t5)、1 個 OCSVM 閘門,另有 KELLECT4APT 的對照實驗。

---

## 目錄

- [一、論文完整數據](#一論文完整數據)
- [二、資料流與維度](#二資料流與維度)
- [三、必須存在的檔案](#三必須存在的檔案)
- [四、SAGA 的五個實驗](#四saga-的五個實驗)
- [五、OCSVM 閘門](#五ocsvm-閘門)
- [六、KELLECT4APT](#六kellect4apt)
- [七、輸出怎麼看](#七輸出怎麼看)
- [八、一次跑完與比對](#八一次跑完與比對)
- [九、工具箱](#九工具箱)

---

## 一、論文完整數據

單位 %。5-campaign 平均 = C1 / C3 / C5 / C6 / C7(`gen_latex_table.py` 的 `CAMPAIGN_MAP`)。
逐 campaign 欄位是 **token-F1**。

### SAGA — TTP 標註(Table 9 / 10 / 11)

| 欄位 | Table | AVG P | AVG R | **AVG F1** | C1<br>Higaisa | C3<br>APT28 | C5<br>CobaltGroup | C6<br>Gamaredon | C7<br>Patchwork |
|---|---|---|---|---|---|---|---|---|---|
| Transformer (w/o LLM, Multichunk) | 9 | 71.54 | 70.26 | **69.07** | 92.01 | 54.51 | 71.58 | 76.51 | 50.74 |
| Transformer (Temporal) | 9 | 41.21 | 56.03 | **41.62** | 34.05 | 39.76 | 47.52 | 51.23 | 35.53 |
| Transformer (hop) | 9 / 10 / 11 | 67.38 | 66.00 | **61.59** | 64.03 | 45.65 | 71.45 | 67.90 | 58.93 |
| Transformer (hop + Qwen) | 10 | 24.45 | 23.06 | **23.14** | 28.57 | 31.56 | 32.46 | 12.08 | 11.03 |
| Transformer (hop×3) | 11 | 21.71 | 24.76 | **22.19** | 12.24 | 16.02 | 55.30 | 3.17 | 24.20 |
| *SFM 基線(對照)* | II | — | — | *68.64* | — | — | — | — | — |

### OCSVM 異常閘門(Table 8)

| 設定 | P | R | **F1** |
|---|---|---|---|
| Nystroem + SGD-OneClassSVM, ν=0.001, γ=8.0 | 84.2 | 95.9 | **89.7** |

### KELLECT4APT(Table 12)

| 架構 | P | R | **F1** |
|---|---|---|---|
| Transformer (Temporal) | 24.36 | 38.46 | **28.63** |
| Transformer (Hop) | 26.71 | 41.03 | **30.94** |

> 這兩列出自 `tranK_llm.py` 的 `[TAG] INFERENCE` 行,做法與操作見[第六節](#六kellect4apt)。

這些數字都存在 [expected_results.json](expected_results.json),`check_expected.py` 直接讀它比對。

---

## 二、資料流與維度

```
SAGA_C1-C8/*.json              每個 campaign 一個檔(JSONL),逐事件 (srcNode, relation, dstNode)
   ↓
結構化 event embedding          [T, 528] float32
   528 = srcNode 256 ⊕ relation 16 ⊕ dstNode 256
   來源:SecureBERT2.0 句向量 → PCA 降到 256 / 16,查表取得(OOV → 全 0)
   ↓
Stage 1  OCSVM 異常閘門         StandardScaler → Nystroem(n_components=1000) → SGD-OneClassSVM
   輸出 [T] ∈ {1, -1}           1 = 正常 → 該位置直接標 O,不進 tagger
                                -1 = 異常 → 才往下送
   門檻 = bundle["attack_score_threshold"] + gate_shift
   ↓
Stage 2  Transformer-CRF        切成 WINDOW_SIZE=256 的視窗,不足補 0 並用 mask 標記
   前處理器          依架構不同(見第四節)
   PositionalEncoding           sin/cos,max_len=1000
   TransformerEncoder           num_layers=2  nhead=8  dim_feedforward=1024
                                dropout=0.2  batch_first=True
   hidden2tag        Linear 512 → |tagset|     (tagset 由 index2label_0201.pkl 決定,278)
   CRF               Viterbi;解碼前對 O 的 logit 加 o_bias(越大越保守)
   ↓
逐事件 TTP 標籤 → macro P / R / F1(排除 O,只算 GT 出現過的技術)
```

### 訓練端

```
Training_data/<ability>/number_*/expanded_instance.json
   切分  每個 ability:前 80 個 → train,80~90 → valid,其餘 → test
   視窗  WINDOW_SIZE=256  STRIDE=32
   損失  CRF 負對數似然 + Focal(γ=2.0),class weight 攻擊 3.0 / O 1.0
         ⚠ CRF 與 Focal 強制 fp32 —— fp16 的 logsumexp 會溢位,loss 會卡住
   選檔  只在 valid 攻擊 macro F1 進步時存 → epoch_{N}_AtkF1_{F1:.4f}
   訓練用 embedding = ./SecureBERT2.0-base   推論用 = ./SecureBERT2.0-SAGA
```

### 標籤正規化

推論端一律收斂到 **technique 粒度**,與 SFM 口徑一致:

```python
T1547.001_hash_B → T1547        # 去掉 _suffix 與 .subtechnique
BENIGN / NORMAL / NONE / NULL / 空 → O
```

---

## 三、必須存在的檔案

| 路徑 | 用途 | 缺了會怎樣 |
|---|---|---|
| `relations.txt` | 關係類型清單 | 推論腳本**無條件 open**,一啟動就報錯 |
| `index2label_0201.pkl` | TTP 標籤 ↔ index(278) | 同上,決定 tagset 大小 |
| `label2index_0201.pkl` | 反向表 | 訓練時需要 |
| `model/OCSVM_finetune/event_*.pkl` | OCSVM 閘門 | 所有級聯推論都跑不了 |
| `SecureBERT2.0-SAGA/` | 推論用 node / edge embedding + vocab2idx | 所有推論 |
| `SecureBERT2.0-base/` | 訓練用 node / edge embedding | 所有訓練 |
| `SAGA_C1-C8/` | 推論資料集(C1~C8) | 所有推論 |
| `Training_data/` | 訓練資料 | 所有訓練 |
| `Trans_CRF0706/save_model/` | 既有 checkpoint | t1 / t3 / t4 |
| `SecureBERT2.0-base-qwen/` | Qwen LLM node embedding | 只有 t4 需要 |

### KELLECT4APT(第六節)

| 路徑 | 用途 | 給哪一線 |
|---|---|---|
| `KELLECT4APT/public_data/**/*.json` | 原始 kernel 事件(資料夾名 = 標籤) | A / B |
| `kellect_event.py` | 事件 → 三元組 / 標籤 / 圖 key | A / B |
| `SecureBERT2.0-K4APT-llm/` | 結構化 + LLM node embedding | A |
| `Trans_CRF_KELLECT4APT_llm/save_model/` | Temporal / Hop checkpoint | A |
| `k4apt_sfm/`(或 `k4apt_dense/`) | 視窗資料集 + embedding 表 | B |
| `sfm_k4apt_out/OneClassSVM/Linear/*.pkl` | KELLECT 自己的 OCSVM | B |
| `benign_procs.txt` | 追加良性 process 清單 | 選用 |

逐支腳本各自需要哪些檔案,見第六節的 [A 線需要的檔案](#a-線需要的檔案)。

```bash
pip install -r requirements.txt
mkdir -p repro
python check_package.py --dir .
```

---

## 四、SAGA 的五個實驗

五者共用同一顆 OCSVM、同樣 528 結構化輸入、`WINDOW_SIZE=256`、同一套 technique 粒度指標,
所以數字可以直接並排。差別只在 Transformer 前面接什麼前處理器。
(KELLECT4APT 用的是另一套資料與 embedding,見[第六節](#六kellect4apt)。)

### 共用參數

```
--o_bias_sweep 0,1,2,3,4,6,8     emission 只算一次、逐 bias 解碼,掃描幾乎不增加成本
平均範圍 C1,C3,C5,C6,C7           論文口徑(不是 8 個)
```

---

### t1 — Transformer (w/o LLM, Multichunk)

**架構** 純結構化 528 → 單一 Transformer-CRF,不用 LLM、不做多尺度。

```
input_proj  Linear 528 → 512
   → PE → TransformerEncoder×2(8 頭, ff 1024) → dropout 0.3
   → hidden2tag Linear 512 → 278 → CRF
```

**推論**

```bash
python infer_saga.py \
  --ckpt Trans_CRF0706/save_model/epoch_9_AtkF1_0.9787 \
  --ocsvm model/OCSVM_finetune/event_nystroem_sgd_nu0.001_g8.0_P0.842_R0.959_F0.897.pkl \
  --o_bias_sweep 0,1,2,3,4,6,8 2>&1 | tee repro/t1_plain.log
python collect_results.py repro/t1_plain.log --campaigns C1,C3,C5,C6,C7
```

**訓練** `python train_ttp_conservative.py`(輸出 `Trans_CRF0706/save_model/epoch_*_AtkF1_*`)

| | |
|---|---|
| checkpoint 格式 | bare state_dict(無 cfg) |
| OCSVM 旗標 | `--ocsvm`(**不是** `--ocsvm_glob`) |
| 額外檔案 | 無,只要共用前置 |

⚠ `Trans_CRF0706/save_model/` 裡有 `epoch_9_AtkF1_0.978**6**` 和 `0.978**7**`,只差一位數但結果差約 2pp。要 **0.9787**。

---

### t2 — Transformer (Temporal)

**架構** 528 → **時間多尺度摘要** → Transformer-CRF。每個事件同時看到自己 + 三個尺度的鄰域摘要。

```
MultiChunk(d_in=528, d_out=512, scales=(256, 64, 16), mode='conv', masked=True,
           learnable_gate=True)
   每個尺度一個 depthwise Conv1d(kernel=s, groups=528),權重初始化為 1/s
       → 起始等同 masked 平均池化,訓練後可變成位置加權
   streams = [原始, 尺度256, 尺度64, 尺度16]
   每個尺度一個 learnable gate:pooled *= sigmoid(scale_gate[i])
   fuse: Linear(528×4 → 1024) → GELU → Dropout → Linear(1024 → 512) → mask → LayerNorm
   → PE → TransformerEncoder×2 → hidden2tag → CRF
```

尺度 256 ≈ 全視窗摘要、64 ≈ 中距離、16 ≈ 局部。

**訓練**

```bash
python train_t2_temporal.py --epochs 30 --batch_size 64 --seed 42
```

**推論**

```bash
python infer_t2_temporal.py --ckpt ./t2_temporal_out/save_model/epoch_N_AtkF1_x.pt \
  --o_bias_sweep 0,1,2,3,4,6,8 2>&1 | tee repro/t2_temporal.log
python collect_results.py repro/t2_temporal.log --campaigns C1,C3,C5,C6,C7
```

不給 `--ckpt` 會自動挑 `--save_dir` 裡 **AtkF1 最高**的那顆(訓練腳本只在 valid 進步時存檔,所以最高的就是 best)。

| 可調參數 | 預設 |
|---|---|
| `--scales` | `256,64,16` |
| `--epochs` `--batch_size` `--lr` | `30` `64` `3e-5` |
| `--layers` `--nhead` `--d_model` `--dropout` | `2` `8` `512` `0.3` |
| `--patience` `--min_delta` | `0` `0`(0 = 跑滿 epochs) |

模型定義在 `model_t2_t5.py`,訓練與推論 import 同一份 → 不會 drift。

---

### t3 — Transformer (hop)

**架構** 528 ⊕ LLM 256×2 = 784 → **圖 k-hop 聚合** → Transformer-CRF。

```
ga = srcNode.UUID, gb = dstNode.UUID          [B, L] long,缺值 -1
兩事件共用任一端點就相連(a==a / a==b / b==a / b==b)→ 布林鄰接 [B, L, L]
pad 位置不連 → row-normalize → A
k-hop 聚合   A^k @ x(bmm 逐次累乘)→ streams = [x, A³x, A²x, A¹x]
             每個 hop 一個 learnable gate:hk *= sigmoid(hop_gate[i])
fuse MLP     Linear(784×4 → 1024) → GELU → Dropout → Linear(1024 → 512) → mask → LayerNorm
   → PE → **同一個共用** TransformerEncoder×2 → hidden2tag → CRF
```

⚠ 圖只在 **256 事件的視窗內**建立,跨視窗不連。

**推論**

```bash
python infer_saga_llm.py \
  --ckpt Trans_CRF0706/save_model/best_hop_llm.pt \
  --ocsvm_glob model/OCSVM_finetune/event_nystroem_sgd_nu0.001_g8.0_P0.842_R0.959_F0.897.pkl \
  --o_bias_sweep 0,1,2,3,4,6,8 2>&1 | tee repro/t3_hop.log
python collect_results.py repro/t3_hop.log --campaigns C1,C3,C5,C6,C7
```

**訓練** `python train_ttp_llm.py --chunk_kind hop --use_llm 1 --epochs 10`

| | |
|---|---|
| 執行鏈 | `infer_saga_llm.py` → `ttp_model.py` → `multi_hop.py` |
| checkpoint 格式 | `{"cfg": {...}, "model": state_dict}`,結構由 cfg 重建 |
| OCSVM 旗標 | `--ocsvm_glob` |
| 額外檔案 | `SecureBERT2.0-base/`(LLM node embedding) |

⚠ 這顆的 cfg **沒有記錄 `llm_dir`**,所以用預設 `./SecureBERT2.0-base` —— **不要自己加 `--llm_dir`**,加了數字就變。

---

### t4 — Transformer (hop + Qwen)

**架構** 與 t3 完全相同,只把 LLM node embedding 換成 Qwen 產生的敘述向量。

```
節點屬性(Process→Cmdline / File→Name / Registry→Key / Network→Dstaddress)
   ↓ exe_key():剝掉 cmdline 參數,只留執行檔路徑
去重後的 executable
   ↓ Qwen 生成自然語言敘述 → SecureBERT2.0 句向量 → PCA 128
llm_node_ent2emb_128.pkl + llm_node_vocab2idx.pkl   → ./SecureBERT2.0-base-qwen/
```

**推論**

```bash
python infer_saga_llm.py \
  --ckpt Trans_CRF0706/save_model/best_hop_llm_qwen.pt \
  --ocsvm_glob model/OCSVM_finetune/event_nystroem_sgd_nu0.001_g8.0_P0.842_R0.959_F0.897.pkl \
  --o_bias_sweep 0,1,2,3,4,6,8 2>&1 | tee repro/t4_hop_qwen.log
python collect_results.py repro/t4_hop_qwen.log --campaigns C1,C3,C5,C6,C7
```

**訓練** `python train_ttp_llm.py --chunk_kind hop --use_llm 1 --llm_dir ./SecureBERT2.0-base-qwen --tag_suffix _qwen`

這顆的 cfg 記錄 `llm_dir=./SecureBERT2.0-base-qwen`,`infer_saga_llm.py` 會自動採用,不必手動指定。

---

### t5 — Transformer (hop×3)

**架構** 與 t3 同樣走圖,但**每個 hop 各自一個 Transformer**,最後才融合(t3 是先融合、共用一個)。

```
adj = row-normalized 鄰接(建法與 t3 相同)
for h in (1, 2, 3):
    x_h = A^h @ x                                  [B, L, 528]
    h_h = Transformer_h( PE( input_proj_h(x_h) ) ) 每個 hop 自己的 Linear 528→512 + Encoder×2
out = hidden2tag( fuse_norm( fuse( concat[h_1, h_2, h_3] ) ) ) → CRF
   fuse: Linear(512×3 → 512);fuse_norm: LayerNorm(512)
```

三條分支各有獨立權重,參數量約是 t3 的數倍。

**訓練**

```bash
python train_t5_hop3.py --epochs 30 --batch_size 32 --seed 42
```

**推論**

```bash
python infer_t5_hop3.py --ckpt ./t5_hop3_out/save_model/epoch_N_AtkF1_x.pt \
  --o_bias_sweep 0,1,2,3,4,6,8 2>&1 | tee repro/t5_hop3.log
python collect_results.py repro/t5_hop3.log --campaigns C1,C3,C5,C6,C7
```

| 可調參數 | 預設 |
|---|---|
| `--hops` | `1,2,3` |
| `--graph_mode` | `shared`(共用任一 UUID 端點就連;`tree` 是 KELLECT 的 PID/PPID 模式) |
| `--batch_size` | `32`(要建 `[B,256,256]` 鄰接,OOM 就調小) |
| `--epochs` `--lr` `--d_model` `--dropout` | `30` `3e-5` `512` `0.3` |

環境變數 `MULTIHOP_MASK_INVALID=1` 會啟用建圖修正(缺 UUID 的事件不互連 + 加自環)。
**必須在 import 之前設定** —— `multi_hop.py` 在 import 當下就讀它。訓練時的設定會寫進
`meta.json`,`infer_t5_hop3.py` 自動沿用,兩端不會用到不同的圖。

---

## 五、OCSVM 閘門

五個實驗共用同一顆,結果直接編碼在檔名:

```
event_nystroem_sgd_nu0.001_g8.0_P0.842_R0.959_F0.897.pkl
                   └ ν ┘ └ γ ┘ └ P ┘ └ R ┘ └ F1 ┘
```

```
StandardScaler → Nystroem(n_components=1000, gamma=8.0) → SGDOneClassSVM(nu=0.001)
判定:score = -decision_function(z);score ≥ attack_score_threshold + gate_shift → -1(異常)
```

**訓練** `OCSVM_GRANULARITY=event python train_ocsvm_finetune.py`

`--gate_shift` 負值 → 門檻降低 → gate 更容易判為異常 → 更高 recall。

---

## 六、KELLECT4APT

跟 SAGA 是**不同的資料集、不同的 embedding 模型**,不共用任何 checkpoint。
Table 12 的 Temporal / Hop 兩列出自這裡。

### 資料

```
KELLECT4APT/public_data/<TTP>/*.json      資料夾名 = 標籤;JSONL,每行一個 Windows kernel 事件
{"Event":"RegistryQueryValue","PID":4312,"PName":"powershell.exe","PPID":880,
 "TimeStamp":133..., "args":{"KeyName":"\\REGISTRY\\MACHINE\\..."}}
```

事件 → 三元組(`kellect_event.py`,訓練與推論共用這一份):

```
src  = PName                      主體行程
edge = Event                      原始事件名
dst  = Registry*     → args.KeyName
       FileIO*/File* → args.FileName(FileIOCreate 用 args.OpenPath)
       ImageLoad     → args.FileName
       Process*      → args.ImageFileName(退 args.CommandLine)
       TcpIp*/Udp*   → args.daddr
       Thread*/DiskIO*/其他 → 沒有明確物件 → **跳過這個事件**

圖 key = (PID, PPID)              hop 版建圖用,缺值 -1
良性   = huya*(BENIGN_PROCS)      主體是它的事件標成 O;./benign_procs.txt 可追加
```

`KELLECT_KEEP_BENIGN=1` 會保留 huya 事件(才能標成 O);不設則整批濾掉。

### 兩條線

| | **A 線 — trace 級** | **B 線 — event 級 + OCSVM** |
|---|---|---|
| 資料入口 | 直接吃原始 `public_data/**/*.json` | `make_dataset4SFM.py` 先建視窗資料集 |
| Embedding | `cisco-ai/SecureBERT2.0-base` → `SecureBERT2.0-K4APT[-llm]/` | `ehsanaghaei/SecureBERT` → `k4apt_sfm/` |
| 有的架構 | Transformer / **Temporal** / **Hop** | SFM BiGRU-CRF / Transformer |
| OCSVM 閘門 | 無 | 有(`svm_sfm_k4apt.py`) |
| 模型輸出 | `Trans_CRF_KELLECT4APT[_llm]/` | `sfm_k4apt_out/` `trans_k4apt_out/` |
| 對應 Table | **12** | — |

兩條線的評測層級與 embedding 模型都不同,數字**不能互相比**;各自線內才可比。

---

### A 線 — Temporal / Hop(Table 12)

**架構** 用的是 SAGA 那邊同一份 `ttp_model.TTP_Model`,所以「KELLECT 的 hop」和「SAGA 的 hop」是同一個架構。

```
event 向量  STRUCT_DIM = 256 + 16 + 256 = 528
+LLM        COMBINED_DIM = 528 + 2 × llm_dim(預設 128)= 784
視窗        WINDOW_SIZE=256  STRIDE=32
切分        每個 TTP 留 --holdout(預設 1)條 trace 當 inference,其餘 train/valid/test

chunk_kind=temporal → MultiChunk(scales=(256, 64, 16))     時間多尺度
chunk_kind=hop      → MultiHop(hops=(3, 2, 1),
                               graph_mode="tree")          ← KELLECT 專用
```

⚠ `graph_mode="tree"` 與 SAGA 的 `"shared"` 不同:

```
tree   (KELLECT) ga=PID, gb=PPID     同 process(a==a)或父子(a==b / b==a)才連
                                     **不連純同父的 siblings**
shared (SAGA)    ga=srcUUID, gb=dstUUID   共用任一端點就連(多一個 b==b)
```

**操作**

```bash
# [1] 結構化 node/edge embedding
python make_emb_K4APT.py --data_glob "./KELLECT4APT/public_data/**/*.json" \
  --save_dir ./SecureBERT2.0-K4APT-llm

# [2] LLM node embedding(--use_llm 1 才需要)
python emb_K4APT_llm.py --data_glob "./KELLECT4APT/public_data/**/*.json" \
  --save_dir ./SecureBERT2.0-K4APT-llm --llm_backend template --pca_dim 128

# [3] 訓練
python tranK_llm.py --chunk_kind temporal --use_llm 1 \
  --sb_dir ./SecureBERT2.0-K4APT-llm --llm_dir ./SecureBERT2.0-K4APT-llm --epochs 20
python tranK_llm.py --chunk_kind hop --use_llm 1 \
  --sb_dir ./SecureBERT2.0-K4APT-llm --llm_dir ./SecureBERT2.0-K4APT-llm --epochs 20

# [4] 推論(trace 級多數決)
python infer_K4APT_llm.py --ckpt ./Trans_CRF_KELLECT4APT_llm/save_model/best_temporal_llm.pt
python infer_K4APT_llm.py --ckpt ./Trans_CRF_KELLECT4APT_llm/save_model/best_hop_llm.pt
```

一鍵版(上面四步):

```bash
bash run_k4apt_llm.sh
```

| 環境變數 | 預設 | 說明 |
|---|---|---|
| `LLM_BACKEND` | `template` | `hf` / `anthropic` / `openai` |
| `HF_MODEL` | `Qwen/Qwen2.5-7B-Instruct` | `LLM_BACKEND=hf` 時用 |
| `PCA_DIM` | `128` | LLM node embedding 維度 |
| `EPOCHS` | `20` | |

**Table 12 的數字在 `tranK_llm.py` 的 log**:

```
[temporal_llm] INFERENCE (bias=X) P=0.2436 R=0.3846 F1=0.2863
[hop_llm]      INFERENCE (bias=X) P=0.2671 R=0.4103 F1=0.3094
```

口徑是 **event 級 macro,只算 GT 出現過的攻擊技術**(`atk = 用到的類別`),與 SAGA 那邊一致。
逐類明細在 `Trans_CRF_KELLECT4APT_llm/save_result/result_{TAG}.csv`,`TAG = {chunk_kind}{_llm}`。

`infer_K4APT_llm.py` 報的是另一個層級 —— **trace 級 accuracy**(整條 trace 投票出一個 TTP),
只印 `>>> Trace 級 accuracy = n/m`,沒有 P/R/F1。兩者不要混。

**純 Transformer 版**(不走 `ttp_model.py`,自己內建 `Transformer_CRF`:
`input_proj` → PE → encoder → CRF):

```bash
python make_emb_K4APT.py --data_glob "./KELLECT4APT/public_data/**/*.json" --save_dir ./SecureBERT2.0-K4APT
python tranK.py                          # → Trans_CRF_KELLECT4APT/save_model/best.pt
python infer_K4APT.py                    # 預設就讀上面那顆
```

一鍵版是 `run_k4apt.sh`。`train_ttp_kellect4apt.py` 是同功能的另一版,輸出路徑相同
(`Trans_CRF_KELLECT4APT/save_model/best.pt`,也正好是 `infer_K4APT.py` 的預設值),
兩支擇一即可 —— 但**不要交錯跑**,後跑的會蓋掉前一顆。

`tranK.py` / `tranK_ori.py` 存 `best.pt` 走的是 `ckpt_guard.safe_save`:固定檔名存檔前
會先把上一次執行留下的檔案備份成 `best.pt.bak_<時間>`,並額外寫一顆帶分數的檔名。

### A 線需要的檔案

| 路徑 | 給誰 |
|---|---|
| `KELLECT4APT/public_data/**/*.json` | 全部(每次都重讀原始檔) |
| `SecureBERT2.0-K4APT/{nodes,edges}/vocab2idx.pkl` + `*_ent2emb_*.pkl` | `tranK.py` / `infer_K4APT.py` |
| `SecureBERT2.0-K4APT-llm/` 同上 + `llm_node_ent2emb_128.pkl` + `llm_node_vocab2idx.pkl` | `tranK_llm.py` / `infer_K4APT_llm.py` |
| `Trans_CRF_KELLECT4APT*/save_result/infer_holdout_files*.txt` | 推論時決定要跑哪些 trace |
| `kellect_event.py` `ttp_model.py` `multi_chunk.py` `multi_hop.py` | import |
| `benign_procs.txt` | 選用,追加良性 process |

---

### B 線 — SFM 基線 / Transformer + OCSVM cascade

**資料**

```
public_data/**/*.json
   │ make_dataset4SFM.py:ehsanaghaei/SecureBERT mean-pool 768 → PCA
   ▼
k4apt_sfm/
   nodes_ent2emb_256.pkl  [Vn+1, 256] float32   末列 = pad/OOV 全零
   edges_ent2emb_16.pkl   [Ve+1,  16] float32
   train/valid/test_data.pkl   list[dict]:
       src / rel / dst   [256] int64   embedding 表的索引(OOV → 末列)
       label_idx         [256] int64
       mask              [256] bool
       process           str
```

視窗存的是**索引不是向量**(baked 528 大約 88 倍,load 就 OOM)。訓練時每批在 **CPU** 查表組成
`[B,256,528]` 再搬 GPU;embedding 表全程留 CPU(KELLECT vocab 很大,整表上 GPU 會 OOM)。

```
tagger  sfm   : BiGRU(2 層, hidden 128, 雙向) → hidden2tag(256→C) → CRF
        trans : input_proj 528→512 → PE → TransformerEncoder×2(8 頭, ff 1024) → CRF
OCSVM   benign = huya*,malicious = 其餘;沿用同一個嵌入空間,結果編碼在檔名
        nu_0.06_p_0.842_r_0.959_f_0.897.pkl
```

**操作**

```bash
bash run_sfm_k4apt.sh                 # 建 k4apt_sfm → SFM 訓練 → OCSVM → cascade 推論
bash run_trans_k4apt.sh               # 同一份資料訓 Transformer + cascade 推論
WITH_SFM=1 bash run_kellect.sh        # 建 k4apt_dense(較密的切分)+ Transformer + SFM 對照
```

| 環境變數 | 預設 | 說明 |
|---|---|---|
| `DATA_GLOB` | `./KELLECT4APT/public_data/**/*.json` | 記得加 `**` |
| `EPOCHS` / `BATCH` | `10` / `32` | OOM 就把 BATCH 調小 |
| `DEVICE` / `GPU` | `auto` / — | `DEVICE=cpu` 退路 |
| `D_MODEL` `LAYERS` `DROPOUT` `LR` | `512` `2` `0.2` `5e-5` | 資料少就縮小模型 |
| `STRIDE` `MAX_WIN` `VALID_FRAC` | `32` `120` `0.1` | 只有 `run_kellect.sh` 有 |
| `REUSE_EMB` | `./k4apt_sfm` | 重用 embedding,跳過 SecureBERT+PCA(RAM 尖峰) |
| `WITH_SFM` | `0` | `1` = 順便跑 SFM 基線對照 |

⚠ **`k4apt_sfm` 與 `k4apt_dense` 是兩份不同切分的資料集**(stride 64/60 vs 32/120、valid 來源不同),
checkpoint 要配對應的那份,混用會得到假的比較。

不用 gate 的純 TTP 評估(event / window / trace 三個層級 + 混淆配對):

```bash
python infer_ttp_k4apt.py --data_dir ./k4apt_sfm --out_dir ./trans_k4apt_out
```

---

### 輸出長什麼樣

A 線:

```
[結果] trace 級 TTP 準確率 = 21/34 = 0.6176                        ← infer_K4APT.py
[結果] 樣本級 TTP 分類 (macro over 28 類)  P=0.5821 R=0.5433 F1=0.5502
>>> Trace 級 accuracy = 23/34 = 0.6765                             ← infer_K4APT_llm.py
```

⚠ `infer_K4APT_llm.py`(temporal / hop)**只印 accuracy,沒有 P/R/F1**;`infer_K4APT.py`(plain)
兩個都有。所以 A 線內部要互相比,共同的欄位只有 accuracy。Table 12 的 P/R/F1 不是從這裡來的,
是從 `tranK_llm.py` 訓練 log 的 `[*_llm] INFERENCE` 那行(見上)。

B 線:

```
   BiGRU  macro P=41.20 R=33.70 F1=35.90 | micro ...       ← infer_sfm_k4apt.py
 Cascade  macro P=28.10 R=19.40 F1=21.80 | micro ...

 O-bias           模型 |  macro P  macro R  macro F1 | ...  ← infer_trans_k4apt.py
    0.0    Transformer |    55.30    48.90     50.10 | ...
    0.0        Cascade |    30.20    22.10     24.00 | ...

[1] event   n= 120345  acc= 61.20%  |  macro P=44.10 ...    ← infer_ttp_k4apt.py
[2] window  n=   1820  acc= 70.50%  |  macro P=52.30 ...
[3] trace   n=     34  acc= 79.40%  |  macro P=63.00 ...
```

**純模型** = 直接用 tagger;**Cascade** = OCSVM 判 benign 的位置強制標 `O`。
Cascade 較高 = gate 擋掉了對良性事件的誤判;較低 = gate 把該偵測的也擋掉了。

### 收成一張表

```bash
bash run_k4apt_infer.sh 2>&1 | tee -i repro/k4apt_all.log
```

只做推論,逐項檢查 checkpoint;缺的會跳過並印出當初訓練的指令。最後用 `collect_k4apt.py`
把各 log 收成表,A / B 兩線分開列(它解析各腳本原本就會印的行,不改任何推論腳本)。

| key | 推論腳本 | checkpoint |
|---|---|---|
| `temporal` | `infer_K4APT_llm.py` | `Trans_CRF_KELLECT4APT_llm/save_model/best_temporal_llm.pt` |
| `hop` | `infer_K4APT_llm.py` | `.../best_hop_llm.pt` |
| `trans_a` | `infer_K4APT.py` | `Trans_CRF_KELLECT4APT/save_model/best.pt` |
| `sfm` | `infer_sfm_k4apt.py` | `sfm_k4apt_out/best.pt` |
| `trans_b` | `infer_trans_k4apt.py` | `trans_k4apt_out/best.pt` |
| `trans_b3` | `infer_ttp_k4apt.py` | `trans_k4apt_out/best.pt` |

```bash
KEYS="temporal hop" bash run_k4apt_infer.sh      # 只跑 Table 12 那兩列
TABLE_ONLY=1 bash run_k4apt_infer.sh             # 不推論,只用既有 log 印表
python collect_k4apt.py --logs repro/k4apt --md --csv k4apt.csv
```

### KELLECT4APT 的坑

1. **資料沒有良性標記時,Cascade 一定比較低。** TTP 資料夾裡全是攻擊行為,只有 `huya*` 會標 O。
   holdout 沒有 O 時,gate 把事件改成 O 只會製造錯誤,O-bias 往上也只會傷分數(最佳必為 0)。
   推論腳本偵測到會警告 —— 那種情況看「純模型」那欄,或直接 `NO_GATE=1`。
2. **A 線與 B 線的 embedding 模型不同**,`SecureBERT2.0-K4APT/` 和 `k4apt_sfm/` 的表不能互換。
3. **`Thread*` / `DiskIO*` 事件會被丟掉**(沒有明確的物件節點),所以視窗裡的事件數 < 原始檔的事件數。
4. `run_kellect.sh` 的 valid 是從 train 視窗切的,而視窗有重疊(stride < window)→ valid 與 train
   可能共享事件,分數偏樂觀。valid 只用來選 epoch / O-bias,**要報的成績是 holdout**。
5. **embedding 表留在 CPU 是刻意的。** KELLECT 的 node vocab 很大,整表搬 GPU 會 OOM。
   訓練時每批在 CPU 查表組成 `[B,256,528]` 再搬 GPU。不要「順手優化」成整表上 GPU。
6. **兩條線不能放進同一列。** A 線報 trace accuracy,B 線報 event macro F1,層級不同,
   硬湊成一張表的數字沒有意義。

### 檔案清單

共用:

| 檔案 | 角色 |
|---|---|
| `kellect_event.py` | 事件 → `(src, edge, dst)` / 標籤 / 圖 key `(PID, PPID)`。**所有腳本共用這一份** |
| `ttp_model.py` | `TTP_Model` — A 線 temporal/hop 的模型(與 SAGA 的 t2/t3 共用) |
| `multi_chunk.py` | `MultiChunk` — 時間多尺度 |
| `multi_hop.py` | `MultiHop` / `MultiHopParallel` / `build_adj` — 圖 k-hop |
| `ckpt_guard.py` | `safe_save` — 固定檔名存檔前備份上一次的 |
| `benign_procs.txt` | 選用,追加良性 process 清單 |

A 線:

| 檔案 | 角色 |
|---|---|
| `make_emb_K4APT.py` | 結構化 node/edge embedding → `SecureBERT2.0-K4APT[-llm]/` |
| `emb_K4APT_llm.py` | LLM node 敘述 → embedding → `llm_node_ent2emb_128.pkl` |
| `tranK.py` | plain Transformer-CRF 訓練(`train_ttp_kellect4apt.py` 是同功能的另一版) |
| `tranK_llm.py` | temporal / hop(±LLM)訓練,用 `TTP_Model` |
| `infer_K4APT.py` | plain 的推論(trace 級準確率 + 樣本級 macro) |
| `infer_K4APT_llm.py` | temporal / hop 的推論(trace 級 accuracy) |
| `run_k4apt.sh` / `run_k4apt_llm.sh` | plain / temporal+hop 一鍵 |
| `fewshot_k4apt.py` | 32-way 3-shot 評估 |
| `list_processes_K4APT.py` | 列出資料裡有哪些 process(挑良性清單用) |

B 線:

| 檔案 | 角色 |
|---|---|
| `make_dataset4SFM.py` | 建視窗資料集 → `k4apt_sfm` / `k4apt_dense` |
| `make_svm_data4SFM.py` | 建 OCSVM 的 benign / malicious 事件 embedding |
| `svm_sfm_k4apt.py` | OCSVM 訓練(nu 掃描;結果編碼在檔名) |
| `train_sfm_k4apt.py` / `infer_sfm_k4apt.py` | SFM BiGRU-CRF |
| `train_trans_k4apt.py` / `infer_trans_k4apt.py` | Transformer-CRF + cascade |
| `infer_ttp_k4apt.py` | 不用 gate 的三層級評估(event / window / trace)+ 混淆配對 |
| `check_o_labels.py` | 檢查資料裡有沒有 O 標記 |
| `run_sfm_k4apt.sh` / `run_trans_k4apt.sh` / `run_kellect.sh` | 一鍵腳本 |

推論與收表:

| 檔案 | 角色 |
|---|---|
| `run_k4apt_infer.sh` | 逐項跑既有 checkpoint 的推論 |
| `collect_k4apt.py` | 解析 log → 比較表(A / B 分開) |

---

## 七、輸出怎麼看

所有推論腳本共用格式:

```
 O-bias |   AVG P   AVG R  AVG F1      ← 8 campaign 平均,逐 bias 一列
    8.0 |  0.6404  0.7292  0.6452
>>> 最佳 O-bias=8.0  AVG token-F1=0.6452  (P=0.6404 R=0.7292)  對照 SFM = 0.6864
--- 最佳 O-bias=8.0 逐檔 ---
C1.json | Atk P:0.9298 R:0.9286 F1:0.9201   ← 只有「最佳 bias」那組會印逐檔明細
```

### ⚠ 一定會踩的坑

log 印的 `AVG token-F1` 是 **8 個 campaign(C1–C8)** 的平均,**不是論文數字**。
論文只用 **5 個**:C1 / C3 / C5 / C6 / C7。

```bash
python collect_results.py repro/t1_plain.log --campaigns C1,C3,C5,C6,C7
```

換算後才是[第一節](#一論文完整數據)那張表的數字。同一次執行會有兩個不同的數字,別拿錯。

`infer_saga_llm.py` 開頭多一行 `chunk=<temporal|hop>, LLM=<True|False>`;
`infer_t2_temporal.py` / `infer_t5_hop3.py` 會逐檔印 `[k/8] Cx.json N events …` 進度。

---

## 八、一次跑完與比對

### 逐項比對論文數字

```bash
bash test_reproduce.sh 2>&1 | tee -i repro/test_all.log
```

推論 → 換算 5-campaign → 與 `expected_results.json` 比對 → 印每一列的
逐 campaign 差與 OK / WARN / FAIL。容差 ±0.5pp 為 OK、±2.0pp 為 WARN。

| 環境變數 | 作用 |
|---|---|
| `SKIP_RUN=1` | 沿用既有 log,只重新比對(秒級) |
| `ONLY=t3_hop` | 只跑一項 |
| `TOL=1.0` / `WARN_TOL=5` | 放寬容差(百分點) |

### 單獨看某一列的逐 campaign 明細

```bash
python check_expected.py --log repro/t3_hop.log --key t3_hop --campaigns C1,C3,C5,C6,C7
```

```
逐 campaign F1(%)
  campaign         實測       期望        差
  C1            64.03    64.03    +0.00  OK
  C3            45.65    45.65    +0.00  OK
  ...
```

⚠ **平均對得上但逐 campaign 分佈不同 = 不同的模型。** 一定要看逐 campaign,不能只看平均。

### t2 / t5 一起跑

```bash
bash run_t2_t5.sh 2>&1 | tee -i repro/t2t5.log
```

訓練 → 級聯推論 → 印比較表。先驗證接線(秒級,不碰資料):

```bash
SMOKE=1 bash run_t2_t5.sh
```

會檢查 t5 真的走圖(改 `ga`/`gb` 輸出會變)、t2 真的不走圖、padding 沒有洩漏到有效位置。

| 環境變數 | 預設 | 說明 |
|---|---|---|
| `KEY` | `both` | `t2` / `t5` 只跑一個 |
| `EPOCHS` | `30` | |
| `BATCH_T2` / `BATCH_T5` | `64` / `32` | |
| `PATIENCE` / `MIN_DELTA` | `0` / `0` | valid 連續沒進步就停;0 = 跑滿 |
| `INFER_ONLY` | `0` | 已訓好,只跑推論 |
| `GPU` | — | 指定顯卡;`DEVICE=cpu` 走 CPU |

### 打包

```bash
bash pack_verified.sh          # 只收數字驗證通過的實驗 + VERIFIED.md
bash make_deliverable.sh       # 程式碼 + 文件 + 模型 → 一個 zip
```

---

## 九、工具箱

| 指令 | 用途 |
|---|---|
| `python scan_all_ckpt.py` | 掃全專案 checkpoint,列出架構身分與該用哪支推論腳本 |
| `python dump_ckpt_cfg.py --cmd` | 讀 checkpoint 的 cfg,組出與訓練一致的推論指令 |
| `python check_expected.py --log <log> --key <t1_plain\|…>` | 單列逐 campaign 比對 |
| `python collect_results.py <log> --campaigns C1,C3,C5,C6,C7` | log → 論文口徑的表格 |
| `python model_t2_t5.py` | t2 / t5 的接線驗證(秒級,不需資料) |
| `python verify_no_drift.py` | 回歸測試:確認程式修改沒有改變推論行為 |
| `python check_package.py --dir .` | 確認零件齊全 |
| `bash explore_ckpt.sh` | 掃過所有 checkpoint 找哪顆對得上(Ctrl-C 會先印報告) |
| `bash scan_bias.sh` | 逐一固定 O-bias 跑推論 |
| `python gen_latex_table.py` | 產生論文用的 LaTeX 表格 |
| `bash run_k4apt_infer.sh` | KELLECT4APT:逐項跑既有 checkpoint 的推論 |
| `python collect_k4apt.py --logs repro/k4apt` | KELLECT4APT:log → 比較表(A / B 分開) |
| `python check_o_labels.py <data_dir>` | KELLECT4APT:檢查資料裡有沒有 O 標記 |
| `python list_processes_K4APT.py` | KELLECT4APT:列出有哪些 process(挑良性清單用) |

### checkpoint 屬於哪個架構

`scan_all_ckpt.py` 依 state_dict 的 key 判斷,載入器不能用猜的:

| key 樣式 | 模型 | 推論腳本 |
|---|---|---|
| `preproc.*` | `ttp_model.TTP_Model` | `infer_saga_llm.py` |
| `input_proj.<數字>.*` | `MultiChunk_Transformer_CRF` | `infer_saga_mc.py` |
| `input_proj.weight` | 內嵌 `Transformer_CRF` | `infer_saga.py` |
| `preproc.chunk_ops.*` | `model_t2_t5.Temporal_Transformer_CRF` | `infer_t2_temporal.py` |
| `hop_transformers.*` | `model_t2_t5.Hop3_Transformer_CRF` | `infer_t5_hop3.py` |

其他實驗(LLM 矩陣、降維、消融、DARPA)的用法見 `USAGE.md` 與 `experiments/`。

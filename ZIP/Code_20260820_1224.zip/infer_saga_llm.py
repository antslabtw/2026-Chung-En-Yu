# -*- coding: utf-8 -*-
"""
infer_saga_llm.py — LLM 版級聯推論 (OCSVM 異常 gate → Multi-chunk/hop + LLM-emb Transformer-CRF)。

搭配 train_ttp_conservative.py (ttp_model.TTP_Model) 訓出的 best_{temporal,hop}_llm.pt。
模型從 checkpoint 裡存的 cfg 重建，train/infer 不 drift；LLM embedding、chunk 種類全由 cfg 決定。
(非 LLM 的原始版本在 infer_saga.py)

用法:
    python infer_saga_llm.py                    # 自動抓最新 best_*.pt + 最新 event_*.pkl OCSVM
    python infer_saga_llm.py --ckpt ./Trans_CRF0706/save_model/best_hop_llm.pt --o_bias 2.0
"""
import os, sys, json, glob, pickle, argparse, logging
import numpy as np
import torch
from sklearn.metrics import precision_recall_fscore_support

from ttp_model import TTP_Model, build_event_feats

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

ap = argparse.ArgumentParser()
ap.add_argument("--ckpt", default=None, help="TTP checkpoint；None=抓最新 best_*.pt")
ap.add_argument("--ocsvm_glob", default="./model/OCSVM_finetune/event_*.pkl")
ap.add_argument("--o_bias", type=float, default=0.0, help="decode 時 O 的 bias，越大越保守")
ap.add_argument("--o_bias_sweep", default="0,1,2,3,4,6,8",
                help="一次推論掃多個 O-bias(emission 只算一次),逗號分隔;空字串=只用 --o_bias")
ap.add_argument("--gate_shift", type=float, default=0.0, help="OCSVM gate threshold shift，負=更高 recall")
ap.add_argument("--saga_dir", default="./SAGA_C1-C8")
ap.add_argument("--emb_dir", default="./SecureBERT2.0-SAGA")   # campaign 的 node/edge emb
ap.add_argument("--llm_dir", default="./SecureBERT2.0-base")   # LLM node emb (aux, 訓練時產)
ap.add_argument("--llmmain_dir", default="./SecureBERT2.0-base-llmmain")  # llm_main 的 256 維 node emb
ap.add_argument("--ignore_cfg_dirs", action="store_true",
                help="不要採用 checkpoint 裡記錄的 emb_dir/llm_dir,一律用命令列的值")
args = ap.parse_args()

# ---- 採用 checkpoint 記錄的 embedding 目錄 --------------------------------
# train_ttp_llm.py 把 emb_dir / llm_dir 存進 cfg,註解寫著「推論端要用完全相同的
# 切片,存進 cfg 才不會 drift」——但這裡原本沒讀,結果推論可能餵到不同的 embedding
# 表卻不會報錯,只是數字靜靜地不一樣。
# 規則:使用者沒在命令列明講,就用 cfg 記的;cfg 沒記(舊 checkpoint)就維持原本預設。
if not args.ignore_cfg_dirs:
    _ck_path = args.ckpt or sorted(glob.glob("./Trans_CRF0706/save_model/best_*.pt"),
                                   key=os.path.getmtime)[-1]
    try:
        _cfg = torch.load(_ck_path, map_location="cpu", weights_only=False).get("cfg", {})
    except Exception:
        _cfg = {}
    # 只採用 llm_dir。emb_dir **不能**採用 —— cfg 記的是「訓練時」的結構化 embedding
    # 目錄(Training_data 的 vocab),而這支是 SAGA 推論腳本,必須用 SAGA 的 vocab,
    # 否則節點全部 OOV 變成零向量。要換請自己下 --emb_dir。
    for _flag, _key in (("--llm_dir", "llm_dir"),):
        if _flag in sys.argv:                       # 命令列明講的優先
            continue
        _v = _cfg.get(_key)
        if _v:
            setattr(args, _key, _v)
            print(f"[cfg] {_key} = {_v}   (取自 checkpoint,訓練時的設定)")
    if not _cfg.get("llm_dir"):
        print("[cfg] checkpoint 沒有記錄 llm_dir(舊版 trainer)→ 沿用命令列/預設值")
    if _cfg.get("emb_dir") and _cfg["emb_dir"] != args.emb_dir:
        print(f"[cfg] 註:訓練時的 emb_dir={_cfg['emb_dir']},但 SAGA 推論固定用 "
              f"{args.emb_dir}(節點 vocab 不同,不可混用)")

WINDOW_SIZE = 256
TYPE2ATTR = {"Process": "Cmdline", "File": "Name", "Registry": "Key", "Network": "Dstaddress"}

with open("./relations.txt") as fp:
    relations = {r.strip() for r in fp.readlines()}
with open("./index2label_0201.pkl", "rb") as fp:
    index2label = pickle.load(fp)
with open(os.path.join(args.emb_dir, "nodes/vocab2idx.pkl"), "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(os.path.join(args.emb_dir, "edges/vocab2idx.pkl"), "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(os.path.join(args.emb_dir, "nodes_ent2emb_256.pkl"), "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(os.path.join(args.emb_dir, "edges_ent2emb_16.pkl"), "rb") as fp:
    edge_ent2emb = pickle.load(fp)

node_emb_tensor = torch.tensor(np.array(node_ent2emb), dtype=torch.float32)
edge_emb_tensor = torch.tensor(np.array(edge_ent2emb), dtype=torch.float32)
NODE_PAD_IDX = node_emb_tensor.shape[0]
EDGE_PAD_IDX = edge_emb_tensor.shape[0]
node_emb_tensor = torch.cat([node_emb_tensor, torch.zeros(1, 256)], 0).to(device)
edge_emb_tensor = torch.cat([edge_emb_tensor, torch.zeros(1, 16)], 0).to(device)

# ---- TTP checkpoint → 重建模型 (cfg 決定一切) ----
ckpt_path = args.ckpt or sorted(glob.glob("./Trans_CRF0706/save_model/best_*.pt"),
                                key=os.path.getmtime)[-1]
logging.info(f"loading TTP ckpt: {ckpt_path}")
ck = torch.load(ckpt_path, map_location=device, weights_only=False)
cfg = ck["cfg"]
model = TTP_Model(cfg["combined_dim"], cfg["output_size"], cfg["chunk_kind"],
                  cfg["scales"], cfg["node_pad_idx"], o_idx=cfg["o_idx"],
                  graph_mode=cfg.get("graph_mode", "shared")).to(device)
model.load_state_dict(ck["model"]); model.eval()
model.decode_o_bias = args.o_bias
logging.info(f"model: chunk_kind={cfg['chunk_kind']} use_llm={cfg['use_llm']} "
             f"combined_dim={cfg['combined_dim']}  O-bias={args.o_bias}")

# ---- LLM emb 查表 (若 cfg 有用；對齊 node idx 空間，OOV→0) ----
llm_emb_tensor = None
if cfg["use_llm"]:
    with open(os.path.join(args.llm_dir, "llm_node_vocab2idx.pkl"), "rb") as fp:
        llm_v2i = pickle.load(fp)
    cand = sorted(glob.glob(os.path.join(args.llm_dir, "llm_node_ent2emb_*.pkl")))
    with open(cand[-1], "rb") as fp:
        llm_arr = np.asarray(pickle.load(fp), dtype=np.float32)
    llm_emb_tensor = torch.zeros(node_emb_tensor.shape[0], llm_arr.shape[1])
    for s, i in node_ent2idx.items():
        j = llm_v2i.get(s)
        if j is not None:
            llm_emb_tensor[i] = torch.from_numpy(llm_arr[j])
    llm_emb_tensor = llm_emb_tensor.to(device)
    logging.info(f"LLM emb loaded: dim={llm_arr.shape[1]}")

# ---- TTP 用的 node emb:llm_main 改用純 LLM 敘述 256(OCSVM 仍用結構化 node_emb_tensor) ----
node_emb_ttp = node_emb_tensor
if cfg.get("emb_mode") == "llm_main":
    with open(f"{args.llmmain_dir}/llm_node_vocab2idx.pkl", "rb") as fp:
        _mv2i = pickle.load(fp)
    _cand = sorted(glob.glob(f"{args.llmmain_dir}/llm_node_ent2emb_*.pkl"))
    with open(_cand[-1], "rb") as fp:
        _marr = np.asarray(pickle.load(fp), dtype=np.float32)
    _t = torch.zeros(node_emb_tensor.shape[0], 256)
    for s, i in node_ent2idx.items():
        j = _mv2i.get(s)
        if j is not None:
            _t[i] = torch.from_numpy(_marr[j])
    node_emb_ttp = _t.to(device)
    logging.info("[llm_main] TTP node emb = LLM 敘述 256 維 (OCSVM 仍用結構化)")

# ---- OCSVM gate ----
ocsvm_path = sorted(glob.glob(args.ocsvm_glob), key=os.path.getmtime)[-1]
logging.info(f"loading OCSVM: {ocsvm_path}")
with open(ocsvm_path, "rb") as fp:
    ocsvm_bundle = pickle.load(fp)
if isinstance(ocsvm_bundle, dict) and ocsvm_bundle.get("granularity") == "process":
    raise ValueError("載到 process 級 OCSVM，但 infer 是 event 級。用 event 級模型。")


def apply_ocsvm(bundle, X):
    if not isinstance(bundle, dict):
        return bundle.predict(X)
    z = bundle["scaler"].transform(X)
    fm = bundle.get("feature_map")
    if fm is not None:
        z = fm.transform(z)
    a = -bundle["estimator"].decision_function(z)
    thr = bundle["attack_score_threshold"] + args.gate_shift
    return np.where(a >= thr, -1, 1)


def normalize_label(label):
    s = str(label).strip()
    if not s or s.upper() in ("BENIGN", "NORMAL", "NONE", "NULL", "O"):
        return "O"
    if s.startswith("T"):
        return s.split("_")[0].split(".")[0]
    return s


# ---- pipeline ----
@torch.no_grad()
def pipeline_evaluate(events, biases):
    srcs, rels, dsts, trues, gas, gbs = [], [], [], [], [], []
    uuid2id = {}   # 每檔 local:srcNode/dstNode UUID → int (圖用)
    for e in events:
        rel = e["relation"]
        if rel not in relations:
            continue
        src_t = e["srcNode"]["Type"]
        src_attr = e["srcNode"][TYPE2ATTR[src_t]]
        su = e["srcNode"].get("UUID")
        if e["dstNode"]:
            dst_attr = e["dstNode"][TYPE2ATTR[e["dstNode"]["Type"]]]
            du = e["dstNode"].get("UUID")
        else:
            dst_attr, du = src_attr, su
        srcs.append(node_ent2idx.get(str(src_attr), NODE_PAD_IDX))
        dsts.append(node_ent2idx.get(str(dst_attr), NODE_PAD_IDX))
        rels.append(edge_ent2idx.get(rel, EDGE_PAD_IDX))
        trues.append(e.get("label", "O"))
        gas.append(uuid2id.setdefault(su, len(uuid2id)) if su is not None else -1)
        gbs.append(uuid2id.setdefault(du, len(uuid2id)) if du is not None else -1)
    N = len(srcs)
    if N == 0:
        return [], []
    src = torch.tensor(srcs, dtype=torch.long, device=device)
    rel = torch.tensor(rels, dtype=torch.long, device=device)
    dst = torch.tensor(dsts, dtype=torch.long, device=device)
    ga = torch.tensor(gas, dtype=torch.long, device=device)
    gb = torch.tensor(gbs, dtype=torch.long, device=device)

    # Stage-1 OCSVM (在 528 結構化上)
    struct = build_event_feats(src.unsqueeze(0), rel.unsqueeze(0), dst.unsqueeze(0),
                               node_emb_tensor, edge_emb_tensor, None)[0]   # [N,528]
    ocsvm_pred = apply_ocsvm(ocsvm_bundle, struct.cpu().numpy())
    if (ocsvm_pred == 1).all():
        return {b: ["O"] * N for b in biases}, trues

    # Stage-2 TTP (逐 window);同一份 emission 對每個 O-bias 各解碼一次(掃描幾乎免費)
    preds_by = {b: [] for b in biases}
    for i in range(0, N, WINDOW_SIZE):
        cs, cr, cd = src[i:i+WINDOW_SIZE], rel[i:i+WINDOW_SIZE], dst[i:i+WINDOW_SIZE]
        cga, cgb = ga[i:i+WINDOW_SIZE], gb[i:i+WINDOW_SIZE]
        seq = cs.shape[0]
        if seq < WINDOW_SIZE:
            pad = WINDOW_SIZE - seq
            cs = torch.cat([cs, torch.full((pad,), NODE_PAD_IDX, device=device)])
            cr = torch.cat([cr, torch.full((pad,), EDGE_PAD_IDX, device=device)])
            cd = torch.cat([cd, torch.full((pad,), NODE_PAD_IDX, device=device)])
            cga = torch.cat([cga, torch.full((pad,), -1, device=device)])
            cgb = torch.cat([cgb, torch.full((pad,), -1, device=device)])
            m = torch.tensor([1]*seq + [0]*pad, dtype=torch.bool, device=device)
        else:
            m = torch.ones(WINDOW_SIZE, dtype=torch.bool, device=device)
        cs, cr, cd, m = cs.unsqueeze(0), cr.unsqueeze(0), cd.unsqueeze(0), m.unsqueeze(0)
        cga, cgb = cga.unsqueeze(0), cgb.unsqueeze(0)
        feats = build_event_feats(cs, cr, cd, node_emb_ttp, edge_emb_tensor, llm_emb_tensor)  # TTP node emb
        with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
            e_emis = model.emissions(feats, cga, cgb, m).float()
        chunk_oc = ocsvm_pred[i:i+seq]
        for b in biases:
            out = model.decode(e_emis, m, o_bias=b)[0]
            for j, idx in enumerate(out[:seq]):
                preds_by[b].append("O" if chunk_oc[j] == 1 else index2label.get(int(idx), "O"))
    return preds_by, trues


def main():
    json_paths = glob.glob(os.path.join(args.saga_dir, "*.json"))
    if not json_paths:
        print(f"[錯誤] {args.saga_dir} 沒有 json"); return
    # 要掃的 O-bias 列表(空字串 → 只用 --o_bias)
    biases = [float(x) for x in args.o_bias_sweep.split(",") if x.strip()] if args.o_bias_sweep.strip() else [args.o_bias]
    print(f"\n>>> {len(json_paths)} 個檔案，級聯推論 (chunk={cfg['chunk_kind']}, LLM={cfg['use_llm']})  O-bias 掃描={biases}")

    summ_by = {b: [] for b in biases}          # {bias: [每檔 p/r/f]}
    for path in json_paths:
        fn = os.path.basename(path)
        events = []
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        preds_by, trues = pipeline_evaluate(events, biases)
        if not trues:
            print(f"{fn:<15} | 無有效事件"); continue
        ct = [normalize_label(t) for t in trues]
        atk = sorted(set(ct) - {"O"})              # SFM 口徑: 只 macro over GT-present technique
        for b in biases:
            cp = [normalize_label(p) for p in preds_by[b]]
            if atk:
                p, r, f, _ = precision_recall_fscore_support(ct, cp, labels=atk, average="macro", zero_division=0)
            else:
                p = r = f = 0.0
            summ_by[b].append({"file": fn, "p": p, "r": r, "f": f})

    # 每個 O-bias 的 AVG,挑最佳
    print("-" * 90)
    print(f"{'O-bias':>7} | {'AVG P':>7} {'AVG R':>7} {'AVG F1':>7}")
    best = None
    for b in biases:
        s = summ_by[b]
        if not s:
            continue
        ap_ = np.mean([x["p"] for x in s]); ar_ = np.mean([x["r"] for x in s]); af_ = np.mean([x["f"] for x in s])
        star = ""
        if best is None or af_ > best[1]:
            best = (b, af_, ap_, ar_)
        print(f"{b:>7.1f} | {ap_:>7.4f} {ar_:>7.4f} {af_:>7.4f}")
    print("-" * 90)
    if best:
        print(f">>> 最佳 O-bias={best[0]}  AVG token-F1={best[1]:.4f}  (P={best[2]:.4f} R={best[3]:.4f})  對照 SFM = 0.6864")
        # 印最佳 O-bias 的逐檔明細
        print(f"--- 最佳 O-bias={best[0]} 逐檔 ---")
        for x in summ_by[best[0]]:
            print(f"{x['file']:<15} | Atk P:{x['p']:.4f} R:{x['r']:.4f} F1:{x['f']:.4f}")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""KELLECT4APT 原始 kernel 事件 → (src, edge, dst) 三元組。

tranK.py(訓練) 與 make_emb_K4APT.py(建 embedding) **共用這支**，
保證 node/edge 字串的抽取邏輯逐字一致 —— 否則兩邊對不上會全部變 OOV。

每行(JSONL)一個事件，schema:
  {"Event":.., "PID":.., "PName":.., "PPID":.., "PPName":..,
   "TimeStamp":.., "Host-UUID":.., "args":{型別專屬欄位}}

映射(依 KELLECT4APT 實際 Event 目錄整理):
  src   = PName (主體行程)
  edge  = Event (原始事件名，如 RegistryQueryValue / FileIOCreate / TcpIpSendIPV4)
  dst   = 依 Event 家族從 args 取物件:
            Registry*  -> args.KeyName
            FileIO*/File* -> args.FileName (FileIOCreate 用 args.OpenPath)
            ImageLoad  -> args.FileName
            Process*   -> args.ImageFileName (退 args.CommandLine)
            TcpIp*/Udp* -> args.daddr
            Thread*/DiskIO*/其他 -> 無明確物件 -> 跳過(回 None)
"""
import os
import json

# ----------------------------------------------------------------------
# 良性背景雜訊 process(作者刻意加入)。這些 process 當主體(PName)產生的事件全部濾掉。
#   - 小寫比對；可用 ./benign_procs.txt(一行一個 PName)追加更多。
#   - 設環境變數 KELLECT_KEEP_BENIGN=1 → 停用過濾(比較 with/without 用)。
# ----------------------------------------------------------------------
BENIGN_PROCS = {
    "huyaplayermodule.exe", "huyaexternal.exe", "huyaclient.exe", "huyaapplet.exe",
}


def load_benign_procs(path="./benign_procs.txt"):
    """從檔案追加良性 process(一行一個 PName)。回傳目前的集合大小。"""
    if os.path.exists(path):
        with open(path, encoding="utf-8", errors="ignore") as fp:
            for line in fp:
                s = line.strip()
                if s and not s.startswith("#"):
                    BENIGN_PROCS.add(s.lower())
    return len(BENIGN_PROCS)


load_benign_procs()                                   # 啟動時自動吃 ./benign_procs.txt(若有)
_FILTER_BENIGN = os.environ.get("KELLECT_KEEP_BENIGN") != "1"


def is_benign_proc(pname):
    return bool(pname) and str(pname).lower() in BENIGN_PROCS


def iter_events(path):
    """讀一個檔的所有事件，相容 JSON array 與 JSONL(每行一物件)。"""
    with open(path, encoding="utf-8", errors="ignore") as fp:
        text = fp.read()
    if not text.strip():
        return []
    try:                                    # 先試整檔 JSON
        obj = json.loads(text)
        if isinstance(obj, list):
            return obj
        if isinstance(obj, dict):
            return [obj]
    except json.JSONDecodeError:
        pass
    out = []                                # 退回 JSONL
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def _dst_str(ev, args):
    if not isinstance(args, dict):
        return None
    if ev.startswith("Registry"):
        return args.get("KeyName")
    if ev.startswith("FileIO") or ev.startswith("File"):
        return args.get("FileName") or args.get("OpenPath")
    if ev == "ImageLoad":
        return args.get("FileName")
    if ev.startswith("Process"):
        return args.get("ImageFileName") or args.get("CommandLine")
    if ev.startswith("TcpIp") or ev.startswith("UdpIp") or ev.startswith("Udp") or ev.startswith("Tcp"):
        return args.get("daddr")
    return None                             # Thread*, DiskIO*, 未知 -> 跳過


def event_to_triple(e):
    """回傳 (src, edge, dst) 三個字串；無法解析(缺主體/物件)或屬良性雜訊 → 回 None(跳過)。"""
    if not isinstance(e, dict):
        return None
    ev = e.get("Event")
    src = e.get("PName")
    if not ev or not src:
        return None
    if _FILTER_BENIGN and str(src).lower() in BENIGN_PROCS:   # 作者刻意加入的良性背景 → 丟掉
        return None
    dst = _dst_str(ev, e.get("args"))
    if dst is None or dst == "":
        return None
    return str(src), str(ev), str(dst)


def event_ts(e):
    """TimeStamp 排序用(檔內事件多半已時序，保險起見排一次)。"""
    try:
        return int(e.get("TimeStamp", 0) or 0)
    except (TypeError, ValueError):
        return 0


def event_graph_key(e):
    """圖用的節點 id = (PID, PPID)。PPID=該 process 的 parent。缺值回 -1(建圖時被排除)。
    → hop 用 PID 區分實例(同名不同 process 不會被亂連)、用 PPID 連父子。"""
    def _int(v):
        try:
            return int(v)
        except (TypeError, ValueError):
            return -1
    return _int(e.get("PID")), _int(e.get("PPID"))

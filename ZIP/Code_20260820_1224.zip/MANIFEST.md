# T1~T5 與 KELLECT4APT

產生時間 2026-08-20 12:24  於 1f9fe295e25f:/workspace/SFM

| 實驗 | runner | 訓練 | 推論 | checkpoint |
|---|---|---|---|---|
| OCSVM 異常閘門(T1~T5 共用) | `run_v2.sh` | `train_ocsvm_finetune.py` | `-` | `model/OCSVM_finetune/event_nystroem_sgd_nu0.001_g8.0_P0.842_R0.959_F0.897.pkl` |
| T1 Transformer (w/o LLM, Multichunk) | `run_v2.sh` | `train_ttp_conservative.py` | `infer_saga.py` | `Trans_CRF0706/save_model/epoch_9_AtkF1_0.9787` |
| T2 Transformer (Temporal) | `run_all.sh` | `train_ttp_llm.py` | `infer_saga_llm.py` | `Trans_CRF0706/save_model/best_temporal_llm.pt` |
| T3 Transformer (hop) | `run_all.sh` | `train_ttp_llm.py` | `infer_saga_llm.py` | `Trans_CRF0706/save_model/best_hop_llm.pt` |
| T4 Transformer (hop + Qwen) | `run_all.sh` | `train_ttp_llm.py` | `infer_saga_llm.py` | `Trans_CRF0706/save_model/best_hop_llm_qwen.pt` |
| T5 Transformer (hop*3,每 chunk 一個 transformer) | `run_multichunk.sh` | `train_multichunk.py` | `infer_saga_mc.py` | `multichunk_20260721/save_model/epoch_17_AtkF1_0.8046` |
| KELLECT4APT Transformer | `run_k4apt.sh` | `tranK.py` | `infer_K4APT.py` | `Trans_CRF_KELLECT4APT/save_model/best.pt` |
| KELLECT4APT Transformer (Temporal) | `run_k4apt_llm.sh` | `tranK_llm.py` | `infer_K4APT_llm.py` | `Trans_CRF_KELLECT4APT_llm/save_model/best_temporal_llm.pt` |
| KELLECT4APT Transformer (Hop) | `run_k4apt_llm.sh` | `tranK_llm.py` | `infer_K4APT_llm.py` | `Trans_CRF_KELLECT4APT_llm/save_model/best_hop_llm.pt` |

```bash
sed -i 's/\r$//' *.sh *.py
bash run_all_infer.sh
python show_results.py
```

# -*- coding: utf-8 -*-
"""
make_llm_embedding.py — node → LLM 敘述 → SecureBERT2.0 → PCA → node 級 vocab2idx。

LLM 敘述用「Windows process knowledge base」prompt (只針對 Process/executable node)；
File/Registry/Network node 用中性 template。輸出 JSON 會被 parse+攤平成一段文字丟 SecureBERT。

LLM backend:
    --llm_backend template            離線可跑 (陽春)
    --llm_backend hf --hf_model ...    本地 HF 模型 (Mistral/Llama/Qwen)，batched generate
    --llm_backend anthropic / openai   API

用法:
    python make_llm_embedding.py --llm_backend hf --hf_model Qwen/Qwen2.5-7B-Instruct --pca_dim 128
    python make_llm_embedding.py --llm_backend hf --hf_model meta-llama/Llama-3.1-8B-Instruct
    python make_llm_embedding.py --llm_backend hf --hf_model mistralai/Mistral-7B-Instruct-v0.3
"""
import os, re, json, math, pickle, logging, argparse
import numpy as np
from glob import glob
from tqdm import tqdm

import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.decomposition import PCA

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

TYPE2ATTR = {"Process": "Cmdline", "File": "Name", "Registry": "Key", "Network": "Dstaddress"}

# ---- 你的 prompt (R1–R4) + 明確 schema ----
EXEC_PROMPT = (
    "You are a Windows process knowledge base. Given an image path of an executable "
    "(e.g. \"C:\\Windows\\System32\\cmd.exe\", \"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe\"), "
    "output a JSON description of what that executable generally is in Windows. "
    "Use only widely documented knowledge of the executable, plus what the filesystem location implies "
    "(e.g. \"System32\" = OS binary, \"Program Files\" = installed application, \"AppData\" = user-installed component). "
    "Use neutral, factual language describing what the program is and what it standardly does. "
    "For unknown executables, describe them as generic user-mode applications without inventing details.\n\n"
    "Hard rules:\n"
    "R1  Use only documented background knowledge. State what the program is and what it standardly does.\n"
    "R2  Use concrete technical vocabulary (e.g. \"loads service DLLs\", \"renders web content\", \"interprets .ps1 scripts\").\n"
    "R3  Stay neutral and present-tense factual. Avoid the words \"suspicious\", \"malicious\", \"benign\", "
    "\"anomalous\", \"attack\", \"legitimate\", \"might\", \"could\", \"may\", \"possibly\".\n"
    "R4  Output exactly ONE valid JSON object matching the schema. No markdown, no commentary, no text outside the JSON.\n\n"
    "Schema:\n"
    "{\"name\": \"<executable file name>\", "
    "\"category\": \"OS binary | installed application | user-installed component | unknown user-mode application\", "
    "\"description\": \"<what the program is and what it standardly does>\", "
    "\"standard_operations\": [\"<operation>\", \"<operation>\"]}"
)


def template_desc(text, ntype):
    return f"A {ntype} entity in a Windows host provenance graph with value: {text}"


def build_user_prompt(text, ntype, process_only):
    """Process(executable) 用 EXEC_PROMPT；其它 node 回 None (改用 template)。"""
    if ntype == "Process" or not process_only:
        return EXEC_PROMPT + f"\n\nExecutable / image path: {text}"
    return None


def json_to_text(raw, fallback):
    """把 LLM 的 JSON 攤平成一段文字給 SecureBERT；parse 失敗就用 raw / fallback。"""
    m = re.search(r"\{.*\}", raw, re.S)
    if m:
        try:
            obj = json.loads(m.group(0))
            parts = []
            for v in obj.values():
                if isinstance(v, str):
                    parts.append(v)
                elif isinstance(v, list):
                    parts.extend(str(x) for x in v)
            if parts:
                return " ".join(parts)
        except Exception:
            pass
    raw = raw.strip()
    return raw if raw else fallback


# ---------------------------------------------------------------------------
# node vocab
# ---------------------------------------------------------------------------
def collect_node_vocab(training_glob, relations):
    node2type = {}
    paths = glob(training_glob)
    if not paths:
        raise FileNotFoundError(f"training_glob 無比對: {training_glob} (cwd={os.getcwd()})")
    logging.info(f"matched {len(paths)} training files")
    for p in tqdm(paths, desc="collect node vocab"):
        with open(p) as fp:
            events = json.load(fp)
        for e in events:
            if e["relation"] not in relations:
                continue
            for key in ("srcNode", "dstNode"):
                nd = e.get(key)
                if nd is None:
                    continue
                s = str(nd[TYPE2ATTR[nd["Type"]]])
                if s:
                    node2type.setdefault(s, nd["Type"])
    logging.info(f"unique nodes: {len(node2type)} "
                 f"(process={sum(1 for t in node2type.values() if t=='Process')})")
    return node2type


# ---------------------------------------------------------------------------
# LLM backends
# ---------------------------------------------------------------------------
def hf_token():
    """HuggingFace token:只從環境變數讀,**不寫死在程式碼**(避免隨原始碼外流)。
       gated 模型(meta-llama/*)必須提供,且要先在 HF 網頁同意授權:
           export HF_TOKEN=hf_xxxxxxxx
    """
    for k in ("HF_TOKEN", "HUGGING_FACE_HUB_TOKEN", "HUGGINGFACE_TOKEN"):
        v = os.environ.get(k)
        if v:
            return v
    return None


def _hf_kw():
    tk = hf_token()
    return {"token": tk} if tk else {}


def _load_hf(model_name, device):
    from transformers import AutoModelForCausalLM
    kw = _hf_kw()
    if not kw:
        logging.warning("沒有偵測到 HF_TOKEN;gated 模型(如 meta-llama/*)會失敗。"
                        "解法:export HF_TOKEN=hf_xxxx")
    tok = AutoTokenizer.from_pretrained(model_name, **kw)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left"                       # causal LM batched generate 要左 pad
    dtype = torch.bfloat16 if (device.type == "cuda" and torch.cuda.is_bf16_supported()) else torch.float16
    model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=dtype, **kw).to(device).eval()
    return tok, model


@torch.no_grad()
def hf_generate(user_prompts, tok, model, device, max_new_tokens=200, batch_size=8):
    outs = []
    for i in tqdm(range(0, len(user_prompts), batch_size), desc="HF generate"):
        batch = user_prompts[i:i+batch_size]
        texts = [tok.apply_chat_template([{"role": "user", "content": u}],
                                         tokenize=False, add_generation_prompt=True) for u in batch]
        enc = tok(texts, return_tensors="pt", padding=True, truncation=True, max_length=1024).to(device)
        gen = model.generate(**enc, max_new_tokens=max_new_tokens, do_sample=False,
                             pad_token_id=tok.pad_token_id)
        new = gen[:, enc["input_ids"].shape[1]:]
        outs.extend(tok.batch_decode(new, skip_special_tokens=True))
    return outs


def api_describe(user_prompt, backend):
    if backend == "anthropic":
        import anthropic
        c = anthropic.Anthropic()
        r = c.messages.create(model="claude-haiku-4-5-20251001", max_tokens=256,
                              messages=[{"role": "user", "content": user_prompt}])
        return r.content[0].text
    if backend == "openai":
        from openai import OpenAI
        c = OpenAI()
        r = c.chat.completions.create(model="gpt-4o-mini", max_tokens=256,
                                      messages=[{"role": "user", "content": user_prompt}])
        return r.choices[0].message.content
    raise ValueError(backend)


_EXE_RE = re.compile(r"^(.*?\.(?:exe|dll|sys|com|scr|bat|cmd|ps1))\b", re.I)


def exe_key(text, ntype):
    """Process node 的 cmdline → **可執行檔路徑**(去掉參數),其它型別回原字串。

    prompt 只問「executable 的 image path」,參數對敘述沒有貢獻,
    所以 "cmd.exe /c a" 與 "cmd.exe /c b" 應該共用同一份敘述 → LLM 只需生成一次。
    這是把生成次數從「不重複 cmdline 數」降到「不重複執行檔數」的關鍵(通常差 2~3 個數量級)。
    """
    if ntype != "Process":
        return text
    s = str(text).strip()
    if not s:
        return s
    if s[0] in ('"', "'"):                       # "C:\path with space\x.exe" args
        q, end = s[0], s.find(s[0], 1)
        if end > 0:
            return s[1:end].strip().lower()
    m = _EXE_RE.match(s)                          # 取到第一個副檔名為止
    if m:
        return m.group(1).strip().lower()
    return s.split()[0].strip().lower()           # 沒有副檔名 → 取第一個 token


def describe_all(nodes, node2type, args, device, cache_path):
    """回傳 {node: description}。

    ★ 以 exe_key 去重:同一個執行檔的所有 cmdline 變體只呼叫 LLM 一次。
      快取以 exe_key 為索引(讀取時相容舊的「以完整 node 字串為索引」格式)。
      關掉去重:--llm_dedup_exe 0
    """
    dedup = int(getattr(args, "llm_dedup_exe", 1))
    cache = {}
    if os.path.exists(cache_path):
        with open(cache_path, encoding="utf-8") as fp:
            cache = json.load(fp)
        logging.info(f"loaded {len(cache)} cached descriptions")

    key_of = {s: (exe_key(s, node2type[s]) if dedup else s) for s in nodes}
    n_exe = len(set(key_of.values()))
    logging.info(f"nodes={len(nodes):,} → 去重後不重複鍵={n_exe:,} "
                 f"(去重{'開啟' if dedup else '關閉'};省下 {100*(1-n_exe/max(len(nodes),1)):.1f}% 的生成量)")

    # 哪些「鍵」還沒有敘述(舊格式快取可能以完整 node 字串存,這裡一併認)
    need, seen = [], set()
    for s in nodes:
        k = key_of[s]
        if k in cache or s in cache or k in seen:
            continue
        seen.add(k); need.append((k, s))
    logging.info(f"describe {len(need):,} new keys (backend={args.llm_backend})")

    llm_keys, up_list = [], []
    for k, s in need:
        up = None if args.llm_backend == "template" \
            else build_user_prompt(k, node2type[s], args.llm_process_only)
        if up is not None:
            llm_keys.append((k, s)); up_list.append(up)
        # up is None(非 Process / template backend)→ **不寫進快取**:
        #   template_desc 是純函式,現算即可。存它們會讓快取多出數十萬筆,
        #   每次斷點存檔都要重寫一個巨大 JSON,純屬浪費(下面展開時會自動 fallback)。

    if llm_keys:
        logging.info(f"實際要呼叫 LLM 的次數:{len(llm_keys):,}")
        if args.llm_backend == "hf":
            tok, model = _load_hf(args.hf_model, device)
            # ★ 分段生成 + 分段存檔:中斷後重跑會從快取接續,不會整批重來
            chunk = max(1, int(getattr(args, "save_every", 200)))
            for st in range(0, len(llm_keys), chunk):
                sub_k = llm_keys[st:st + chunk]
                sub_p = up_list[st:st + chunk]
                raws = hf_generate(sub_p, tok, model, device, args.max_new_tokens, args.hf_batch_size)
                for (k, s), raw in zip(sub_k, raws):
                    cache[k] = json_to_text(raw, template_desc(k, node2type[s]))
                with open(cache_path, "w", encoding="utf-8") as fp:
                    json.dump(cache, fp, ensure_ascii=False)
                done = min(st + chunk, len(llm_keys))
                logging.info(f"  進度 {done:,}/{len(llm_keys):,} ({100*done/len(llm_keys):.1f}%) "
                             f"→ 已存檔 {cache_path}")
        else:  # anthropic / openai(逐筆,邊做邊存)
            for i, ((k, s), up) in enumerate(zip(tqdm(llm_keys, desc=args.llm_backend), up_list)):
                try:
                    cache[k] = json_to_text(api_describe(up, args.llm_backend), template_desc(k, node2type[s]))
                except Exception as ex:
                    logging.warning(f"api describe failed ({ex}); template fallback")
                    cache[k] = template_desc(k, node2type[s])
                if (i + 1) % 100 == 0:
                    with open(cache_path, "w", encoding="utf-8") as fp:
                        json.dump(cache, fp, ensure_ascii=False)

    with open(cache_path, "w", encoding="utf-8") as fp:
        json.dump(cache, fp, ensure_ascii=False)
    logging.info(f"saved descriptions cache → {cache_path} ({len(cache):,} 筆)")

    # 展開回「每個 node 一份敘述」(同執行檔的變體共用)
    out = {}
    for s in nodes:
        k = key_of[s]
        out[s] = cache.get(k) or cache.get(s) or template_desc(k, node2type[s])
    return out


def dedup_descriptions(descriptions):
    """敘述層級去重 → (不重複敘述清單, 每個 node 對應的列索引)。

    為什麼必要:exe 去重後,同一執行檔的所有 cmdline 共用**同一段敘述**。
    若不摺疊,SecureBERT 會把同一句話重複算幾十萬次,PCA 也在重複列上 fit,
    最後表還存 N_node 列(824,642 × 128 × 4B ≈ 422 MB),其中絕大多數是重複的向量。
    摺疊後:SecureBERT 只算不重複的、表只存不重複的列;
    vocab2idx 改指向去重後的列索引 → 查表方式 arr[v2i[node]] 完全不用改。
    """
    uniq, d2row, node_row = [], {}, []
    for d in descriptions:
        r = d2row.get(d)
        if r is None:
            r = len(uniq)
            d2row[d] = r
            uniq.append(d)
        node_row.append(r)
    n = max(len(descriptions), 1)
    logging.info(f"敘述去重:{len(descriptions):,} → {len(uniq):,} 段不重複 "
                 f"(SecureBERT 與儲存都只做這麼多;省下 {100*(1-len(uniq)/n):.1f}%)")
    return uniq, node_row


# ---------------------------------------------------------------------------
# SecureBERT embed
# ---------------------------------------------------------------------------
@torch.no_grad()
def securebert_embed(texts, tokenizer, model, device, batch_size=64, max_length=256):
    out = []
    for i in tqdm(range(math.ceil(len(texts) / batch_size)), desc="SecureBERT embed"):
        batch = texts[i*batch_size:(i+1)*batch_size]
        enc = tokenizer(batch, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
        ids = enc["input_ids"].to(device); att = enc["attention_mask"].to(device)
        hs = model(input_ids=ids, attention_mask=att).last_hidden_state
        m = att.unsqueeze(-1).float()
        avg = (hs * m).sum(1) / m.sum(1).clamp(min=1e-9)
        out.append(avg.detach().cpu().numpy())
    return np.concatenate(out, 0).astype(np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--training_glob", default="./Training_data/*/number_*/expanded_instance.json")
    ap.add_argument("--relations_txt", default="./relations.txt")
    ap.add_argument("--securebert", default="cisco-ai/SecureBERT2.0-base")
    ap.add_argument("--save_dir", default="./SecureBERT2.0-base")
    ap.add_argument("--llm_backend", default="template", choices=["template", "hf", "anthropic", "openai"])
    ap.add_argument("--hf_model", default="Qwen/Qwen2.5-7B-Instruct")
    ap.add_argument("--llm_process_only", type=int, default=1, help="1=只有 Process node 用 LLM 敘述")
    ap.add_argument("--max_new_tokens", type=int, default=200)
    ap.add_argument("--hf_batch_size", type=int, default=8)
    ap.add_argument("--desc_cache", default="./llm_node_descriptions.json")
    ap.add_argument("--pca_dim", type=int, default=128)
    ap.add_argument("--pca_out", default="./model/pca_model_llm_node.pkl",
                    help="PCA 存檔路徑。比較多個 LLM 時務必每個模型各一個檔,否則會互相覆蓋,"
                         "導致 SAGA 的 frozen-PCA 對齊用到別的模型的 PCA。")
    ap.add_argument("--sb_batch_size", type=int, default=64)
    ap.add_argument("--llm_dedup_exe", type=int, default=1,
                    help="1=同一執行檔的不同 cmdline 只讓 LLM 生成一次(強烈建議);0=每個 node 各生一次")
    ap.add_argument("--save_every", type=int, default=200,
                    help="每生成幾筆就存一次描述快取(中斷可續跑)")
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"device={device} | backend={args.llm_backend} | hf_model={args.hf_model}")

    with open(args.relations_txt) as fp:
        relations = {r.strip() for r in fp if r.strip()}
    node2type = collect_node_vocab(args.training_glob, relations)
    nodes = sorted(node2type)

    desc_map = describe_all(nodes, node2type, args, device, args.desc_cache)
    descriptions = [desc_map[s] for s in nodes]

    uniq, node_row = dedup_descriptions(descriptions)

    logging.info(f"loading SecureBERT: {args.securebert}")
    tok = AutoTokenizer.from_pretrained(args.securebert, **_hf_kw())
    sb = AutoModel.from_pretrained(args.securebert, trust_remote_code=True, **_hf_kw()).to(device).eval()
    emb768 = securebert_embed(uniq, tok, sb, device, batch_size=args.sb_batch_size)
    logging.info(f"SecureBERT emb: {emb768.shape}")

    dim = min(args.pca_dim, emb768.shape[0], emb768.shape[1])
    pca = PCA(n_components=dim)
    reduced = pca.fit_transform(emb768).astype(np.float32)
    logging.info(f"PCA: {emb768.shape} -> {reduced.shape}")

    os.makedirs(args.save_dir, exist_ok=True)
    # vocab2idx 指向「去重後的列」→ 表只存不重複的向量,查表方式不變:arr[v2i[node]]
    with open(os.path.join(args.save_dir, "llm_node_vocab2idx.pkl"), "wb") as fp:
        pickle.dump({s: node_row[i] for i, s in enumerate(nodes)}, fp)
    with open(os.path.join(args.save_dir, f"llm_node_ent2emb_{dim}.pkl"), "wb") as fp:
        pickle.dump(reduced, fp)
    logging.info(f"表大小:{reduced.shape[0]:,} 列 × {dim} 維 "
                 f"= {reduced.nbytes/2**20:.1f} MB(未去重會是 "
                 f"{len(nodes)*dim*4/2**20:.1f} MB)")
    os.makedirs(os.path.dirname(args.pca_out) or ".", exist_ok=True)
    with open(args.pca_out, "wb") as fp:
        pickle.dump(pca, fp)
    logging.info(f"[✓] saved llm_node_vocab2idx.pkl + llm_node_ent2emb_{dim}.pkl (dim={dim})")
    logging.info(f"[✓] PCA → {args.pca_out}(SAGA 對齊時要用同一顆)")


if __name__ == "__main__":
    main()

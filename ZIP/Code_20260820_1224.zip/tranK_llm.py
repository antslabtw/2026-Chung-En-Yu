# -*- coding: utf-8 -*-
"""
tranK_llm.py — KELLECT4APT TTP tagger，LLM 版 (Multi-chunk 時間 / 圖 hop + LLM embedding)。

跟 train_ttp_kellect4apt.py 同資料/切分邏輯，差別:
  - 模型改用 ttp_model.TTP_Model (--chunk_kind temporal|hop)，train/infer 共用不 drift。
  - concat LLM node embedding (emb_K4APT_llm.py 產)。
  - huya* 良性 process 的事件「保留」並逐 event 標成 O (讓模型學到它們是 benign)，
    不是丟掉 (KELLECT_KEEP_BENIGN=1)。
  - 每個 TTP 留 --holdout 個樣本做 inference，其餘 train/valid/test；best-on-valid + O-bias。
"""
import os
os.environ.setdefault("KELLECT_KEEP_BENIGN", "1")   # 保留 huya* 事件 → 標 O

import re, gc, math, hashlib, random, pickle, logging, argparse, atexit
from glob import glob
from collections import defaultdict
import numpy as np
import pandas as pd
from tqdm import tqdm
from sklearn.metrics import classification_report, precision_recall_fscore_support

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from kellect_event import (iter_events, event_to_triple, event_ts, event_graph_key,
                           is_benign_proc, BENIGN_PROCS)
from ttp_model import TTP_Model, build_event_feats, scales_for, STRUCT_DIM

# ======================================================================
SEED, WINDOW_SIZE, STRIDE, BATCH_SIZE = 42, 256, 32, 64
EPOCHS, LR, WARMUP_RATIO, PATIENCE = 20, 1e-4, 0.1, 0
HOLDOUT_PER_CLASS, VAL_RATIO, TEST_RATIO, MIN_TRAIN = 1, 0.2, 0.2, 1
ATTACK_CLASS_WEIGHT, O_CLASS_WEIGHT, FOCAL_GAMMA = 3.0, 1.0, 2.0
O_DECODE_BIAS, O_BIAS_SWEEP, RECALL_TOL = None, [0.0, 0.5, 1.0, 2.0, 4.0, 8.0], 0.02
EVAL_NONOVERLAP, EVAL_MAX_WINDOWS = True, 8000
DATA_ROOT = "./KELLECT4APT/public_data"
VARIANT_RE = re.compile(r"-\d+$")
BENIGN_NAMES = {"O", "benign", "BENIGN", "normal", "NORMAL", "none", "NONE"}
# ======================================================================

ap = argparse.ArgumentParser()
ap.add_argument("--chunk_kind", choices=["temporal", "hop"], default="temporal")
ap.add_argument("--use_llm", type=int, default=1)
ap.add_argument("--data_root", default=DATA_ROOT)
ap.add_argument("--sb_dir", default="./SecureBERT2.0-K4APT-llm")   # 結構化 emb (含 huya)
ap.add_argument("--llm_dir", default="./SecureBERT2.0-K4APT-llm")  # LLM node emb
ap.add_argument("--holdout", type=int, default=HOLDOUT_PER_CLASS)
ap.add_argument("--epochs", type=int, default=EPOCHS)
ap.add_argument("--lr", type=float, default=LR)
ap.add_argument("--min_train", type=int, default=MIN_TRAIN)
ap.add_argument("--strip_variant", action="store_true", default=False)
ap.add_argument("--rebuild_cache", action="store_true")
args, _ = ap.parse_known_args()
DATA_ROOT, SB_DIR, LLM_DIR = args.data_root, args.sb_dir, args.llm_dir
HOLDOUT_PER_CLASS, MIN_TRAIN, EPOCHS, LR = args.holdout, args.min_train, args.epochs, args.lr
STRIP_VARIANT_SUFFIX = args.strip_variant
USE_LLM = bool(args.use_llm)
TAG = f"{args.chunk_kind}{'_llm' if USE_LLM else ''}"
MODEL_SAVE = "./Trans_CRF_KELLECT4APT_llm/save_model"
RESULT_SAVE = "./Trans_CRF_KELLECT4APT_llm/save_result"
CACHE_TRACES = "./kellect4apt_traces_llm.pt"

random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")
logging.info(f"chunk_kind={args.chunk_kind} use_llm={USE_LLM} device={device}")

# ---- 結構化 node/edge emb ----
with open(f"{SB_DIR}/nodes/vocab2idx.pkl", "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/edges/vocab2idx.pkl", "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/nodes_ent2emb_256.pkl", "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(f"{SB_DIR}/edges_ent2emb_16.pkl", "rb") as fp:
    edge_ent2emb = pickle.load(fp)

node_emb_tensor = torch.tensor(np.array(node_ent2emb), dtype=torch.float32).to(device)
edge_emb_tensor = torch.tensor(np.array(edge_ent2emb), dtype=torch.float32).to(device)
NODE_PAD_IDX = node_emb_tensor.shape[0]
EDGE_PAD_IDX = edge_emb_tensor.shape[0]
node_emb_tensor = torch.cat([node_emb_tensor, torch.zeros(1, 256).to(device)], 0)
edge_emb_tensor = torch.cat([edge_emb_tensor, torch.zeros(1, 16).to(device)], 0)

# ---- LLM node emb (對齊 node index 空間，OOV→0) ----
llm_emb_tensor, LLM_DIM = None, 0
if USE_LLM:
    with open(f"{LLM_DIR}/llm_node_vocab2idx.pkl", "rb") as fp:
        llm_v2i = pickle.load(fp)
    cand = sorted(glob(f"{LLM_DIR}/llm_node_ent2emb_*.pkl"))
    assert cand, f"找不到 llm_node_ent2emb_*.pkl，先跑 emb_K4APT_llm.py ({LLM_DIR})"
    with open(cand[-1], "rb") as fp:
        llm_arr = np.asarray(pickle.load(fp), dtype=np.float32)
    LLM_DIM = llm_arr.shape[1]
    llm_emb_tensor = torch.zeros(node_emb_tensor.shape[0], LLM_DIM)
    hit = 0
    for s, i in node_ent2idx.items():
        j = llm_v2i.get(s)
        if j is not None:
            llm_emb_tensor[i] = torch.from_numpy(llm_arr[j]); hit += 1
    llm_emb_tensor = llm_emb_tensor.to(device)
    logging.info(f"LLM emb: dim={LLM_DIM} matched {hit}/{len(node_ent2idx)}")

COMBINED_DIM = STRUCT_DIM + (2 * LLM_DIM if USE_LLM else 0)
logging.info(f"COMBINED_DIM={COMBINED_DIM}")


# ---- label (資料夾名；huya* 事件標 O) ----
def label_of(json_path):
    name = os.path.basename(os.path.dirname(json_path))
    if STRIP_VARIANT_SUFFIX:
        name = VARIANT_RE.sub("", name)
    return "O" if name in BENIGN_NAMES else name


def scan_dataset(root):
    paths = glob(os.path.join(root, "**", "*.json"), recursive=True)
    if not paths:
        raise FileNotFoundError(f"{root} 底下沒有 .json (指到 KELLECT4APT/public_data)")
    by_class = defaultdict(list)
    for p in paths:
        by_class[label_of(p)].append(p)
    return by_class, paths


by_class_all, all_json = scan_dataset(DATA_ROOT)
labels_sorted = sorted(by_class_all.keys())
ordered = ["O"] + [l for l in labels_sorted if l != "O"]   # 強制有 O (huya 事件會標 O)
label2index = {l: i for i, l in enumerate(ordered)}
index2label = {i: l for l, i in label2index.items()}
OUTPUT_SIZE = len(label2index)
O_IDX = label2index["O"]
PAD_LABEL = O_IDX
logging.info(f"總 .json={len(all_json)} 類別數(含O)={OUTPUT_SIZE}")


def process_sample(json_path, label_idx):
    events = iter_events(json_path)
    events.sort(key=event_ts)
    seq_src, seq_rel, seq_dst, seq_lab, seq_ga, seq_gb = [], [], [], [], [], []
    for e in events:
        tri = event_to_triple(e)
        if tri is None:
            continue
        src, edge, dst = tri
        seq_src.append(node_ent2idx.get(src, NODE_PAD_IDX))
        seq_rel.append(edge_ent2idx.get(edge, EDGE_PAD_IDX))
        seq_dst.append(node_ent2idx.get(dst, NODE_PAD_IDX))
        seq_lab.append(O_IDX if is_benign_proc(src) else label_idx)   # huya* → 標 O
        pid, ppid = event_graph_key(e)                                # 圖 key = PID/PPID
        seq_ga.append(pid); seq_gb.append(ppid)
    n = len(seq_src)
    if n == 0:
        return []
    seq_msk = [1] * n
    if n % WINDOW_SIZE != 0:
        pad = (WINDOW_SIZE - n if n < WINDOW_SIZE
               else ((n - WINDOW_SIZE) // STRIDE + 1) * STRIDE + WINDOW_SIZE - n)
        seq_src += [NODE_PAD_IDX] * pad; seq_rel += [EDGE_PAD_IDX] * pad
        seq_dst += [NODE_PAD_IDX] * pad; seq_lab += [PAD_LABEL] * pad; seq_msk += [0] * pad
        seq_ga += [-1] * pad; seq_gb += [-1] * pad                    # pad 圖 key = -1 (被 mask 排除)
    out = []
    for i in range(0, len(seq_src) - WINDOW_SIZE + 1, STRIDE):
        out.append({
            "src": torch.tensor(seq_src[i:i+WINDOW_SIZE], dtype=torch.long),
            "rel": torch.tensor(seq_rel[i:i+WINDOW_SIZE], dtype=torch.long),
            "dst": torch.tensor(seq_dst[i:i+WINDOW_SIZE], dtype=torch.long),
            "ga": torch.tensor(seq_ga[i:i+WINDOW_SIZE], dtype=torch.long),
            "gb": torch.tensor(seq_gb[i:i+WINDOW_SIZE], dtype=torch.long),
            "label_idx": torch.tensor(seq_lab[i:i+WINDOW_SIZE], dtype=torch.long),
            "mask": torch.tensor(seq_msk[i:i+WINDOW_SIZE], dtype=torch.bool),
            "process": json_path,
        })
    return out


def build_or_load_cache():
    if os.path.exists(CACHE_TRACES) and not args.rebuild_cache:
        blob = torch.load(CACHE_TRACES, weights_only=False)
        if (blob.get("label2index") == label2index and blob.get("sb_dir") == SB_DIR
                and blob.get("graph") == "pid_ppid"):
            logging.info(f"載入視窗快取 {CACHE_TRACES}")
            return blob["by_class"]
        logging.warning("快取 label/sb_dir/graph 不符 → 重建")
    by_class = defaultdict(list)
    for lab, paths in tqdm(by_class_all.items(), desc="processing samples"):
        li = label2index[lab]
        for p in paths:
            w = process_sample(p, li)
            if w:
                by_class[lab].append({"path": p, "windows": w})
        gc.collect()
    torch.save({"by_class": dict(by_class), "label2index": label2index, "sb_dir": SB_DIR,
                "graph": "pid_ppid"}, CACHE_TRACES)
    return by_class


by_class = build_or_load_cache()


# ---- 切分：每類 holdout N 做 inference，其餘 train/valid/test ----
def _stable_seed(s):
    return int(hashlib.md5(s.encode("utf-8")).hexdigest(), 16) % (2**32)


def split_counts(R):
    if R <= 0:
        return 0, 0, 0
    te = int(round(R * TEST_RATIO)); va = int(round(R * VAL_RATIO)); tr = R - te - va
    if tr < MIN_TRAIN:
        tr = min(R, MIN_TRAIN); rem = R - tr; denom = VAL_RATIO + TEST_RATIO
        te = int(round(rem * (TEST_RATIO / denom))) if denom > 0 else 0; va = rem - te
    return tr, va, te


eval_sub = max(1, WINDOW_SIZE // STRIDE) if EVAL_NONOVERLAP else 1


def _cap(windows, rng):
    if EVAL_MAX_WINDOWS and len(windows) > EVAL_MAX_WINDOWS:
        idx = list(range(len(windows))); rng.shuffle(idx)
        windows = [windows[i] for i in sorted(idx[:EVAL_MAX_WINDOWS])]
    return windows


os.makedirs(RESULT_SAVE, exist_ok=True); os.makedirs(MODEL_SAVE, exist_ok=True)
train_w, val_w, test_w, infer_w = [], [], [], []
holdout_files, class_rows, used_classes, dropped = [], [], [], []
for lab in sorted(by_class):
    if lab == "O":
        continue
    samples = sorted(by_class[lab], key=lambda d: d["path"])
    random.Random(_stable_seed(lab) ^ SEED).shuffle(samples)
    hold, rest = samples[:HOLDOUT_PER_CLASS], samples[HOLDOUT_PER_CLASS:]
    if len(rest) < MIN_TRAIN or len(hold) < HOLDOUT_PER_CLASS:
        dropped.append((lab, len(samples))); continue
    tr, va, te = split_counts(len(rest))
    tr_s, va_s, te_s = rest[:tr], rest[tr:tr+va], rest[tr+va:tr+va+te]
    for d in tr_s: train_w.extend(d["windows"])
    for d in va_s: val_w.extend(d["windows"][::eval_sub])
    for d in te_s: test_w.extend(d["windows"][::eval_sub])
    for d in hold:
        infer_w.extend(d["windows"][::eval_sub]); holdout_files.append((lab, d["path"]))
    used_classes.append(lab)
    class_rows.append({"label": lab, "total": len(samples), "inference": len(hold),
                       "train": len(tr_s), "valid": len(va_s), "test": len(te_s)})
val_w = _cap(val_w, random.Random(SEED)); test_w = _cap(test_w, random.Random(SEED + 1))

with open(f"{RESULT_SAVE}/infer_holdout_files_{TAG}.txt", "w", encoding="utf-8") as fp:
    for lab, p in holdout_files:
        fp.write(f"{lab}\t{p}\n")
pd.DataFrame(class_rows).to_csv(f"{RESULT_SAVE}/split_per_class_{TAG}.csv", index=False)
atk = sorted({label2index[l] for l in used_classes})
logging.info(f"可用類別={len(used_classes)} 跳過={len(dropped)} | "
             f"win: train={len(train_w)} val={len(val_w)} test={len(test_w)} infer={len(infer_w)}")
if not train_w:
    raise RuntimeError("train 集為空：類別樣本太少。")


# ---- model / feats ----
class_weights = torch.ones(OUTPUT_SIZE, device=device) * ATTACK_CLASS_WEIGHT
class_weights[O_IDX] = O_CLASS_WEIGHT
model = TTP_Model(COMBINED_DIM, OUTPUT_SIZE, args.chunk_kind, scales_for(args.chunk_kind),
                  NODE_PAD_IDX, class_weights=class_weights, o_idx=O_IDX,
                  focal_gamma=FOCAL_GAMMA, graph_mode="tree").to(device)   # KELLECT: PID/PPID 樹
optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-5)
_WARM = max(1, int(EPOCHS * WARMUP_RATIO))
scheduler = torch.optim.lr_scheduler.LambdaLR(
    optimizer, lambda e: (e + 1) / _WARM if e < _WARM else
    0.5 * (1 + math.cos(math.pi * min(1.0, (e - _WARM) / max(1, EPOCHS - _WARM)))))
scaler = torch.amp.GradScaler("cuda")

CFG = {"chunk_kind": args.chunk_kind, "scales": list(scales_for(args.chunk_kind)),
       "use_llm": USE_LLM, "llm_dim": LLM_DIM, "combined_dim": COMBINED_DIM,
       "output_size": OUTPUT_SIZE, "node_pad_idx": NODE_PAD_IDX, "o_idx": O_IDX,
       "graph_mode": "tree", "window_size": WINDOW_SIZE, "stride": STRIDE,
       "sb_dir": SB_DIR, "llm_dir": LLM_DIR}


def _feat(data):
    src = data["src"].to(device, non_blocking=True)
    rel = data["rel"].to(device, non_blocking=True)
    dst = data["dst"].to(device, non_blocking=True)
    ga = data["ga"].to(device, non_blocking=True)
    gb = data["gb"].to(device, non_blocking=True)
    return build_event_feats(src, rel, dst, node_emb_tensor, edge_emb_tensor, llm_emb_tensor), ga, gb


def make_loader(ws, sh):
    return DataLoader(ws, batch_size=BATCH_SIZE, shuffle=sh, num_workers=0, pin_memory=True) if ws else None


@torch.no_grad()
def eval_sweep(loader, biases):
    if loader is None or not atk:
        return {b: (0.0, 0.0, 0.0) for b in biases}
    model.eval()
    trues, preds_by = [], {b: [] for b in biases}
    for data in loader:
        mask = data["mask"].to(device, non_blocking=True)
        feats, ga, gb = _feat(data)
        e = model.emissions(feats, ga, gb, mask).float()
        lc = data["label_idx"].cpu().tolist()
        for k, b in enumerate(biases):
            out = model.decode(e, mask, o_bias=b)
            for idx, pred in enumerate(out):
                preds_by[b].extend(pred)
                if k == 0:
                    trues.extend(lc[idx][:len(pred)])
    rows = {}
    for b in biases:
        p, r, f, _ = precision_recall_fscore_support(trues, preds_by[b], labels=atk,
                                                     average="macro", zero_division=0)
        rows[b] = (p, r, f)
    return rows


def recommend_bias(rows, base=0.0, tol=RECALL_TOL):
    base_r = rows.get(base, (0, 0, 0))[1]
    c = [(b, v) for b, v in rows.items() if v[1] >= base_r - tol]
    return max(c, key=lambda x: (x[1][0], x[0]))[0] if c else base


train_loader = make_loader(train_w, True)
val_loader = make_loader(val_w, False)
test_loader = make_loader(test_w, False)
infer_loader = make_loader(infer_w, False)

best_val, best_state, no_improve = float("-inf"), None, 0
for epoch in range(EPOCHS):
    model.train(); losses = []
    for data in tqdm(train_loader, desc=f"[{TAG}] ep{epoch}", leave=False):
        label = data["label_idx"].to(device, non_blocking=True)
        mask = data["mask"].to(device, non_blocking=True)
        feats, ga, gb = _feat(data)
        optimizer.zero_grad()
        with torch.amp.autocast("cuda"):
            _, loss = model(feats, ga, gb, label, mask)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(optimizer); scaler.update()
        losses.append(loss.item())
    scheduler.step()
    vf1 = eval_sweep(val_loader, [0.0])[0.0][2] if val_loader else -np.mean(losses)
    if vf1 > best_val:
        best_val = vf1
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        no_improve = 0
    else:
        no_improve += 1
    logging.info(f"[{TAG}] ep{epoch} lr={optimizer.param_groups[0]['lr']:.2e} "
                 f"loss={np.mean(losses):.4f} val_atkF1={vf1:.4f}")
    if PATIENCE and no_improve >= PATIENCE:
        break

if best_state is not None:
    model.load_state_dict(best_state)

vrows = eval_sweep(val_loader, O_BIAS_SWEEP) if val_loader else {}
deploy_bias = O_DECODE_BIAS if O_DECODE_BIAS is not None else (recommend_bias(vrows) if vrows else 0.0)
logging.info(f"[{TAG}] deploy O-bias = {deploy_bias}")

for name, loader in [("TEST", test_loader), ("INFERENCE", infer_loader)]:
    if loader is not None:
        rows = eval_sweep(loader, sorted(set([0.0, deploy_bias])))
        p, r, f = rows[deploy_bias]
        logging.info(f"[{TAG}] {name} (bias={deploy_bias}) P={p:.4f} R={r:.4f} F1={f:.4f}")

# 存 self-describing checkpoint (給 infer_K4APT_llm.py 重建)
torch.save({"model": model.state_dict(), "cfg": CFG, "deploy_o_bias": deploy_bias,
            "label2index": label2index, "index2label": index2label},
           f"{MODEL_SAVE}/best_{TAG}.pt")
logging.info(f"[{TAG}] saved {MODEL_SAVE}/best_{TAG}.pt")

# 逐類 report (test 空則用 inference holdout)
report_loader = test_loader if test_loader is not None else infer_loader
if report_loader is not None:
    model.decode_o_bias = deploy_bias
    preds, labs = [], []
    model.eval()
    with torch.no_grad():
        for data in report_loader:
            mask = data["mask"].to(device, non_blocking=True)
            feats, ga, gb = _feat(data)
            out, _ = model(feats, ga, gb, None, mask)
            lc = data["label_idx"].cpu().tolist()
            for idx, pred in enumerate(out):
                preds.extend(pred); labs.extend(lc[idx][:len(pred)])
    rep = classification_report(labs, preds, output_dict=True, zero_division=0)
    rdf = pd.DataFrame(rep).transpose().reset_index(names="label")
    rdf["label"] = rdf["label"].apply(lambda x: index2label.get(int(x), x) if str(x).isdigit() else x)
    rdf.to_csv(f"{RESULT_SAVE}/result_{TAG}.csv", index=False)
    logging.info(f"[{TAG}] saved {RESULT_SAVE}/result_{TAG}.csv")

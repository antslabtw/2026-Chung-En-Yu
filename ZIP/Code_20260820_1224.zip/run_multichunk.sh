#!/usr/bin/env bash
# ============================================================================
# Multi-chunk 版(每個 chunk 一個 transformer)。
#   train_multichunk.py : 跟原始訓練 code 完全一致(base 表 + 全新快取 *_mc.pt),只換模型。
#   infer_saga_mc.py    : 跟 infer_saga.py 一致(SAGA 表 + OCSVM + O-bias 掃描)。
#   base 訓練 + SAGA 推論 就是能跑出 0.68 的設定。不動 train_ttp_conservative.py / infer_saga.py。
# ============================================================================
set -e
CKDIR="./multichunk_20260721/save_model"

echo "==== [1/3] event 級 OCSVM(沒有才訓)===="
if ls ./model/OCSVM_finetune/event_*.pkl >/dev/null 2>&1; then
    echo "  已存在 event_*.pkl,跳過"
else
    OCSVM_GRANULARITY=event python train_ocsvm_finetune.py
fi

echo "==== [2/3] 訓練 Multi-chunk Transformer-CRF(base 表)===="
python train_multichunk.py

echo "==== [3/3] 級聯推論(SAGA 表 + O-bias 掃描)===="
CKPT="$(ls -t "$CKDIR"/epoch_*_AtkF1_* 2>/dev/null | head -1)"
if [ -z "$CKPT" ]; then
    echo "[錯誤] $CKDIR 找不到 checkpoint"; exit 1
fi
echo "  使用 checkpoint: $CKPT"
python infer_saga_mc.py --ckpt "$CKPT"

echo "===================================================================="
echo " 跟單一 transformer(epoch_9=0.68)比 AVG token-F1。"
echo "===================================================================="

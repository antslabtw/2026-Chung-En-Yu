# -*- coding: utf-8 -*-
"""
Anomaly detection (One-Class SVM) — fine-tune / 調參 (v4: per-process 聚合，衝 P>=.80 R>=.90)
=============================================================================================
延續同一條 pipeline、同樣的攻擊(-1) P/R/F1、同樣「誠實 val 選、test 只量一次、命中目標操作點」。
v4 動的是「特徵粒度」——這是 precision 上不去的真正原因，不是 nu/gamma 喬得動的：

  為什麼從 per-event 換 per-process：
    惡意 process 會做一堆「單看很正常」的 event(讀檔、開 socket)。在 event 粒度，惡意/正常
    幾乎完全重疊 → 不管 nu/gamma/threshold 怎麼調，precision 都卡住 (這正是 SFM .733 的天花板)。
    可分的訊號在「一個 process 的 event 分佈」，所以改成:
      每個 process → 對它所有 in-vocab event embedding 做 [mean ‖ max ‖ std] pooling (528*3)
                     ＋ [log1p(事件數), OOV 比例] 2 維 (← 這就是「不丟 OOV，而是當特徵」)
      → 1586 維 process 向量。train 只用 benign process，malicious = outlier。
    偵測單位變成「malicious process」(比逐 event 更有意義，也更好分)。

  GRANULARITY="process"(預設) 或 "event"(舊行為) 可切換對照。
  其餘: StandardScaler → (RBF: Nystroem 或 rbf_ocsvm) → OCSVM；
        nu(小)×gamma 聯合搜；掃整條 P-R 曲線找 P>=.80 & R>=.90 中 F1 最大點。

⚠ 誠實提醒:
  - per-process 後樣本數變少 (process 數 << event 數)，val/test 的 malicious 若很少，P/R 會較抖。
  - 偵測單位從 event 變 process，跟 SFM 的數字比較時要說清楚是 process-level。
"""
import os
import pickle
import random
import logging
import warnings

import numpy as np
from tqdm import tqdm
from sklearn.preprocessing import StandardScaler
from sklearn.kernel_approximation import Nystroem
from sklearn.svm import OneClassSVM
from sklearn.linear_model import SGDOneClassSVM
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import (precision_recall_curve, precision_recall_fscore_support,
                             roc_auc_score, average_precision_score)

# ======================================================================
# CONFIG
# ======================================================================
SEED        = 42
GRANULARITY = os.environ.get("OCSVM_GRANULARITY", "event")   # 預設 event = 528 維，對齊 infer_saga.py
#   要練回 process(1586 維): OCSVM_GRANULARITY=process python train_ocsvm_finetune.py
MODEL_KIND  = "nystroem_sgd"     # "nystroem_sgd" 或 "rbf_ocsvm" (小樣本/process 模式可考慮，較貼近 paper)

TRAIN_CAP   = 50000              # process 模式通常用不到上限；rbf_ocsvm 建議 <= 10000
VAL_CAP     = 10000
TEST_CAP    = 10000

TARGET_P    = 0.80
TARGET_R    = 0.90
TARGET_F1   = 0.80
TARGET_FPR  = float(os.environ.get("OCSVM_TARGET_FPR", "0.05"))   # 存門檻用:benign 假陽性上限
THRESHOLD_MODE = os.environ.get("OCSVM_THR_MODE", "fpr")          # "fpr"(可轉移,預設) | "pr"(舊,綁 SAGA malicious)

NU_GRID     = [0.001, 0.002, 0.005, 0.01, 0.02, 0.05]
GAMMA_MULT_GRID = [0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0]
NYSTROEM_COMPONENTS = 1000       # 分離力上限；會自動 clamp 到 <= 訓練樣本數
SAVE_DIR = os.environ.get("OCSVM_SAVE_DIR", "./model/OCSVM_finetune")
# ======================================================================

random.seed(SEED); np.random.seed(SEED)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

# ----------------------------------------------------------------------
# 載入資料 / 預訓練 embedding
# ----------------------------------------------------------------------
with open("./MaliciousProc2events.pkl", "rb") as fp:
    malicious_proc = pickle.load(fp)
with open("./BenignProc2events.pkl", "rb") as fp:
    benign_proc = pickle.load(fp)
# ⚠ OCSVM 必須跟 TTP 模型與 infer 用「同一個 PCA 空間」的表,否則 gate 收到的是別的座標系 = 亂判。
NODE_VOCAB = os.environ.get("TTP_NODE_VOCAB", "./vocab2idx_node.pkl")
EDGE_VOCAB = os.environ.get("TTP_EDGE_VOCAB", "./vocab2idx_edge.pkl")
NODE_EMB   = os.environ.get("TTP_NODE_EMB",   "./nodes_ent2emb_256.pkl")
EDGE_EMB   = os.environ.get("TTP_EDGE_EMB",   "./edges_ent2emb_16.pkl")
logging.info(f"OCSVM embedding 表: {NODE_VOCAB} | {NODE_EMB}")
with open(NODE_VOCAB, "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(EDGE_VOCAB, "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(NODE_EMB, "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(EDGE_EMB, "rb") as fp:
    edge_ent2emb = pickle.load(fp)

type2attr = {"Process": "Cmdline", "File": "Name", "Registry": "Key", "Network": "Dstaddress"}
EVENT_DIM = 528


def get_value(event):
    srcType = event["srcNode"]["Type"]
    srcAttr = event["srcNode"][type2attr[srcType]]
    dstType = event["dstNode"]["Type"] if event["dstNode"] is not None else srcType
    dstAttr = event["dstNode"][type2attr[dstType]] if event["dstNode"] is not None else srcAttr
    return srcAttr, dstAttr, event["relation"]


def _event_emb(e):
    """單一 event → 528 向量；OOV 回 None。"""
    srcAttr, dstAttr, rel = get_value(e)
    s, d = str(srcAttr), str(dstAttr)
    if s in node_ent2idx and d in node_ent2idx and rel in edge_ent2idx:
        return np.concatenate((node_ent2emb[node_ent2idx[s]],
                               edge_ent2emb[edge_ent2idx[rel]],
                               node_ent2emb[node_ent2idx[d]]))
    return None


def _process_feature(events):
    """一個 process → [mean‖max‖std](528*3) + [log1p(n), oov_rate]。回傳 (vec, n, oov)。"""
    embs, n, oov = [], 0, 0
    for e in events:
        n += 1
        v = _event_emb(e)
        if v is None:
            oov += 1
        else:
            embs.append(v)
    if embs:
        A = np.stack(embs)
        pooled = np.concatenate([A.mean(0), A.max(0), A.std(0)])
    else:
        pooled = np.zeros(EVENT_DIM * 3, dtype=np.float32)
    extra = np.array([np.log1p(n), (oov / n if n else 0.0)], dtype=np.float32)
    return np.concatenate([pooled, extra]).astype(np.float32), n, oov


def build_matrix(procs, proc2events, desc):
    rows, tot, oov = [], 0, 0
    for p in tqdm(procs, desc=desc):
        evs = proc2events[p]
        if GRANULARITY == "process":
            vec, n, o = _process_feature(evs); tot += n; oov += o
            rows.append(vec)
        else:  # event
            for e in evs:
                tot += 1
                v = _event_emb(e)
                if v is None: oov += 1
                else: rows.append(v)
    logging.info(f"[{desc}] granularity={GRANULARITY} | rows={len(rows)} | events={tot} | "
                 f"OOV={oov} ({(oov/tot*100) if tot else 0:.2f}%)")
    return np.asarray(rows, dtype=np.float32)


def subsample_rows(X, cap):
    if len(X) <= cap:
        return X
    idx = np.array(random.sample(range(len(X)), cap))
    return X[idx]


# ----------------------------------------------------------------------
# 誠實切分
# ----------------------------------------------------------------------
benign_processes = list(benign_proc.keys()); random.shuffle(benign_processes)
malicious_processes = list(malicious_proc.keys()); random.shuffle(malicious_processes)
nb, nm = len(benign_processes), len(malicious_processes)
ben_train = benign_processes[:int(nb*0.7)]
ben_val   = benign_processes[int(nb*0.7):int(nb*0.8)]
ben_test  = benign_processes[int(nb*0.8):]
mal_val   = malicious_processes[:int(nm*0.5)]     # 前 50% → val (選超參)
mal_test  = malicious_processes[int(nm*0.5):]     # 後 50% → test (量一次)；用光惡意、兩者不重疊
logging.info(f"processes: benign={nb} malicious={nm}")

logging.info("轉換特徵中 ...")
Xtr = subsample_rows(build_matrix(ben_train, benign_proc,    "Train-Benign"),   TRAIN_CAP)
Xvb = subsample_rows(build_matrix(ben_val,   benign_proc,    "Val-Benign"),     VAL_CAP)
Xvm = subsample_rows(build_matrix(mal_val,   malicious_proc, "Val-Malicious"),  VAL_CAP)
Xeb = subsample_rows(build_matrix(ben_test,  benign_proc,    "Test-Benign"),    TEST_CAP)
Xem = subsample_rows(build_matrix(mal_test,  malicious_proc, "Test-Malicious"), TEST_CAP)

Xval = np.concatenate([Xvb, Xvm]); yval01 = np.array([0]*len(Xvb) + [1]*len(Xvm))   # 1 = 攻擊
Xte  = np.concatenate([Xeb, Xem]); yte01  = np.array([0]*len(Xeb) + [1]*len(Xem))
logging.info(f"train:{Xtr.shape} | val B/M:{len(Xvb)}/{len(Xvm)} | test B/M:{len(Xeb)}/{len(Xem)}")
if len(Xvm) < 30 or len(Xem) < 30:
    logging.warning(f"malicious val/test 樣本很少 (val={len(Xvm)}, test={len(Xem)}) → P/R 會較抖，數字要保守解讀。")

scaler = StandardScaler().fit(Xtr)
Ztr_s, Zval_s, Zte_s = scaler.transform(Xtr), scaler.transform(Xval), scaler.transform(Xte)
gamma_scale = 1.0 / (Ztr_s.shape[1] * Ztr_s.var())
NC = min(NYSTROEM_COMPONENTS, Ztr_s.shape[0])       # Nystroem n_components 不能超過樣本數
logging.info(f"feat_dim={Ztr_s.shape[1]} | gamma_scale={gamma_scale:.6f} | nystroem_nc={NC}")


# ----------------------------------------------------------------------
# P-R 曲線工具 (attack_score = -decision_function, 越大越像攻擊)
# ----------------------------------------------------------------------
def pr_arrays(attack_scores, y01):
    prec, rec, thr = precision_recall_curve(y01, attack_scores)
    p, r = prec[:-1], rec[:-1]
    f1 = 2 * p * r / (p + r + 1e-12)
    return p, r, f1, thr


def pick(mask, key, p, r, f1, thr):
    idx = np.where(mask)[0]
    if idx.size == 0:
        return None
    j = idx[np.argmax(key[idx])]
    return {"thr": float(thr[j]), "p": float(p[j]), "r": float(r[j]), "f1": float(f1[j])}


# ----------------------------------------------------------------------
# nu × gamma 聯合訓練
# ----------------------------------------------------------------------
configs = []
for gmult in GAMMA_MULT_GRID:
    gamma = gmult * gamma_scale
    if MODEL_KIND == "nystroem_sgd":
        feat = Nystroem(kernel="rbf", gamma=gamma, n_components=NC, random_state=SEED).fit(Ztr_s)
        Ztr, Zval = feat.transform(Ztr_s), feat.transform(Zval_s)
    elif MODEL_KIND == "rbf_ocsvm":
        feat, Ztr, Zval = None, Ztr_s, Zval_s
    else:
        raise ValueError(MODEL_KIND)

    for nu in NU_GRID:
        est = (OneClassSVM(kernel="rbf", gamma=gamma, nu=nu) if MODEL_KIND == "rbf_ocsvm"
               else SGDOneClassSVM(nu=nu, random_state=SEED, max_iter=5000, tol=1e-4))
        # === fit health / 「loss/收斂」檢查 ===
        with warnings.catch_warnings(record=True) as ws:
            warnings.simplefilter("always")
            est.fit(Ztr)
        converged = not any(issubclass(w.category, ConvergenceWarning) for w in ws)
        tr_out = float((est.decision_function(Ztr[:5000]) < 0).mean())   # 訓練異常比例, 應 ≈ nu

        a_val = -est.decision_function(Zval)          # attack score
        val_auc = roc_auc_score(yval01, a_val)        # threshold-free 分離度 (0.5=沒訊號)
        val_ap  = average_precision_score(yval01, a_val)   # PR-AUC
        p, r, f1, thr = pr_arrays(a_val, yval01)
        c = {"nu": nu, "gmult": gmult, "gamma": gamma, "feat": feat, "est": est,
             "auc": val_auc, "ap": val_ap, "converged": converged, "tr_out": tr_out,
             "constrained": pick((p >= TARGET_P) & (r >= TARGET_R), f1, p, r, f1, thr),
             "at_r": pick(r >= TARGET_R, p, p, r, f1, thr),
             "overall": pick(np.ones_like(p, bool), f1, p, r, f1, thr)}
        configs.append(c)
        b = c["constrained"]
        tag = (f"HIT F1={b['f1']:.4f}(P{b['p']:.3f}/R{b['r']:.3f})" if b else
               (f"best@R>=.9 P={c['at_r']['p']:.4f}(R{c['at_r']['r']:.3f},F1{c['at_r']['f1']:.3f})"
                if c["at_r"] else f"maxF1={c['overall']['f1']:.4f}"))
        conv = "" if converged else " ⚠NOT-CONVERGED(調高 max_iter/檢查 scale)"
        logging.info(f"gmult={gmult:<5} nu={nu:<6} | AUC={val_auc:.3f} AP={val_ap:.3f} "
                     f"tr_out={tr_out:.3f}(~nu={nu}) | {tag}{conv}")

# ----------------------------------------------------------------------
# 分離度診斷 (回答「loss/模型健康」)：AUC/AP 是 threshold-free 的能力上限
# ----------------------------------------------------------------------
n_not_conv = sum(1 for c in configs if not c["converged"])
best_auc = max(c["auc"] for c in configs)
best_ap  = max(c["ap"]  for c in configs)
logging.info(f"===== 健康檢查 =====")
logging.info(f"未收斂 config 數: {n_not_conv}/{len(configs)}"
             + ("  ⚠ 有沒收斂的 → 那些 P/R 不可信" if n_not_conv else "  (全部收斂)"))
logging.info(f"分離度上限: best val ROC-AUC={best_auc:.3f} | best PR-AUC(AP)={best_ap:.3f}")
if best_auc < 0.85:
    logging.info("→ AUC 偏低: 不管 nu/gamma/threshold 怎麼調都難達標，瓶頸在『特徵可分性』(資料層)，"
                 "不是超參。下一步應動特徵，不是繼續掃 nu。")
else:
    logging.info("→ AUC 夠高: 有訊號，達不達標主要看操作點 (nu/gamma/threshold) 選得對不對。")

# ----------------------------------------------------------------------
# (A)→(B)→(C) 選 winner
# ----------------------------------------------------------------------
meeting = [c for c in configs if c["constrained"]]
if meeting:
    win = max(meeting, key=lambda c: c["constrained"]["f1"]); op = win["constrained"]
    branch = "(A) 命中 P>=0.80 & R>=0.90"
else:
    r_ok = [c for c in configs if c["at_r"]]
    if r_ok:
        win = max(r_ok, key=lambda c: c["at_r"]["p"]); op = win["at_r"]
        branch = "(B) 未命中；R>=0.90 下 precision 最高 (離目標最近)"
    else:
        win = max(configs, key=lambda c: c["overall"]["f1"]); op = win["overall"]
        branch = "(C) 未命中；全域 F1 最佳 (連 R>=0.90 都達不到)"

logging.info(f"===== winner: nu={win['nu']} gmult={win['gmult']} | {branch} =====")
logging.info(f"      val: P={op['p']:.4f} R={op['r']:.4f} F1={op['f1']:.4f} | thr={op['thr']:+.4f}")

# ----------------------------------------------------------------------
# 門檻校準:one-class 的操作點應由『benign 假陽性率(FPR)』決定,不綁 malicious → 可跨資料集轉移。
#   thr_fpr = benign-val 分數的 (1-TARGET_FPR) 分位數 → 只讓 ~TARGET_FPR 比例的 benign 被判攻擊,
#   這才不會「換個資料集(DARPA)就把全部樣本判成攻擊」。PR-based 門檻只留作對照。
# ----------------------------------------------------------------------
Zvb_f = win["feat"].transform(scaler.transform(Xvb)) if win["feat"] is not None else scaler.transform(Xvb)
a_vb = -win["est"].decision_function(Zvb_f)                 # benign val attack score
thr_fpr = float(np.quantile(a_vb, 1.0 - TARGET_FPR))
benign_q = {q: float(np.quantile(a_vb, q)) for q in (0.5, 0.9, 0.95, 0.99, 0.999, 1.0)}
q_str = ", ".join(f"{q}:{v:+.3f}" for q, v in benign_q.items())
logging.info(f"benign-val 分數分位數: {q_str}")

thr_pr = op["thr"]
save_thr = thr_fpr if THRESHOLD_MODE == "fpr" else thr_pr
logging.info(f"THRESHOLD_MODE={THRESHOLD_MODE} → 存 thr={save_thr:+.4f} "
             f"(fpr={thr_fpr:+.4f}@FPR≤{TARGET_FPR} / pr={thr_pr:+.4f})")

# ----------------------------------------------------------------------
# 最終 test —— 兩個門檻都量一次(對照),另印 benign FPR 與判成攻擊比例
# ----------------------------------------------------------------------
Zte_f = win["feat"].transform(Zte_s) if win["feat"] is not None else Zte_s
a_te = -win["est"].decision_function(Zte_f)
y_true_pm = np.where(yte01 == 1, -1, 1)

def _test_at(thr, tag):
    y_pred = np.where(a_te >= thr, -1, 1)
    p, r, f, _ = precision_recall_fscore_support(
        y_true_pm, y_pred, pos_label=-1, average="binary", zero_division=0)
    fpr = float((a_te[yte01 == 0] >= thr).mean()) if (yte01 == 0).any() else float("nan")
    flag = float((y_pred == -1).mean())
    logging.info(f"[TEST/{tag}] thr={thr:+.4f} | Atk P:{p:.4f} R:{r:.4f} F1:{f:.4f} "
                 f"| benign FPR={fpr:.4f} | 判成攻擊比例={flag:.4f}")
    return p, r, f

logging.info("對照 SFM: P .733 / R .956 / F .830")
p_pr, r_pr, f_pr = _test_at(thr_pr, "PR")
p_fp, r_fp, f_fp = _test_at(thr_fpr, "FPR")
p_t, r_t, f_t = (p_fp, r_fp, f_fp) if THRESHOLD_MODE == "fpr" else (p_pr, r_pr, f_pr)

hit = (p_t >= TARGET_P) and (r_t >= TARGET_R) and (f_t >= TARGET_F1)
logging.info(f"目標 P>=0.80 R>=0.90 F1>=0.80  →  {'✅ 達標' if hit else '❌ 未達標'}  (granularity={GRANULARITY})")
if not hit:
    logging.info("下一步:GRANULARITY=process / MODEL_KIND=rbf_ocsvm / 加大 GAMMA_MULT_GRID;"
                 "跨資料集(DARPA)請在 infer 用 --fpr,以『目標域自己的 benign』重新校準門檻。")

os.makedirs(SAVE_DIR, exist_ok=True)
save_path = f"{SAVE_DIR}/{GRANULARITY}_{MODEL_KIND}_nu{win['nu']}_g{win['gmult']}_P{p_t:.3f}_R{r_t:.3f}_F{f_t:.3f}.pkl"
with open(save_path, "wb") as fp:
    pickle.dump({
        "granularity": GRANULARITY, "model_kind": MODEL_KIND, "scaler": scaler,
        "feature_map": win["feat"], "estimator": win["est"],
        "attack_score_threshold": save_thr,          # 預設 = benign-FPR 校準門檻(可轉移)
        "attack_score_threshold_pr": thr_pr,         # 舊 PR-based(對照)
        "attack_score_threshold_fpr": thr_fpr,
        "target_fpr": TARGET_FPR, "threshold_mode": THRESHOLD_MODE,
        "benign_val_score_quantiles": benign_q,      # 供跨域重新校準 / 除錯
        # 推論: 造特徵 → z=scaler.transform(x); (feature_map.transform(z));
        #        a=-est.decision_function(z); pred=-1(攻擊) if a>=threshold else 1
        "nu": win["nu"], "gamma_mult": win["gmult"], "gamma_scale": gamma_scale,
    }, fp)
logging.info(f"已存: {save_path} (門檻模式={THRESHOLD_MODE})")

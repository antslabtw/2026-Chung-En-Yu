# -*- coding: utf-8 -*-
"""
infer_K4APT_llm.py — KELLECT4APT LLM 版推論 (holdout 樣本，trace 級 majority-vote TTP)。

模型從 tranK_llm.py 存的 best_{tag}.pt 的 cfg 重建 (ttp_model.TTP_Model)，不 drift。
每個 held-out .json → 逐 event 預測 → 取非-O 預測的多數決 → 該 trace 的 TTP，
跟資料夾真 label 比，印 trace 級 accuracy。

用法:
    python infer_K4APT_llm.py --ckpt ./Trans_CRF_KELLECT4APT_llm/save_model/best_hop_llm.pt
"""
import os
os.environ.setdefault("KELLECT_KEEP_BENIGN", "1")

import glob, pickle, argparse, logging
from collections import Counter
import numpy as np
import torch

from kellect_event import iter_events, event_to_triple, event_ts, event_graph_key, is_benign_proc
from ttp_model import TTP_Model, build_event_feats

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

ap = argparse.ArgumentParser()
ap.add_argument("--ckpt", default=None, help="None=抓最新 best_*.pt")
ap.add_argument("--holdout_list", default=None, help="infer_holdout_files_*.txt；None=依 ckpt tag 自動找")
ap.add_argument("--o_bias", type=float, default=None, help="覆蓋 deploy O-bias")
args = ap.parse_args()

ckpt_path = args.ckpt or sorted(glob.glob("./Trans_CRF_KELLECT4APT_llm/save_model/best_*.pt"),
                                key=os.path.getmtime)[-1]
ck = torch.load(ckpt_path, map_location=device, weights_only=False)
cfg = ck["cfg"]
label2index = ck["label2index"]; index2label = ck["index2label"]
o_bias = args.o_bias if args.o_bias is not None else ck.get("deploy_o_bias", 0.0)
O_IDX = cfg["o_idx"]; WINDOW_SIZE = cfg["window_size"]; STRIDE = cfg["stride"]
logging.info(f"ckpt={ckpt_path} chunk_kind={cfg['chunk_kind']} use_llm={cfg['use_llm']} O-bias={o_bias}")

SB_DIR, LLM_DIR = cfg["sb_dir"], cfg["llm_dir"]
with open(f"{SB_DIR}/nodes/vocab2idx.pkl", "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/edges/vocab2idx.pkl", "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/nodes_ent2emb_256.pkl", "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(f"{SB_DIR}/edges_ent2emb_16.pkl", "rb") as fp:
    edge_ent2emb = pickle.load(fp)

node_emb_tensor = torch.tensor(np.array(node_ent2emb), dtype=torch.float32)
edge_emb_tensor = torch.tensor(np.array(edge_ent2emb), dtype=torch.float32)
NODE_PAD_IDX = node_emb_tensor.shape[0]; EDGE_PAD_IDX = edge_emb_tensor.shape[0]
node_emb_tensor = torch.cat([node_emb_tensor, torch.zeros(1, 256)], 0).to(device)
edge_emb_tensor = torch.cat([edge_emb_tensor, torch.zeros(1, 16)], 0).to(device)

llm_emb_tensor = None
if cfg["use_llm"]:
    with open(f"{LLM_DIR}/llm_node_vocab2idx.pkl", "rb") as fp:
        llm_v2i = pickle.load(fp)
    cand = sorted(glob.glob(f"{LLM_DIR}/llm_node_ent2emb_*.pkl"))
    with open(cand[-1], "rb") as fp:
        llm_arr = np.asarray(pickle.load(fp), dtype=np.float32)
    llm_emb_tensor = torch.zeros(node_emb_tensor.shape[0], llm_arr.shape[1])
    for s, i in node_ent2idx.items():
        j = llm_v2i.get(s)
        if j is not None:
            llm_emb_tensor[i] = torch.from_numpy(llm_arr[j])
    llm_emb_tensor = llm_emb_tensor.to(device)

model = TTP_Model(cfg["combined_dim"], cfg["output_size"], cfg["chunk_kind"], cfg["scales"],
                  cfg["node_pad_idx"], o_idx=cfg["o_idx"],
                  graph_mode=cfg.get("graph_mode", "tree")).to(device)
model.load_state_dict(ck["model"]); model.eval()
model.decode_o_bias = o_bias


@torch.no_grad()
def predict_trace(json_path):
    """回傳這個 trace 逐 event 的預測 label 字串 list。"""
    events = iter_events(json_path); events.sort(key=event_ts)
    src_i, rel_i, dst_i, ga_i, gb_i = [], [], [], [], []
    for e in events:
        tri = event_to_triple(e)
        if tri is None:
            continue
        s, ed, d = tri
        src_i.append(node_ent2idx.get(s, NODE_PAD_IDX))
        rel_i.append(edge_ent2idx.get(ed, EDGE_PAD_IDX))
        dst_i.append(node_ent2idx.get(d, NODE_PAD_IDX))
        pid, ppid = event_graph_key(e)
        ga_i.append(pid); gb_i.append(ppid)
    if not src_i:
        return []
    preds = []
    for i in range(0, len(src_i), WINDOW_SIZE):
        cs = src_i[i:i+WINDOW_SIZE]; cr = rel_i[i:i+WINDOW_SIZE]; cd = dst_i[i:i+WINDOW_SIZE]
        cga = ga_i[i:i+WINDOW_SIZE]; cgb = gb_i[i:i+WINDOW_SIZE]
        seq = len(cs)
        if seq < WINDOW_SIZE:
            pad = WINDOW_SIZE - seq
            cs += [NODE_PAD_IDX]*pad; cr += [EDGE_PAD_IDX]*pad; cd += [NODE_PAD_IDX]*pad
            cga += [-1]*pad; cgb += [-1]*pad
            m = [1]*seq + [0]*pad
        else:
            m = [1]*WINDOW_SIZE
        T = lambda a: torch.tensor(a, dtype=torch.long, device=device).unsqueeze(0)
        src, rel, dst = T(cs), T(cr), T(cd)
        ga, gb = T(cga), T(cgb)
        mask = torch.tensor(m, dtype=torch.bool, device=device).unsqueeze(0)
        feats = build_event_feats(src, rel, dst, node_emb_tensor, edge_emb_tensor, llm_emb_tensor)
        with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
            e_emis = model.emissions(feats, ga, gb, mask).float()
        out = model.decode(e_emis, mask, o_bias=o_bias)[0]
        preds.extend(index2label.get(int(x), "O") for x in out[:seq])
    return preds


def trace_vote(preds):
    """非-O 預測的多數決；全 O → 'O'。"""
    non_o = [p for p in preds if p != "O"]
    return Counter(non_o).most_common(1)[0][0] if non_o else "O"


def main():
    hl = args.holdout_list
    if hl is None:
        tag = os.path.basename(ckpt_path)[len("best_"):-len(".pt")]
        hl = f"./Trans_CRF_KELLECT4APT_llm/save_result/infer_holdout_files_{tag}.txt"
    if not os.path.exists(hl):
        logging.error(f"找不到 holdout 清單 {hl}；用 --holdout_list 指定"); return
    items = []
    with open(hl, encoding="utf-8") as fp:
        for line in fp:
            if "\t" in line:
                lab, path = line.rstrip("\n").split("\t", 1)
                items.append((lab, path))
    correct, total = 0, 0
    print(f"\n>>> KELLECT4APT holdout 推論 ({len(items)} traces, chunk={cfg['chunk_kind']}, LLM={cfg['use_llm']})")
    print("-" * 80)
    for lab, path in items:
        preds = predict_trace(path)
        if not preds:
            print(f"{lab:<14} | {os.path.basename(path):<24} | 無有效事件"); continue
        pred = trace_vote(preds)
        ok = (pred == lab)
        correct += ok; total += 1
        print(f"{lab:<14} | {os.path.basename(path):<24} | pred={pred:<14} {'✓' if ok else '✗'}")
    print("-" * 80)
    if total:
        print(f">>> Trace 級 accuracy = {correct}/{total} = {correct/total:.4f}")


if __name__ == "__main__":
    main()

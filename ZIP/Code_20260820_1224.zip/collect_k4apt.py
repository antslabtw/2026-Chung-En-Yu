# -*- coding: utf-8 -*-
"""collect_k4apt.py — 把 KELLECT4APT 各支推論腳本的 log 收成一張表。

**不改任何推論腳本**,直接解析它們原本就會印的行。五種格式各有一組 regex,
靠 log 裡的特徵行辨識是哪一支印的(不是靠檔名,檔名改了也還是認得出來)。

    infer_sfm_k4apt.py    「BiGRU= …」   →  BiGRU / Cascade 的 macro P R F1
    infer_trans_k4apt.py  「Transformer= …」→ 逐 O-bias 的 Transformer / Cascade
    infer_ttp_k4apt.py    「[1] event …」  →  event / window / trace 三個層級
    infer_K4APT.py        「[ckpt] …」     →  trace 級準確率 + 樣本級 macro P R F1
    infer_K4APT_llm.py    「holdout 推論 (… chunk=…)」→ trace 級 accuracy

⚠ A 線(trace 級)與 B 線(event 級 + OCSVM)**度量不同,不能互相比**,
  表格會分開列,不會把它們排進同一個名次。

用法:
    python collect_k4apt.py                       # 讀 repro/k4apt/*.log
    python collect_k4apt.py --logs repro/k4apt --md
    python collect_k4apt.py --logs repro/k4apt --csv k4apt.csv
"""
import os
import re
import glob
import argparse

ap = argparse.ArgumentParser()
ap.add_argument("--logs", default="repro/k4apt", help="log 目錄或 glob")
ap.add_argument("--md", action="store_true", help="另外印 markdown 表格")
ap.add_argument("--csv", default=None)
args = ap.parse_args()

pat = args.logs if any(c in args.logs for c in "*?[") else os.path.join(args.logs, "*.log")
files = sorted(glob.glob(pat))
if not files:
    raise SystemExit(f"沒有 log:{pat}\n  先跑:bash run_k4apt_infer.sh")


# ---------------------------------------------------------------- 五種格式
def parse_sfm(t):
    """infer_sfm_k4apt.py:BiGRU / Cascade,值域 0~100。"""
    out = {}
    for m in re.finditer(r"(BiGRU|Cascade)\s+macro P=\s*([\d.]+) R=\s*([\d.]+) F1=\s*([\d.]+)", t):
        out[m.group(1)] = (float(m.group(2)), float(m.group(3)), float(m.group(4)))
    if not out:
        return None
    rows = []
    if "BiGRU" in out:
        rows.append(("SFM BiGRU-CRF", "純模型", "-") + out["BiGRU"])
    if "Cascade" in out:
        rows.append(("SFM BiGRU-CRF", "Cascade", "-") + out["Cascade"])
    return "B", rows


def parse_trans(t):
    """infer_trans_k4apt.py:逐 O-bias 的兩列;取各自 macro F1 最高那個 bias。"""
    best = {}
    for m in re.finditer(r"([\d.]+)\s+(Transformer|Cascade)\s*\|\s*"
                         r"([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*\|", t):
        b, who = m.group(1), m.group(2)
        p, r, f = float(m.group(3)), float(m.group(4)), float(m.group(5))
        if who not in best or f > best[who][3]:
            best[who] = (b, p, r, f)
    if not best:
        return None
    rows = []
    for who, label in (("Transformer", "純模型"), ("Cascade", "Cascade")):
        if who in best:
            b, p, r, f = best[who]
            rows.append(("Transformer-CRF", label, b, p, r, f))
    return "B", rows


def parse_three_level(t):
    """infer_ttp_k4apt.py:event / window / trace 三個層級(不含 OCSVM gate)。"""
    rows = []
    for m in re.finditer(r"\[(\d)\] (event|window|trace)\s+n=\s*\d+\s+acc=\s*([\d.]+)%\s*\|\s*"
                         r"macro P=\s*([\d.]+) R=\s*([\d.]+) F1=\s*([\d.]+)", t):
        rows.append(("Transformer-CRF", f"{m.group(2)} 級", "-",
                     float(m.group(4)), float(m.group(5)), float(m.group(6))))
    return ("B", rows) if rows else None


def parse_k4apt_plain(t):
    """infer_K4APT.py:trace 級準確率 + 樣本級 macro(值域 0~1,要 ×100)。"""
    rows = []
    m = re.search(r"樣本級 TTP 分類 \(macro over (\d+) 類\)\s+"
                  r"P=([\d.]+)\s+R=([\d.]+)\s+F1=([\d.]+)", t)
    if m:
        rows.append(("Transformer", "trace 級 macro", "-",
                     float(m.group(2)) * 100, float(m.group(3)) * 100, float(m.group(4)) * 100))
    a = re.search(r"trace 級 TTP 準確率 = (\d+)/(\d+) = ([\d.]+)", t)
    if a:
        rows.append(("Transformer", f"trace 級 acc ({a.group(1)}/{a.group(2)})", "-",
                     None, None, float(a.group(3)) * 100))
    return ("A", rows) if rows else None


def parse_k4apt_llm(t):
    """infer_K4APT_llm.py:只有 trace 級 accuracy,沒有 P/R/F1。"""
    c = re.search(r"chunk=(\w+), LLM=(\w+)", t)
    a = re.search(r"Trace 級 accuracy = (\d+)/(\d+) = ([\d.]+)", t)
    if not a:
        return None
    kind = c.group(1) if c else "?"
    llm = "+LLM" if (c and c.group(2) not in ("0", "False")) else ""
    return "A", [(f"Trans({kind}){llm}", f"trace 級 acc ({a.group(1)}/{a.group(2)})", "-",
                  None, None, float(a.group(3)) * 100)]


# 特徵行 → 用哪個解析器。順序有意義:先比對最獨特的。
DETECT = [
    (re.compile(r"holdout 推論 \("), parse_k4apt_llm),
    (re.compile(r"^\[ckpt\] ", re.M), parse_k4apt_plain),
    (re.compile(r"\[1\] event\s+n="), parse_three_level),
    (re.compile(r"Transformer=\S"), parse_trans),
    (re.compile(r"BiGRU=\S"), parse_sfm),
]

records = []          # (track, key, 架構, 口徑, bias, P, R, F1, log)
for f in files:
    with open(f, encoding="utf-8", errors="ignore") as fp:
        text = fp.read()
    hit = None
    for rx, fn in DETECT:
        if rx.search(text):
            hit = fn(text)
            if hit:
                break
    key = os.path.splitext(os.path.basename(f))[0]
    if not hit:
        records.append(("?", key, "(認不出格式或推論未完成)", "-", "-", None, None, None, f))
        continue
    track, rows = hit
    for arch, how, bias, p, r, f1 in rows:
        records.append((track, key, arch, how, bias, p, r, f1, f))

if not records:
    raise SystemExit("log 裡沒有可解析的結果。")


def fmt(v):
    return "  -  " if v is None else f"{v:6.2f}"


def pad(s, n):
    """中文字在終端機佔兩格,用 str.ljust 會對不齊。"""
    import unicodedata
    w = sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in str(s))
    return str(s) + " " * max(n - w, 0)


TRACK_TITLE = {
    "A": ("A 線 — trace 級(直接吃原始 json;每個 TTP 留 1 條 trace 當 holdout)",
          "整條 trace 投票出一個 TTP。沒有 OCSVM gate。"),
    "B": ("B 線 — event 級 + OCSVM cascade(k4apt_sfm / k4apt_dense 視窗資料集)",
          "逐事件標註,排除 O、只算 GT 出現過的技術,macro 平均。"),
    "?": ("無法辨識", ""),
}

for track in ("B", "A", "?"):
    rs = [r for r in records if r[0] == track]
    if not rs:
        continue
    title, note = TRACK_TITLE[track]
    print("=" * 94)
    print(f" {title}")
    if note:
        print(f" {note}")
    print("=" * 94)
    print("  " + pad("項目", 10) + pad("架構", 22) + pad("口徑", 24)
          + f"{'bias':>5}{'P':>9}{'R':>9}{'F1':>9}")
    print("-" * 94)
    for _, key, arch, how, bias, p, r, f1, _log in rs:
        print("  " + pad(key, 10) + pad(arch, 22) + pad(how, 24)
              + f"{str(bias):>5}{fmt(p):>9}{fmt(r):>9}{fmt(f1):>9}")
    print()

print("=" * 94)
print(" ⚠ A 線與 B 線的度量不同(trace 級 vs event 級、有無 OCSVM gate),**不能互相比**。")
print("   要放進同一張論文表,兩邊必須用同一份資料與同一個口徑重跑。")
print("=" * 94)

if args.md:
    print()
    for track in ("B", "A"):
        rs = [r for r in records if r[0] == track]
        if not rs:
            continue
        print(f"### {TRACK_TITLE[track][0]}")
        print()
        print("| 項目 | 架構 | 口徑 | P | R | F1 |")
        print("|---|---|---|---|---|---|")
        for _, key, arch, how, bias, p, r, f1, _log in rs:
            g = lambda v: "-" if v is None else f"{v:.2f}"
            print(f"| {key} | {arch} | {how} | {g(p)} | {g(r)} | **{g(f1)}** |")
        print()

if args.csv:
    import csv
    with open(args.csv, "w", newline="", encoding="utf-8") as fp:
        w = csv.writer(fp)
        w.writerow(["track", "key", "arch", "metric", "o_bias", "P", "R", "F1", "log"])
        w.writerows(records)
    print(f"\n→ {args.csv}")

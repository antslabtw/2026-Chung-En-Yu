# -*- coding: utf-8 -*-
"""SecureBERT 2.0 embedding pipeline — KELLECT4APT 原始事件版。

跟原本 make_embedding.py 的差別只在「vocab 怎麼收」：
  - 從 KELLECT4APT public_data 遞迴掃 *.json(JSONL)
  - 用 kellect_event.event_to_triple 抽 (src, edge, dst) → node/edge vocab
  - 不再需要 relations.txt(要收哪些 edge 由 event_to_triple 決定，跟 tranK 完全一致)
其餘 SecureBERT mean-pooled embedding + PCA 流程原封不動。

用法:
    python make_emb_K4APT.py \
        --data_glob "./KELLECT4APT/public_data/**/*.json" \
        --save_dir  ./SecureBERT2.0-K4APT
"""
import os, math, pickle, logging, argparse
import numpy as np
from glob import glob
from tqdm import tqdm

import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.decomposition import PCA

from kellect_event import iter_events, event_to_triple

logging.basicConfig(format='%(asctime)s | %(levelname)s | %(message)s',
                    level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S')


# ---------------------------------------------------------------------------
# 1. Vocabulary collection (KELLECT 原始事件 → node/edge 字串)
# ---------------------------------------------------------------------------
def collect_vocab(data_glob: str):
    nodes, edges = set(), set()
    paths = glob(data_glob, recursive=True)
    if not paths:
        raise FileNotFoundError(
            f"data_glob 沒有比對到任何檔案:\n  {data_glob}\n"
            f"cwd={os.getcwd()}\n"
            f"檢查資料路徑，或用 --data_glob '/abs/path/**/*.json' 指定(記得加 **)。")
    logging.info(f"matched {len(paths)} json files")
    n_ev, n_tri = 0, 0
    for p in tqdm(paths, total=len(paths), desc="collect vocab"):
        for e in iter_events(p):
            n_ev += 1
            tri = event_to_triple(e)
            if tri is None:
                continue
            n_tri += 1
            s, ed, d = tri
            nodes.add(s); nodes.add(d); edges.add(ed)
    logging.info(f"events={n_ev}  triples(可用)={n_tri}  Nodes={len(nodes)}  Edges={len(edges)}")
    if not nodes or not edges:
        raise RuntimeError("vocab 空的：event_to_triple 全數回 None。"
                           "檢查資料 schema 是否為 Event/PName/args。")
    return sorted(nodes), sorted(edges)


# ---------------------------------------------------------------------------
# 2. SecureBERT 2.0 mean-pooled embedding (streaming chunk save) — 同原版
# ---------------------------------------------------------------------------
def make_embedding_securebert2(vocab, save_path, tokenizer, model, device,
                               batch_size=128, batch_chunk_size=100, max_length=1024):
    os.makedirs(save_path, exist_ok=True)
    clean = []
    for v in vocab:
        if v is None:
            continue
        s = str(v)
        if len(s) == 0:
            continue
        clean.append(s)
    if len(clean) < len(vocab):
        logging.warning(f"filtered {len(vocab)-len(clean)} empty/None entries")
    if not clean:
        logging.error(f"vocab empty for {save_path} — abort")
        return
    vocab2idx = {v: idx for idx, v in enumerate(clean)}
    with open(os.path.join(save_path, "vocab2idx.pkl"), "wb") as fp:
        pickle.dump(vocab2idx, fp)
    logging.info(f"[✓] saved {save_path}/vocab2idx.pkl (size={len(clean)})")

    embeddings, batches = [], math.ceil(len(clean) / batch_size)
    for i in tqdm(range(batches), desc=f"embed {os.path.basename(save_path)}"):
        s, e = i * batch_size, min((i + 1) * batch_size, len(clean))
        batch_texts = clean[s:e]
        if not batch_texts:
            continue
        enc = tokenizer(batch_texts, padding=True, truncation=True,
                        max_length=max_length, return_tensors="pt")
        ids = enc["input_ids"].to(device)
        mask = enc["attention_mask"].to(device)
        with torch.no_grad():
            out = model(input_ids=ids, attention_mask=mask)
            hs = out.last_hidden_state
            m3 = mask.unsqueeze(-1).float()
            summed = (hs * m3).sum(dim=1)
            counts = m3.sum(dim=1).clamp(min=1e-9)
            avg = summed / counts
        embeddings.append(avg.detach().cpu().numpy())
        if ((i + 1) % batch_chunk_size == 0) or i == batches - 1:
            arr = np.concatenate(embeddings, axis=0)
            chunk_id = i // batch_chunk_size
            np.save(os.path.join(save_path, f"embeddings_chunk_{chunk_id}.npy"), arr)
            logging.info(f"[✓] saved embeddings_chunk_{chunk_id}.npy shape={arr.shape}")
            embeddings = []


def _numeric(path: str) -> int:
    return int(path.split("_")[-1].split(".")[0])


def _load_all_chunks(save_path: str, ent_type: str) -> np.ndarray:
    pattern = f"{save_path}/{ent_type}/embeddings_chunk_*.npy"
    paths = sorted(glob(pattern), key=_numeric)
    if not paths:
        raise FileNotFoundError(f"沒有 embedding chunk: {pattern}")
    return np.concatenate([np.load(p) for p in paths], axis=0).astype(np.float32)


def make_pca_embedding(save_path: str, ent_type: str, size: int, pca_model_path: str):
    emb = _load_all_chunks(save_path, ent_type)
    n_comp = min(size, emb.shape[0], emb.shape[1])
    if n_comp < size:
        logging.warning(f"[PCA] {ent_type}: 樣本/維度不足，n_components {size}->{n_comp}")
    pca = PCA(n_components=n_comp)
    reduced = pca.fit_transform(emb)
    logging.info(f"[PCA] {ent_type}: {emb.shape} -> {reduced.shape}")
    os.makedirs(os.path.dirname(pca_model_path), exist_ok=True)
    with open(pca_model_path, "wb") as fp:
        pickle.dump(pca, fp)
    out_pkl = f"{save_path}/{ent_type}_ent2emb_{size}.pkl"
    with open(out_pkl, "wb") as fp:
        pickle.dump(reduced, fp)
    logging.info(f"[✓] saved {out_pkl}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="cisco-ai/SecureBERT2.0-base")
    ap.add_argument("--save_dir", default="./SecureBERT2.0-K4APT")
    ap.add_argument("--data_glob", default="./KELLECT4APT/public_data/**/*.json")
    ap.add_argument("--node_pca_dim", type=int, default=256)
    ap.add_argument("--edge_pca_dim", type=int, default=16)
    ap.add_argument("--batch_size", type=int, default=128)
    ap.add_argument("--max_length", type=int, default=1024)
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"device={device}  torch={torch.__version__}")

    nodes, edges = collect_vocab(args.data_glob)

    logging.info(f"loading {args.model} ...")
    tokenizer = AutoTokenizer.from_pretrained(args.model)
    model = AutoModel.from_pretrained(args.model, trust_remote_code=True).to(device)
    model.eval()
    logging.info("[✓] model loaded")

    os.makedirs(args.save_dir, exist_ok=True)
    make_embedding_securebert2(nodes, os.path.join(args.save_dir, "nodes"),
                               tokenizer, model, device,
                               batch_size=args.batch_size, max_length=args.max_length)
    make_embedding_securebert2(edges, os.path.join(args.save_dir, "edges"),
                               tokenizer, model, device,
                               batch_size=args.batch_size, max_length=args.max_length)

    os.makedirs("./model", exist_ok=True)
    make_pca_embedding(args.save_dir, "nodes", args.node_pca_dim, "./model/pca_k4apt_nodes.pkl")
    make_pca_embedding(args.save_dir, "edges", args.edge_pca_dim, "./model/pca_k4apt_edges.pkl")
    logging.info("Done.")


if __name__ == "__main__":
    main()

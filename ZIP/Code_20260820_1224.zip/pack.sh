#!/usr/bin/env bash
# pack.sh — 在專案根目錄執行:檢查每個實驗的 .pt,然後打包 .sh/.py 與 .pt。
#
#   bash pack.sh            檢查 → 全部通過才打包
#   bash pack.sh --check    只檢查
#   bash pack.sh --force    缺 .pt 也照打包
#
# 產出:sfm_code_<日期>.zip(.sh + .py + 設定檔)
#       sfm_ckpt_<日期>.zip(每個實驗一顆 .pt)
set -u

MODE="${1:-}"
STAMP=$(date +%Y%m%d_%H%M)

# ── 實驗表 ────────────────────────────────────────────────────────────
# key | 名稱 | 訓練 | 推論 | runner | checkpoint(AUTO: = 自動挑 AtkF1 最高)
EXP=(
"ocsvm|OCSVM 異常閘門(T1~T5 共用)|train_ocsvm_finetune.py|-|run_v2.sh|model/OCSVM_finetune/event_nystroem_sgd_nu0.001_g8.0_P0.842_R0.959_F0.897.pkl"
"t1|T1 Transformer (w/o LLM, Multichunk)|train_ttp_conservative.py|infer_saga.py|run_v2.sh|Trans_CRF0706/save_model/epoch_9_AtkF1_0.9787"
"t2|T2 Transformer (Temporal)|train_ttp_llm.py|infer_saga_llm.py|run_all.sh|Trans_CRF0706/save_model/best_temporal_llm.pt"
"t3|T3 Transformer (hop)|train_ttp_llm.py|infer_saga_llm.py|run_all.sh|Trans_CRF0706/save_model/best_hop_llm.pt"
"t4|T4 Transformer (hop + Qwen)|train_ttp_llm.py|infer_saga_llm.py|run_all.sh|Trans_CRF0706/save_model/best_hop_llm_qwen.pt"
"t5|T5 Transformer (hop*3,每 chunk 一個 transformer)|train_multichunk.py|infer_saga_mc.py|run_multichunk.sh|AUTO:multichunk_*/save_model Trans_CRF0706_mc/save_model"
"k4_plain|KELLECT4APT Transformer|tranK.py|infer_K4APT.py|run_k4apt.sh|Trans_CRF_KELLECT4APT/save_model/best.pt"
"k4_temporal|KELLECT4APT Transformer (Temporal)|tranK_llm.py|infer_K4APT_llm.py|run_k4apt_llm.sh|Trans_CRF_KELLECT4APT_llm/save_model/best_temporal_llm.pt"
"k4_hop|KELLECT4APT Transformer (Hop)|tranK_llm.py|infer_K4APT_llm.py|run_k4apt_llm.sh|Trans_CRF_KELLECT4APT_llm/save_model/best_hop_llm.pt"
)

SH=(run_v2.sh run_all.sh run_multichunk.sh run_k4apt.sh run_k4apt_llm.sh
    run_all_infer.sh run_k4apt_infer.sh pack.sh)

PY=(train_ocsvm_finetune.py train_ttp_conservative.py train_ttp_llm.py
    train_multichunk.py tranK.py tranK_ori.py tranK_llm.py train_ttp_kellect4apt.py
    infer_saga.py infer_saga_llm.py infer_saga_mc.py infer_K4APT.py infer_K4APT_llm.py
    ttp_model.py multi_chunk.py multi_hop.py train_tagger.py common.py kellect_event.py
    ckpt_guard.py
    make_embedding.py make_llm_embedding.py make_emb_K4APT.py emb_K4APT_llm.py
    make_dataset4SFM.py
    show_results.py collect_results.py collect_k4apt.py check_expected.py check_llm.py)

CFG=(relations.txt index2label_0201.pkl label2index_0201.pkl
     index2label_kellect4apt.pkl label2index_kellect4apt.pkl
     benign_procs.txt expected_results.json requirements.txt
     README.md)

# 從目錄挑 AtkF1 最高的
pick() {
    ls -1 $1/epoch_*_AtkF1_* 2>/dev/null \
      | awk -F'AtkF1_' 'NF>1{print $2"\t"$0}' | sort -rn | head -1 | cut -f2-
}

resolve() {
    case "$1" in
      AUTO:*) for d in ${1#AUTO:}; do p=$(pick "$d"); [ -n "$p" ] && { echo "$p"; return; }; done ;;
      *)      [ -f "$1" ] && echo "$1" ;;
    esac
}

# ── 檢查 ──────────────────────────────────────────────────────────────
echo "===================================================================================================="
echo " 檢查:每個實驗的 .pt 在不在、載得起來嗎、有沒有被 repro log 用過"
echo " 目前目錄 $(pwd)"
echo "===================================================================================================="
printf "\n  %-13s %8s  %-30s %s\n" "key" "大小" "狀態" "路徑"
printf "  %s\n" "$(printf '%.0s-' $(seq 1 96))"

FOUND=(); MISS=0
for row in "${EXP[@]}"; do
    IFS='|' read -r key name tr inf sh ck <<< "$row"
    p=$(resolve "$ck")
    if [ -z "$p" ]; then
        printf "  %-13s %8s  %-30s %s\n" "$key" "—" "✗ 不存在" "$ck"
        MISS=$((MISS+1)); continue
    fi
    sz=$(du -m "$p" 2>/dev/null | cut -f1)
    note=""
    case "$p" in
      *.pkl) : ;;
      *) if command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1; then
             PYBIN=$(command -v python3 || command -v python)
             note=$("$PYBIN" - "$p" "$inf" <<'PYEOF' 2>&1
import sys, torch
p, want = sys.argv[1], sys.argv[2]
try:
    ck = torch.load(p, map_location="cpu", weights_only=False)
except Exception as ex:
    print(f"FATAL 載入失敗 {type(ex).__name__}"); sys.exit()
sd = ck.get("model", ck.get("state_dict", ck)) if isinstance(ck, dict) else {}
k = list(sd) if isinstance(sd, dict) else []
# preproc.* 來自 ttp_model.TTP_Model,SAGA 與 KELLECT 的 LLM 版共用同一個類別
if   any(x.startswith("preproc.") for x in k):            got = "infer_saga_llm.py|infer_K4APT_llm.py"
elif any(x.startswith("chunk_transformers") for x in k):  got = "infer_saga_mc.py"
elif any(x.startswith("input_proj.") and x.split(".")[1].isdigit() for x in k): got = "infer_saga_mc.py"
elif "input_proj.weight" in k:                            got = "infer_saga.py|infer_K4APT.py|infer_K4APT_llm.py"
else:                                                     got = "?"
if got == "?":            print("架構認不出來")
elif want not in got:     print(f"架構像 {got},表上寫 {want}")
PYEOF
)
         fi ;;
    esac
    # 比對完整路徑,不能用 basename —— t3 與 k4_hop 的檔名都叫 best_hop_llm.pt
    used=$(grep -rl -- "$p" repro/*.log 2>/dev/null | head -3 | xargs -r -n1 basename | paste -sd, -)
    [ -z "$used" ] && note="${note}${note:+; }沒有 repro log 用過"
    st="✓ 可用"; [ -n "$note" ] && st="△ $note"
    case "$note" in FATAL*) st="✗ $note"; MISS=$((MISS+1));; *) FOUND+=("$p|$key|$name|$inf");; esac
    printf "  %-13s %7sM  %-30s %s\n" "$key" "${sz:-?}" "$st" "$p"
    [ -n "$used" ] && printf "  %-13s %8s  %-30s log: %s\n" "" "" "" "$used"
done

echo
if [ "$MISS" -gt 0 ]; then
    echo "  ✗ $MISS 個實驗沒有可用的 .pt"
    [ "$MODE" != "--force" ] && [ "$MODE" != "--check" ] && {
        echo "  中止 —— 補齊後再跑,或 bash pack.sh --force 放行"; exit 1; }
else
    echo "  ✓ ${#FOUND[@]} 個實驗全部有可用的 .pt"
fi

# ── 檔案清單 ──────────────────────────────────────────────────────────
CODE=(); LOST=()
for f in "${SH[@]}" "${PY[@]}" "${CFG[@]}"; do
    [ -f "$f" ] && CODE+=("$f") || LOST+=("$f")
done
echo
echo "===================================================================================================="
echo " 程式碼:${#CODE[@]} 個檔案"
echo "===================================================================================================="
for f in "${CODE[@]}"; do printf "  %8s  %s\n" "$(du -k "$f" | cut -f1)K" "$f"; done
[ ${#LOST[@]} -gt 0 ] && { echo; echo "  這台機器沒有(略過):${LOST[*]}"; }

[ "$MODE" = "--check" ] && { echo; echo "--check:只檢查,沒有打包。"; exit 0; }

# ── 打包 ──────────────────────────────────────────────────────────────
# 有 zip 就用 zip;沒有就退回 python 的 zipfile(server 不一定裝了 zip)
PYBIN=$(command -v python3 || command -v python || true)
if command -v zip >/dev/null 2>&1; then
    mkzip() { out="$1"; lvl="$2"; shift 2; zip -q -"$lvl" "$out" "$@"; }
elif [ -n "$PYBIN" ]; then
    echo "  (沒有 zip 指令,改用 $PYBIN 的 zipfile)"
    mkzip() {
        out="$1"; lvl="$2"; shift 2
        "$PYBIN" - "$out" "$lvl" "$@" <<'PYEOF'
import sys, zipfile
out, lvl, files = sys.argv[1], int(sys.argv[2]), sys.argv[3:]
comp = zipfile.ZIP_STORED if lvl == 0 else zipfile.ZIP_DEFLATED
with zipfile.ZipFile(out, "w", comp, allowZip64=True) as z:
    for f in files:
        z.write(f, f)
PYEOF
    }
else
    echo; echo "既沒有 zip 也沒有 python,無法打包"; exit 1
fi

{
  echo "# T1~T5 與 KELLECT4APT"
  echo
  echo "產生時間 $(date '+%Y-%m-%d %H:%M')  於 $(hostname):$(pwd)"
  echo
  echo "| 實驗 | runner | 訓練 | 推論 | checkpoint |"
  echo "|---|---|---|---|---|"
  for row in "${EXP[@]}"; do
      IFS='|' read -r key name tr inf sh ck <<< "$row"
      echo "| $name | \`$sh\` | \`$tr\` | \`$inf\` | \`$(resolve "$ck" || echo "$ck")\` |"
  done
  echo
  echo '```bash'
  echo "sed -i 's/\r\$//' *.sh *.py"
  echo "bash run_all_infer.sh"
  echo "python show_results.py"
  echo '```'
} > MANIFEST.md

CODEZIP="sfm_code_${STAMP}.zip"
echo
mkzip "$CODEZIP" 9 "${CODE[@]}" MANIFEST.md \
  && echo "  $CODEZIP   $(du -h "$CODEZIP" | cut -f1)"

if [ ${#FOUND[@]} -gt 0 ]; then
    CKZIP="sfm_ckpt_${STAMP}.zip"
    : > CKPT_MANIFEST.md
    {
      echo "# checkpoint — 每個實驗只收實際拿去 inference 的那一顆"
      echo
      echo "| 實驗 | checkpoint | 推論腳本 |"
      echo "|---|---|---|"
    } >> CKPT_MANIFEST.md
    FILES=()
    for e in "${FOUND[@]}"; do
        IFS='|' read -r p key name inf <<< "$e"
        FILES+=("$p")
        echo "| $name | \`$p\` | \`$inf\` |" >> CKPT_MANIFEST.md
    done
    echo "  打包 ${#FILES[@]} 顆 .pt(不重壓,大檔會跑一陣子)…"
    mkzip "$CKZIP" 0 "${FILES[@]}" CKPT_MANIFEST.md \
      && echo "  $CKZIP   $(du -h "$CKZIP" | cut -f1)"
fi

echo
for z in "$CODEZIP" ${CKZIP:-}; do
    [ -f "$z" ] || continue
    if command -v md5sum >/dev/null 2>&1; then
        md5sum "$z" | tee "$z.md5"
    elif [ -n "$PYBIN" ]; then
        "$PYBIN" -c "import hashlib,sys
h=hashlib.md5()
with open(sys.argv[1],'rb') as f:
    for blk in iter(lambda: f.read(1<<22), b''): h.update(blk)
print(h.hexdigest()+'  '+sys.argv[1])" "$z" | tee "$z.md5"
    fi
done
echo
echo "===================================================================================================="
echo " 完成。下載:"
for z in "$CODEZIP" ${CKZIP:-}; do
    [ -f "$z" ] && echo "   $(pwd)/$z"
done
echo "===================================================================================================="

# -*- coding: utf-8 -*-
"""
TTP tagger (Transformer+CRF) — KELLECT4APT / 32-way 3-shot 版本
================================================================
以你那支 `train_ttp_conservative.py` 為底，**模型/損失/權重結構完全不動**
(Transformer_CRF、FocalLoss、class weight、推論端 O-bias 全保留 → 存出來的
state_dict 仍跟 infer_saga.py 的架構相容)。只改三件事：

  1. 資料改吃 KELLECT4APT：
       KELLECT4APT/public_data/<任一層>/<label 資料夾>/<sample>.json
     - 每個 .json = 一個 sample(一條事件序列)
     - 每筆事件的 TTP label = 「裝這個 .json 的資料夾名稱」(你指定的規則)
     - 事件 schema 與 expanded_instance.json 相同：
         event = {"srcNode":{"Type":.., <attr>:..},
                  "dstNode":{"Type":.., <attr>:..} 或 None,
                  "relation": ..}
       Type∈{Process,File,Registry,Network} → attr 用 Cmdline/Name/Key/Dstaddress
     - label 不再從 event["label"] 拿(KELLECT4APT 事件裡沒有)，改從資料夾名。

  2. 32-way 3-shot few-shot(episodic 多回合平均，你選的方案)：
       每個 episode：從合格類別抽 N_WAY 類，每類抽 K_SHOT 個 sample 當 support(訓練)，
       其餘 sample 當 query，query 再對半切成 val / test。
       → 用 val 選 best epoch + 決定 deploy O-bias，套到 test；重抽 N_EPISODES 回合取平均。
     這樣既是 few-shot，又保住你原本「bias 在 val 選、test 不偷看」的做法。

  3. label2index / index2label 由「資料夾名稱」自動建立並存檔(你不用手刻)。
     node/edge 的 vocab 與 embedding **仍需你先用 make_embedding.py 對 KELLECT4APT 重生**
     (見檔案最下方註解「需要提供哪些檔」)。

調參改最上面 CONFIG。
"""
import os
import re
import math
import json
import random
import pickle
import logging
import gc
import time
import atexit
import argparse
import hashlib
from glob import glob
from collections import defaultdict

import numpy as np
import pandas as pd
from tqdm import tqdm
from sklearn.metrics import classification_report, precision_recall_fscore_support

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchcrf import CRF
from torch.utils.data import DataLoader

from ckpt_guard import safe_save   # best.pt 是固定檔名,存之前先備份上一次的

from kellect_event import iter_events, event_to_triple, event_ts

# ======================================================================
# CONFIG
# ======================================================================
SEED          = 42
WINDOW_SIZE   = 256
STRIDE        = 32
BATCH_SIZE    = 64
EPOCHS        = 20          # 每個 episode 內的訓練 epoch 數 (from-scratch few-shot，太少會收斂不完全)
LR            = 2e-4        # (原 5e-5 對 from-scratch + 少步數太低 → 提高加速收斂)
WARMUP_RATIO  = 0.1         # 前 10% epoch 線性 warmup，再接 cosine 衰減 (穩定高 LR)

# ---- few-shot (episodic) ----
N_WAY         = 32          # 每個 episode 用幾類 (>合格類別數就用全部)
K_SHOT        = 3           # 每類幾個 support sample = 訓練
N_EPISODES    = 5           # 重抽幾回合取平均 (Zoomer 用 10；想更穩就調大)
HOLDOUT_PER_CLASS = 1       # 每類固定保留幾個樣本當 inference(絕不進 training/support/val)
MIN_SAMPLES   = K_SHOT + HOLDOUT_PER_CLASS  # 一類至少要有這麼多 sample 才合格

# ---- 保守度控制 (跟原版一致) ----
ATTACK_CLASS_WEIGHT = 3.0   # 攻擊類權重，調小 → 較保守
O_CLASS_WEIGHT      = 1.0   # O 類權重(若資料裡根本沒有 O 類，這條自動失效)
FOCAL_GAMMA         = 2.0
O_DECODE_BIAS       = None  # None → 用 val 自動建議；設數值 → 直接用
O_BIAS_SWEEP        = [0.0, 0.5, 1.0, 2.0, 4.0, 8.0]
RECALL_TOL          = 0.02

# ---- 評估加速 (避免 epoch 收尾的 bias-sweep 看起來卡死) ----
# train 仍用 stride-32 重疊視窗(當資料增強)；但 val/test 只需非重疊視窗就能算 token 指標，
# 取 [::WINDOW_SIZE//STRIDE] 可省 ~8 倍解碼量。再加一個總數上限當保險。
EVAL_NONOVERLAP  = True     # val/test 每個 sample 只取非重疊視窗
EVAL_MAX_WINDOWS = 4000     # val / test 各自的視窗上限；超過就隨機抽樣 (0=不限)

# ---- 資料 / label ----
# KELLECT4APT public_data 根目錄(server 上請改成實際路徑)。
DATA_ROOT     = "./KELLECT4APT/public_data"
# label = 裝 .json 的資料夾名。若想把 "T1003.001-3" 收斂成 sub-technique "T1003.001"
# (把 -N 變體當同一類的不同 sample) → 設 True。預設 False = 照你講的字面規則。
STRIP_VARIANT_SUFFIX = False
VARIANT_RE    = re.compile(r"-\d+$")     # 去尾綴用；只在 STRIP_VARIANT_SUFFIX=True 生效
# 若某資料夾名(正規化後)屬於下列，視為背景類 O：
BENIGN_NAMES  = {"O", "benign", "BENIGN", "normal", "NORMAL", "none", "NONE"}

# ---- 資產路徑 (node/edge vocab + embedding；請先用 make_emb_K4APT.py 對 KELLECT4APT 重生) ----
RELATIONS_TXT = "./relations.txt"          # (已不需要；保留只為相容舊 CLI，不再使用)
SB_DIR        = "./SecureBERT2.0-K4APT"    # 內含 nodes/edges 的 vocab2idx + *_ent2emb_*.pkl
LABEL2IDX_OUT = "./label2index_kellect4apt.pkl"
IDX2LABEL_OUT = "./index2label_kellect4apt.pkl"

CACHE_TRACES  = "./kellect4apt_traces.pt"  # 預處理後的 per-sample 視窗快取
MODEL_SAVE    = "./Trans_CRF_KELLECT4APT/save_model"
RESULT_SAVE   = "./Trans_CRF_KELLECT4APT/save_result"
# ======================================================================

# 允許用命令列覆蓋幾個常改的路徑/數字(不改 code 就能在 server 換路徑)
ap = argparse.ArgumentParser()
ap.add_argument("--data_root", default=DATA_ROOT)
ap.add_argument("--sb_dir", default=SB_DIR)
ap.add_argument("--relations_txt", default=RELATIONS_TXT)
ap.add_argument("--episodes", type=int, default=N_EPISODES)
ap.add_argument("--n_way", type=int, default=N_WAY)
ap.add_argument("--k_shot", type=int, default=K_SHOT)
ap.add_argument("--strip_variant", action="store_true", default=STRIP_VARIANT_SUFFIX)
ap.add_argument("--holdout", type=int, default=HOLDOUT_PER_CLASS)
ap.add_argument("--lr", type=float, default=LR)
ap.add_argument("--epochs", type=int, default=EPOCHS)
ap.add_argument("--rebuild_cache", action="store_true")
args, _ = ap.parse_known_args()
DATA_ROOT = args.data_root
SB_DIR = args.sb_dir
RELATIONS_TXT = args.relations_txt
N_EPISODES = args.episodes
N_WAY = args.n_way
K_SHOT = args.k_shot
HOLDOUT_PER_CLASS = args.holdout
LR = args.lr
EPOCHS = args.epochs
MIN_SAMPLES = K_SHOT + HOLDOUT_PER_CLASS
STRIP_VARIANT_SUFFIX = args.strip_variant

random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")
logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s",
                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

# ----------------------------------------------------------------------
# 讀資產：node/edge vocab + embedding (由 make_emb_K4APT.py 產)
# ----------------------------------------------------------------------
with open(f"{SB_DIR}/nodes/vocab2idx.pkl", "rb") as fp:
    node_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/edges/vocab2idx.pkl", "rb") as fp:
    edge_ent2idx = pickle.load(fp)
with open(f"{SB_DIR}/nodes_ent2emb_256.pkl", "rb") as fp:
    node_ent2emb = pickle.load(fp)
with open(f"{SB_DIR}/edges_ent2emb_16.pkl", "rb") as fp:
    edge_ent2emb = pickle.load(fp)

NODE_EMB_SIZE = 256
EDGE_EMB_SIZE = 16
EVENT_DIM = NODE_EMB_SIZE * 2 + EDGE_EMB_SIZE

# embedding 表 (最後補一列 zero 當 PAD)
node_emb_tensor = torch.tensor(np.array(node_ent2emb), dtype=torch.float32).to(device)
edge_emb_tensor = torch.tensor(np.array(edge_ent2emb), dtype=torch.float32).to(device)
NODE_PAD_IDX = node_emb_tensor.shape[0]
EDGE_PAD_IDX = edge_emb_tensor.shape[0]
node_emb_tensor = torch.cat([node_emb_tensor, torch.zeros(1, NODE_EMB_SIZE).to(device)], dim=0)
edge_emb_tensor = torch.cat([edge_emb_tensor, torch.zeros(1, EDGE_EMB_SIZE).to(device)], dim=0)


# ----------------------------------------------------------------------
# label 由資料夾名決定
# ----------------------------------------------------------------------
def label_of(json_path):
    """label = 裝這個 .json 的資料夾名(選擇性去掉 -N 變體尾綴)。
    KELLECT4APT 結構 public_data/<sub-technique>/<sub-technique>-N.json，
    資料夾名(如 T1003.001)本身就是 label，-N 在檔名上是同類的不同 sample。"""
    name = os.path.basename(os.path.dirname(json_path))
    if STRIP_VARIANT_SUFFIX:
        name = VARIANT_RE.sub("", name)
    if name in BENIGN_NAMES:
        return "O"
    return name


# 事件抽取一律走 kellect_event（跟 make_emb_K4APT 同一套）：
#   iter_events(path) -> [事件dict, ...]
#   event_to_triple(e) -> (src, edge, dst) 或 None
#   event_ts(e) -> TimeStamp


# ----------------------------------------------------------------------
# 掃資料 → {label: [json_path,...]}
# ----------------------------------------------------------------------
def scan_dataset(data_root):
    paths = glob(os.path.join(data_root, "**", "*.json"), recursive=True)
    if not paths:
        raise FileNotFoundError(
            f"在 {data_root} 底下找不到任何 .json。\n"
            f"請把 --data_root 指到 KELLECT4APT/public_data (裡面是 <資料夾>/<label 資料夾>/*.json)。")
    by_class = defaultdict(list)
    for p in paths:
        by_class[label_of(p)].append(p)
    return by_class, paths


by_class_all, all_json = scan_dataset(DATA_ROOT)

# schema 探針：抽第一個檔前幾筆，確認 event_to_triple 抽得出三元組
try:
    _peek = iter_events(all_json[0])
    logging.info(f"[schema 探針] {all_json[0]}  (前 {min(len(_peek),200)} 筆抽樣)")
    if _peek:
        _e0 = _peek[0]
        logging.info(f"  第一筆事件 keys = {list(_e0.keys())}")
        _tri = [event_to_triple(e) for e in _peek[:200]]
        _ok = [t for t in _tri if t is not None]
        logging.info(f"  可轉三元組比率 = {len(_ok)}/{min(len(_peek),200)}")
        if _ok:
            s, ed, d = _ok[0]
            logging.info(f"  範例三元組: src={s!r}  edge={ed!r}  dst={d!r}")
        else:
            logging.warning("前 200 筆都轉不出三元組 → 確認事件是 Event/PName/args 結構(kellect_event.py)。")
    else:
        logging.warning(f"第一個檔 {all_json[0]} parse 後 0 筆事件。")
except Exception as _ex:
    logging.warning(f"schema 探針失敗: {_ex}")


# ----------------------------------------------------------------------
# label2index / index2label：由所有 label 建立(O 若存在放 index 0)
# ----------------------------------------------------------------------
labels_sorted = sorted(by_class_all.keys())
ordered = (["O"] if "O" in labels_sorted else []) + [l for l in labels_sorted if l != "O"]
label2index = {l: i for i, l in enumerate(ordered)}
index2label = {i: l for l, i in label2index.items()}
with open(LABEL2IDX_OUT, "wb") as fp:
    pickle.dump(label2index, fp)
with open(IDX2LABEL_OUT, "wb") as fp:
    pickle.dump(index2label, fp)

OUTPUT_SIZE = len(label2index)
O_IDX = label2index.get("O", -1)
PAD_LABEL = O_IDX if O_IDX != -1 else 0    # pad 位置的 label(反正 mask=0 不算進 loss/metric)

# 診斷：每類樣本數、有幾類合格
counts = {l: len(v) for l, v in by_class_all.items()}
eligible = [l for l, c in counts.items() if l != "O" and c >= MIN_SAMPLES]
logging.info(f"=== KELLECT4APT 掃描結果 ===")
logging.info(f"總 .json 樣本數 = {len(all_json)}；類別數(含O={'有' if O_IDX!=-1 else '無'}) = {OUTPUT_SIZE}")
logging.info(f"STRIP_VARIANT_SUFFIX = {STRIP_VARIANT_SUFFIX}  (label 由資料夾名決定)")
logging.info(f"合格類別(sample>= {MIN_SAMPLES}，可做 {K_SHOT}-shot) = {len(eligible)} / 目標 N_WAY={N_WAY}")
_dist = sorted(counts.items(), key=lambda x: -x[1])
logging.info("樣本數最多的幾類: " + ", ".join(f"{l}:{c}" for l, c in _dist[:8]))
logging.info("樣本數最少的幾類: " + ", ".join(f"{l}:{c}" for l, c in _dist[-8:]))
if len(eligible) < N_WAY:
    logging.warning(
        f"合格類別只有 {len(eligible)} < N_WAY({N_WAY})。"
        f"每個 episode 會改用全部 {len(eligible)} 類。\n"
        f"    若你要的是『每類多個變體』的 3-shot，通常要把 --strip_variant 打開"
        f"(T1003.001-3 → T1003.001，變體資料夾變成同類的不同 sample)。")


# ----------------------------------------------------------------------
# 把一個 sample(.json) 處理成 window 清單(label 全填該 sample 的類別)
# ----------------------------------------------------------------------
def process_sample(json_path, label_idx):
    events = iter_events(json_path)
    events.sort(key=event_ts)                       # 依 TimeStamp 保證時序
    seq_src, seq_rel, seq_dst = [], [], []
    for e in events:
        tri = event_to_triple(e)
        if tri is None:                             # Thread*/DiskIO*/缺物件 → 跳過
            continue
        src, edge, dst = tri
        seq_src.append(node_ent2idx.get(src, NODE_PAD_IDX))
        seq_rel.append(edge_ent2idx.get(edge, EDGE_PAD_IDX))
        seq_dst.append(node_ent2idx.get(dst, NODE_PAD_IDX))
    n = len(seq_src)
    if n == 0:
        return []
    seq_lab = [label_idx] * n
    seq_msk = [1] * n
    if n % WINDOW_SIZE != 0:
        pad_len = (WINDOW_SIZE - n if n < WINDOW_SIZE
                   else ((n - WINDOW_SIZE) // STRIDE + 1) * STRIDE + WINDOW_SIZE - n)
        seq_src += [NODE_PAD_IDX] * pad_len
        seq_rel += [EDGE_PAD_IDX] * pad_len
        seq_dst += [NODE_PAD_IDX] * pad_len
        seq_lab += [PAD_LABEL] * pad_len
        seq_msk += [0] * pad_len
    windows = []
    for i in range(0, len(seq_src) - WINDOW_SIZE + 1, STRIDE):
        windows.append({
            "src": torch.tensor(seq_src[i:i+WINDOW_SIZE], dtype=torch.long),
            "rel": torch.tensor(seq_rel[i:i+WINDOW_SIZE], dtype=torch.long),
            "dst": torch.tensor(seq_dst[i:i+WINDOW_SIZE], dtype=torch.long),
            "label_idx": torch.tensor(seq_lab[i:i+WINDOW_SIZE], dtype=torch.long),
            "mask": torch.tensor(seq_msk[i:i+WINDOW_SIZE], dtype=torch.bool),
            "process": json_path,
        })
    return windows


# 預處理所有 sample 一次(快取)。結構: {label: [ {"path":.., "windows":[...] }, ... ]}
def build_or_load_cache():
    if os.path.exists(CACHE_TRACES) and not args.rebuild_cache:
        logging.info(f"載入 sample 視窗快取 {CACHE_TRACES} ...")
        blob = torch.load(CACHE_TRACES, weights_only=False)
        if (blob.get("label2index") == label2index
                and blob.get("strip") == STRIP_VARIANT_SUFFIX
                and blob.get("scheme") == "kellect_triple_v1"):
            return blob["by_class"]
        logging.warning("快取的 label/strip/scheme 與現在不符 → 重建。")
    by_class = defaultdict(list)
    for lab, paths in tqdm(by_class_all.items(), desc="processing samples"):
        li = label2index[lab]
        for p in paths:
            w = process_sample(p, li)
            if w:
                by_class[lab].append({"path": p, "windows": w})
        gc.collect()
    torch.save({"by_class": dict(by_class), "label2index": label2index,
                "strip": STRIP_VARIANT_SUFFIX, "scheme": "kellect_triple_v1"}, CACHE_TRACES)
    logging.info(f"已存快取 {CACHE_TRACES}")
    return by_class

by_class = build_or_load_cache()

# ----------------------------------------------------------------------
# 每類固定保留 HOLDOUT_PER_CLASS 個樣本當 inference（held-out，絕不進 training/val）
#   - 用 md5 穩定種子挑選 → 跨 run 可重現、不受 dict 順序影響
#   - train_pool[lab] = 其餘樣本（support / val 只能從這裡抽）
#   - holdout[lab]    = 固定 inference 樣本（每個 episode 的 test 都用它）
# ----------------------------------------------------------------------
def _stable_seed(s):
    return int(hashlib.md5(s.encode("utf-8")).hexdigest(), 16) % (2**32)

holdout, train_pool = {}, {}
for lab, samples in by_class.items():
    s = sorted(samples, key=lambda d: d["path"])      # 先固定順序
    random.Random(_stable_seed(lab) ^ SEED).shuffle(s)  # 穩定洗牌
    holdout[lab]    = s[:HOLDOUT_PER_CLASS]
    train_pool[lab] = s[HOLDOUT_PER_CLASS:]

# 合格類別：train_pool 至少要有 K_SHOT 個(能組 support)，且有保留到 holdout
eligible = [l for l in train_pool
            if l != "O" and len(train_pool[l]) >= K_SHOT and len(holdout.get(l, [])) >= HOLDOUT_PER_CLASS]

# 存出 held-out inference 樣本清單(方便你之後單獨對這些檔跑 infer)
os.makedirs(RESULT_SAVE, exist_ok=True)
with open(f"{RESULT_SAVE}/infer_holdout_files.txt", "w", encoding="utf-8") as fp:
    for lab in sorted(holdout):
        for d in holdout[lab]:
            fp.write(f"{lab}\t{d['path']}\n")
n_holdout = sum(len(v) for v in holdout.values())
logging.info(f"(holdout 切分後) 合格類別 = {len(eligible)}；"
             f"每類保留 {HOLDOUT_PER_CLASS} 個 inference 樣本(共 {n_holdout} 個，永不進 training)")
logging.info(f"held-out 清單已存 → {RESULT_SAVE}/infer_holdout_files.txt")
if len(eligible) == 0:
    # ---------- 自我診斷：分辨「schema/relations 對不上」vs「純粹檔數不夠」 ----------
    raw_counts = {l: len(v) for l, v in by_class_all.items()}   # 原始 json 檔數(掃描)
    win_counts = {l: len(v) for l, v in by_class.items()}       # 有非空視窗的樣本數
    n_total = sum(raw_counts.values())
    n_nonempty = sum(win_counts.values())
    max_raw = max(raw_counts.values()) if raw_counts else 0
    logging.error("========== few-shot 前置診斷 ==========")
    logging.error(f"類別數={len(raw_counts)}  原始json總數={n_total}  產出非空視窗的樣本數={n_nonempty}")
    logging.error(f"單一類別最多的原始json數={max_raw}  (需 >= {MIN_SAMPLES} 才能做 {K_SHOT}-shot)")

    if n_total > 0 and n_nonempty <= max(1, n_total * 0.05):
        # 判別 A：視窗幾乎全空 → event_to_triple 抽不出東西(schema 對不上)
        total_ev, n_tri, ev_types = 0, 0, defaultdict(int)
        for p in all_json[:30]:
            for e in iter_events(p):
                total_ev += 1
                if isinstance(e, dict):
                    ev_types[e.get("Event", "?")] += 1
                if event_to_triple(e) is not None:
                    n_tri += 1
        logging.error("[判別 A] 幾乎所有樣本產不出視窗 → event_to_triple 抽不出三元組(schema 對不上)。")
        logging.error(f"  抽 30 檔：可轉三元組 = {n_tri}/{total_ev}")
        logging.error(f"  出現的 Event 型別(前15)：{sorted(ev_types.items(), key=lambda x:-x[1])[:15]}")
        logging.error("  → 檢查 kellect_event.py 的 event_to_triple 是否涵蓋這些 Event/args 欄位；")
        logging.error("     若 vocab 對不上(node/edge 全 PAD)，先確認 SB_DIR 指向 make_emb_K4APT 產的新目錄。")
    else:
        # 判別 B：原始檔數就不夠 → 粒度問題，模擬 strip_variant
        regroup = defaultdict(int)
        for l, c in raw_counts.items():
            nl = "O" if l == "O" else VARIANT_RE.sub("", l)
            regroup[nl] += c
        elig_strip = sum(1 for l, c in regroup.items() if l != "O" and c >= MIN_SAMPLES)
        logging.error(f"[判別 B] 每類原始 json 檔數不足 {MIN_SAMPLES}。")
        logging.error(f"  開 --strip_variant(T1003.001-3 併成 T1003.001) 後："
                      f"類別 {len(raw_counts)}→{len(regroup)}，合格(>= {MIN_SAMPLES})={elig_strip}")
        if elig_strip > 0:
            logging.error("  → 建議：STRIP=1 bash run_k4apt.sh  (或 python tranK.py ... --strip_variant)")
        else:
            logging.error("  → strip 後仍不夠：考慮把 K_SHOT 調小，或確認資料夾層級/label 規則對不對。")
        _top = sorted(raw_counts.items(), key=lambda x: -x[1])[:10]
        logging.error(f"  原始每類 json 數(前10)：{_top}")
    raise RuntimeError(f"沒有任何類別達到 {MIN_SAMPLES} 個有效 sample"
                       f"(={K_SHOT}-shot support + {HOLDOUT_PER_CLASS} held-out)，無法做 few-shot。見上面『前置診斷』。")


# ======================================================================
# Model (與 train_ttp_conservative.py 完全一致 → state_dict 相容 infer_saga)
# ======================================================================
class FocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=2.0, reduction="mean"):
        super().__init__()
        self.weight = weight; self.gamma = gamma; self.reduction = reduction

    def forward(self, inputs, targets):
        ce = F.cross_entropy(inputs, targets, weight=self.weight, reduction="none")
        pt = torch.exp(-ce)
        focal = ((1 - pt) ** self.gamma) * ce
        return focal.mean() if self.reduction == "mean" else (focal.sum() if self.reduction == "sum" else focal)


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1), :]


class Transformer_CRF(nn.Module):
    def __init__(self, embedding_dim, output_size, layers, nhead, device, dropout=0.2):
        super().__init__()
        self.device = device
        self.tagset_size = output_size
        self.d_model = 512
        self.input_proj = nn.Linear(embedding_dim, self.d_model)
        self.pos_encoder = PositionalEncoding(self.d_model, max_len=1000)
        encoder_layers = nn.TransformerEncoderLayer(
            d_model=self.d_model, nhead=nhead, dim_feedforward=self.d_model * 2,
            dropout=dropout, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers=layers)
        self.hidden2tag = nn.Linear(self.d_model, output_size)
        self.crf = CRF(num_tags=output_size, batch_first=True)

        # 非參數: O index + 推論端 O-bias (不進 state_dict → 跟 infer 權重相容)
        self.o_idx = label2index.get("O", -1)
        self.decode_o_bias = 0.0

        # class weight (可調保守度)
        self.loss_weights = torch.ones(output_size).to(device) * ATTACK_CLASS_WEIGHT
        if self.o_idx != -1:
            self.loss_weights[self.o_idx] = O_CLASS_WEIGHT
        self.focal_loss = FocalLoss(weight=self.loss_weights, gamma=FOCAL_GAMMA)

    def emissions(self, x, mask_tensor=None):
        x = self.pos_encoder(self.input_proj(x))
        key_pad = ~mask_tensor if mask_tensor is not None else None
        out = self.transformer_encoder(x, src_key_padding_mask=key_pad)
        return self.hidden2tag(out)

    def compute_loss(self, feats, label_tensor, mask_tensor):
        crf_loss = -self.crf(emissions=feats, tags=label_tensor, mask=mask_tensor, reduction="mean")
        active = mask_tensor.view(-1)
        foc = self.focal_loss(feats.view(-1, self.tagset_size)[active], label_tensor.view(-1)[active])
        return crf_loss + foc

    def decode(self, feats, mask_tensor, o_bias=None):
        b = self.decode_o_bias if o_bias is None else o_bias
        if b != 0.0 and self.o_idx != -1:
            feats = feats.clone()
            feats[:, :, self.o_idx] = feats[:, :, self.o_idx] + b
        return self.crf.decode(emissions=feats, mask=mask_tensor)

    def forward(self, sentence_tensor, label_tensor=None, mask_tensor=None):
        feats = self.emissions(sentence_tensor, mask_tensor)
        loss = self.compute_loss(feats, label_tensor, mask_tensor) if label_tensor is not None else None
        if self.training:
            return None, loss
        return self.decode(feats, mask_tensor), loss


def _feat(data):
    src = data["src"].to(device, non_blocking=True)
    rel = data["rel"].to(device, non_blocking=True)
    dst = data["dst"].to(device, non_blocking=True)
    return torch.cat([node_emb_tensor[src], edge_emb_tensor[rel], node_emb_tensor[dst]], dim=-1)


@torch.no_grad()
def eval_sweep(model, loader, biases, attack_labels, desc=""):
    """對每個 O-bias 收 attack macro P/R/F1 (只算 attack_labels 這些類)。回傳 {bias:(P,R,F1)}。
    desc 非空時 → 顯示 tqdm 進度 + 記錄用時(讓收尾評估不再像卡死)。"""
    if loader is None or len(loader.dataset) == 0 or not attack_labels:
        return {b: (0.0, 0.0, 0.0) for b in biases}
    model.eval()
    t0 = time.time()
    trues_all, preds_by_bias = [], {b: [] for b in biases}
    batches = tqdm(loader, desc=desc, leave=False) if desc else loader
    for data in batches:
        feats = model.emissions(_feat(data), data["mask"].to(device, non_blocking=True)).float()
        mask = data["mask"].to(device, non_blocking=True)
        label_cpu = data["label_idx"].cpu().tolist()
        for k, b in enumerate(biases):
            out = model.decode(feats, mask, o_bias=b)
            for idx, pred in enumerate(out):
                preds_by_bias[b].extend(pred)
                if k == 0:
                    trues_all.extend(label_cpu[idx][:len(pred)])
    rows = {}
    for b in biases:
        p, r, f, _ = precision_recall_fscore_support(
            trues_all, preds_by_bias[b], labels=attack_labels, average="macro", zero_division=0)
        rows[b] = (p, r, f)
    if desc:
        logging.info(f"    [{desc}] {len(loader.dataset)} win × {len(biases)} bias 用時 {time.time()-t0:.1f}s")
    return rows


def recommend_bias(rows, base_bias=0.0, recall_tol=RECALL_TOL):
    base_r = rows.get(base_bias, (0, 0, 0))[1]
    cands = [(b, v) for b, v in rows.items() if v[1] >= base_r - recall_tol]
    if not cands:
        return base_bias
    return max(cands, key=lambda x: (x[1][0], x[0]))[0]


# ----------------------------------------------------------------------
# 抽一個 episode：回傳 (episode 類別, train/val/test window list, episode attack 索引)
# ----------------------------------------------------------------------
def _cap_windows(windows, rng, name):
    """val/test 視窗超過上限就隨機抽樣(仍保原本相對順序)，避免收尾評估爆量。"""
    if EVAL_MAX_WINDOWS and len(windows) > EVAL_MAX_WINDOWS:
        idx = list(range(len(windows)))
        rng.shuffle(idx)
        keep = sorted(idx[:EVAL_MAX_WINDOWS])
        logging.info(f"    [{name}] 視窗 {len(windows)} > 上限 {EVAL_MAX_WINDOWS} → 隨機抽樣至 {EVAL_MAX_WINDOWS}")
        windows = [windows[i] for i in keep]
    return windows


def sample_episode(rng):
    pool = eligible[:]
    rng.shuffle(pool)
    chosen = pool if len(pool) <= N_WAY else pool[:N_WAY]
    # val/test 每個 sample 只取非重疊視窗 → 省 ~eval_sub 倍解碼量
    eval_sub = max(1, WINDOW_SIZE // STRIDE) if EVAL_NONOVERLAP else 1
    train_w, val_w, test_w = [], [], []
    for lab in chosen:
        tp = train_pool[lab][:]           # 只從 train_pool 抽(holdout 不在裡面)
        rng.shuffle(tp)
        support = tp[:K_SHOT]             # 3-shot 訓練
        val_s   = tp[K_SHOT:]             # train_pool 剩下的當 val(選 epoch/bias 用；可能空)
        test_s  = holdout[lab]           # 固定 held-out inference 樣本(每個 episode 都一樣)
        for s in support: train_w.extend(s["windows"])                 # 訓練用全部(含重疊)
        for s in val_s:   val_w.extend(s["windows"][::eval_sub])       # 評估用非重疊
        for s in test_s:  test_w.extend(s["windows"][::eval_sub])
    val_w  = _cap_windows(val_w, rng, "val")
    test_w = _cap_windows(test_w, rng, "holdout")
    atk = [label2index[l] for l in chosen if l != "O"]
    return chosen, train_w, val_w, test_w, atk


def make_loader(windows, shuffle):
    return DataLoader(windows, batch_size=BATCH_SIZE, shuffle=shuffle,
                      num_workers=0, pin_memory=True) if windows else None


# ======================================================================
# Episodic train / eval
# ======================================================================
os.makedirs(MODEL_SAVE, exist_ok=True)
os.makedirs(RESULT_SAVE, exist_ok=True)


def _make_ckpt_blob(best_state, deploy_bias):
    return {
        "state_dict": best_state,
        "deploy_o_bias": deploy_bias,
        "label2index": label2index,
        "index2label": index2label,
        "arch": {"event_dim": EVENT_DIM, "output_size": OUTPUT_SIZE,
                 "d_model": 512, "layers": 2, "nhead": 8, "dropout": 0.2},
        "window_size": WINDOW_SIZE, "stride": STRIDE,
        "sb_dir": SB_DIR, "scheme": "kellect_triple_v1",
    }


def save_best_ckpt(best_state, deploy_bias, val_f1, archival=True):
    """寫 best.pt(infer_K4APT.py 預設讀這個)。
    archival=True → 另存一份帶分數/bias 的存檔名(正式全域最佳時用)；
    archival=False → 只覆蓋 best.pt(epoch 內即時存，不洗出一堆檔)。"""
    blob = _make_ckpt_blob(best_state, deploy_bias)
    # best.pt 是固定檔名:safe_save 會先把「上一次執行」留下的備份成 .bak_<時間>,
    # 每個 process 只備份一次。archival 分支本來就寫帶分數的檔名,所以 unique=False。
    safe_save(blob, f"{MODEL_SAVE}/best.pt", score=val_f1, unique=not archival, quiet=True)
    if archival:
        torch.save(blob, f"{MODEL_SAVE}/best_AtkF1_{val_f1:.4f}_bias_{deploy_bias}.pt")
    tag = "" if archival else " [即時/暫定bias]"
    logging.info(f"    ✔ best.pt 已更新{tag} (metric={val_f1:.4f}, bias={deploy_bias})")


def save_inprogress(best_state, deploy_bias, metric):
    """val=None 模式的 epoch 內即時存(不動 best.pt 的全域最佳保證)。"""
    torch.save(_make_ckpt_blob(best_state, deploy_bias), f"{MODEL_SAVE}/inprogress.pt")
    logging.info(f"    ↳ 即時存 → {MODEL_SAVE}/inprogress.pt (metric={metric:.4f})")


_WARMUP_EPOCHS = max(1, int(EPOCHS * WARMUP_RATIO))
def _warmup_cosine(e):
    """前 _WARMUP_EPOCHS epoch 線性 warmup(0→1)，之後 cosine 衰減到 ~0。"""
    if e < _WARMUP_EPOCHS:
        return (e + 1) / _WARMUP_EPOCHS
    prog = (e - _WARMUP_EPOCHS) / max(1, EPOCHS - _WARMUP_EPOCHS)
    return 0.5 * (1.0 + math.cos(math.pi * min(1.0, prog)))


episode_rows = []
global_best_val_f1 = float("-inf")
global_best = None   # (state_dict, deploy_bias, test_pred, test_label)
best_state = None    # 讓中斷發生在 episode 0 中途時，緊急存檔仍能引用到手上的權重
deploy_bias = O_DECODE_BIAS if O_DECODE_BIAS is not None else 0.0
_disk_best = float("-inf")   # 硬碟上 best.pt 目前的分數(單調遞增，守住 best.pt=全域最佳)


def _emergency_save():
    """Ctrl-C / 程式非正常結束時的安全網：
    若還沒有任何 episode 的 checkpoint 落盤(global_best 仍是 None)，
    就把目前記憶體裡最好的 best_state 緊急寫到 best.pt(bias 可能還沒調，之後 infer 端可用 --o_bias 覆蓋)。"""
    if global_best is not None:
        return                      # 已有正式 best.pt(save_best_ckpt 存過)，不覆蓋未驗證的權重
    bs = globals().get("best_state")
    if bs is None:
        return                      # 連一個 epoch 的 best_state 都還沒有 → 沒東西可存
    try:
        save_best_ckpt(bs, globals().get("deploy_bias", 0.0), globals().get("best_val_f1", float("nan")))
        logging.warning("⚠ 偵測到中斷/非正常結束 → 已把當前最佳權重緊急存到 best.pt")
    except Exception as ex:
        logging.error(f"緊急存檔失敗: {ex}")


atexit.register(_emergency_save)

for ep in range(N_EPISODES):
    rng = random.Random(SEED + ep)
    chosen, train_w, val_w, test_w, atk = sample_episode(rng)
    train_loader = make_loader(train_w, True)
    val_loader   = make_loader(val_w, False)
    test_loader  = make_loader(test_w, False)
    logging.info(f"===== Episode {ep} | {len(chosen)}-way {K_SHOT}-shot | "
                 f"support_win={len(train_w)} val_win={len(val_w)} holdout_win={len(test_w)} =====")
    if train_loader is None or test_loader is None:
        logging.warning(f"Episode {ep} 缺 support/holdout，跳過。")
        continue

    model = Transformer_CRF(EVENT_DIM, OUTPUT_SIZE, layers=2, nhead=8, device=device, dropout=0.2).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, _warmup_cosine)
    scaler = torch.amp.GradScaler("cuda")

    best_val_f1, best_state = float("-inf"), None
    for epoch in range(EPOCHS):
        model.train()
        losses = []
        for data in train_loader:
            label = data["label_idx"].to(device, non_blocking=True)
            mask = data["mask"].to(device, non_blocking=True)
            optimizer.zero_grad()
            with torch.amp.autocast("cuda"):
                _, loss = model(_feat(data), label, mask)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            scaler.step(optimizer); scaler.update()
            losses.append(loss.item())
        scheduler.step()

        if val_loader is not None:
            vf1 = eval_sweep(model, val_loader, [0.0], atk)[0.0][2]
            sel = vf1
        else:
            sel = -np.mean(losses)   # 沒 val → 用負 train loss 當選擇依據
            vf1 = float("nan")
        improved = sel > best_val_f1
        if improved:
            best_val_f1 = sel
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        logging.info(f"  ep{ep} epoch{epoch} lr={optimizer.param_groups[0]['lr']:.2e} "
                     f"loss={np.mean(losses):.4f} val_atkF1={vf1:.4f}")
        # 長 episode 即時存檔: 這個 epoch 一刷新最佳就落盤，中途崩潰不白跑好幾小時
        if improved and best_state is not None:
            if val_loader is not None and best_val_f1 > _disk_best:
                _disk_best = best_val_f1                                   # 只在贏過硬碟最佳時覆蓋 → best.pt 單調變好
                save_best_ckpt(best_state, deploy_bias, best_val_f1, archival=False)
            elif val_loader is None:
                save_inprogress(best_state, deploy_bias, best_val_f1)      # val=None → 寫 inprogress.pt, 不動 best.pt

    if best_state is not None:
        model.load_state_dict(best_state)

    # 決定 deploy O-bias (val 上；沒 val 就用設定值或 0)
    logging.info(f"  ep{ep} 訓練完成 → 開始收尾評估(val bias-sweep + holdout)...")
    if val_loader is not None:
        vrows = eval_sweep(model, val_loader, O_BIAS_SWEEP, atk, desc=f"ep{ep} val-bias-sweep")
        deploy_bias = O_DECODE_BIAS if O_DECODE_BIAS is not None else recommend_bias(vrows)
    else:
        deploy_bias = O_DECODE_BIAS if O_DECODE_BIAS is not None else 0.0

    trows = eval_sweep(model, test_loader, sorted(set([0.0, deploy_bias])), atk, desc=f"ep{ep} holdout")
    (bp, br, bf) = trows[0.0]
    (dp, dr, df) = trows[deploy_bias]
    logging.info(f"  [Ep{ep} HOLDOUT base   bias=0        ] P={bp:.4f} R={br:.4f} F1={bf:.4f}")
    logging.info(f"  [Ep{ep} HOLDOUT deploy bias={deploy_bias:<4}] P={dp:.4f} R={dr:.4f} F1={df:.4f}")
    episode_rows.append({"episode": ep, "n_way": len(chosen), "deploy_bias": deploy_bias,
                         "base_P": bp, "base_R": br, "base_F1": bf,
                         "deploy_P": dp, "deploy_R": dr, "deploy_F1": df})

    # 用「val 最好」的 episode 當要 deploy 的 checkpoint，並留它的 test 預測做 result.csv
    val_metric = best_val_f1 if val_loader is not None else df
    if val_metric > global_best_val_f1:
        global_best_val_f1 = val_metric
        model.decode_o_bias = deploy_bias
        preds, labs = [], []
        model.eval()
        t0 = time.time()
        with torch.no_grad():
            for data in tqdm(test_loader, desc=f"ep{ep} collect-preds", leave=False):
                mask = data["mask"].to(device, non_blocking=True)
                with torch.amp.autocast("cuda"):
                    out, _ = model(_feat(data), None, mask)
                lab_cpu = data["label_idx"].cpu().tolist()
                for idx, pred in enumerate(out):
                    preds.extend(pred); labs.extend(lab_cpu[idx][:len(pred)])
        logging.info(f"    [ep{ep} collect-preds] 用時 {time.time()-t0:.1f}s")
        global_best = (best_state, deploy_bias, preds, labs)
        # episode 確認為全域最佳 → 用「調好的 bias」正式覆蓋一次(含存檔名)，並同步 _disk_best
        save_best_ckpt(best_state, deploy_bias, global_best_val_f1, archival=True)
        _disk_best = max(_disk_best, global_best_val_f1)

    logging.info(f"===== Episode {ep} 完成 =====")
    del model; gc.collect(); torch.cuda.empty_cache()

# ======================================================================
# 匯總 + 存檔
# ======================================================================
if not episode_rows:
    raise RuntimeError("沒有任何 episode 成功執行。")

edf = pd.DataFrame(episode_rows)
summary = {
    "base_P": (edf.base_P.mean(), edf.base_P.std()),
    "base_R": (edf.base_R.mean(), edf.base_R.std()),
    "base_F1": (edf.base_F1.mean(), edf.base_F1.std()),
    "deploy_P": (edf.deploy_P.mean(), edf.deploy_P.std()),
    "deploy_R": (edf.deploy_R.mean(), edf.deploy_R.std()),
    "deploy_F1": (edf.deploy_F1.mean(), edf.deploy_F1.std()),
}
logging.info(f"===== {N_EPISODES}-episode 平均 ({N_WAY}-way {K_SHOT}-shot；"
             f"評估於每類固定 held-out {HOLDOUT_PER_CLASS} 樣本) =====")
for k, (m, s) in summary.items():
    logging.info(f"  {k:>9}: {m:.4f} ± {s:.4f}")

edf.to_csv(f"{RESULT_SAVE}/episodes.csv", index=False)
pd.DataFrame([{"metric": k, "mean": m, "std": s} for k, (m, s) in summary.items()]
             ).to_csv(f"{RESULT_SAVE}/summary.csv", index=False)

# best episode 的 checkpoint + 逐類 classification_report
if global_best is not None:
    best_state, deploy_bias, preds, labs = global_best
    ckpt_blob = {
        "state_dict": best_state,
        "deploy_o_bias": deploy_bias,
        "label2index": label2index,
        "index2label": index2label,
        "arch": {"event_dim": EVENT_DIM, "output_size": OUTPUT_SIZE,
                 "d_model": 512, "layers": 2, "nhead": 8, "dropout": 0.2},
        "window_size": WINDOW_SIZE, "stride": STRIDE,
        "sb_dir": SB_DIR, "scheme": "kellect_triple_v1",
    }
    ckpt = f"{MODEL_SAVE}/best_AtkF1_{global_best_val_f1:.4f}_bias_{deploy_bias}.pt"
    torch.save(ckpt_blob, ckpt)                      # 帶分數的存檔名,不會被覆蓋
    safe_save(ckpt_blob, f"{MODEL_SAVE}/best.pt",    # 穩定路徑,infer_K4APT.py 預設讀這個
              score=global_best_val_f1, unique=False, quiet=True)
    logging.info(f"saved checkpoint {ckpt}")
    logging.info(f"saved {MODEL_SAVE}/best.pt (自帶 arch/label/bias，給 infer_K4APT.py)")
    report = classification_report(labs, preds, output_dict=True, zero_division=0)
    rdf = pd.DataFrame(report).transpose().reset_index(names="label")
    rdf["label"] = rdf["label"].apply(lambda x: index2label.get(int(x), x) if str(x).isdigit() else x)
    rdf.to_csv(f"{RESULT_SAVE}/result.csv", index=False)
    logging.info(f"saved {RESULT_SAVE}/result.csv")

logging.info("Done.")

# ======================================================================
# 需要提供 / 先產生哪些檔
# ----------------------------------------------------------------------
#  共用: kellect_event.py  (事件→三元組；本 script 與 make_emb_K4APT.py 都 import)
#
#  A. 由本 script 自動產生(不用你手刻)：
#       - ./label2index_kellect4apt.pkl / ./index2label_kellect4apt.pkl   (由資料夾名建)
#       - ./kellect4apt_traces.pt        (預處理視窗快取)
#
#  B. 先用 make_emb_K4APT.py 對 KELLECT4APT 重生(舊 SecureBERT2.0-base 是別的資料，不能用)：
#       - SecureBERT2.0-K4APT/nodes/vocab2idx.pkl      ┐ node 字串(PName/KeyName/FileName/IP…)→id
#       - SecureBERT2.0-K4APT/edges/vocab2idx.pkl      ┤ edge 字串(Event 名)→id
#       - SecureBERT2.0-K4APT/nodes_ent2emb_256.pkl    ┤ node 256d embedding(對齊 vocab)
#       - SecureBERT2.0-K4APT/edges_ent2emb_16.pkl     ┘ edge 16d  embedding(對齊 vocab)
#     產法(不需要 relations.txt)：
#       python make_emb_K4APT.py \
#         --data_glob "./KELLECT4APT/public_data/**/*.json" \
#         --save_dir  ./SecureBERT2.0-K4APT
#     兩邊都走 kellect_event.event_to_triple → node/edge 字串保證一致，不會 OOV。
# ======================================================================

#!/usr/bin/env bash
# ============================================================================
# KELLECT4APT + LLM embedding 一鍵整套：結構化 emb → LLM node emb → 兩架構訓練 → 推論
# huya* 良性 process 全程「保留並標 O」(KELLECT_KEEP_BENIGN=1)，讓模型學到它們是 benign。
# 每步「輸出已存在就跳過」。用獨立 emb 夾 ./SecureBERT2.0-K4APT-llm，不動原本的 K4APT 資產。
# ----------------------------------------------------------------------------
# 用法:
#   bash run_k4apt_llm.sh
#   LLM_BACKEND=hf HF_MODEL=Qwen/Qwen2.5-7B-Instruct bash run_k4apt_llm.sh
# 需要: ./KELLECT4APT/public_data/**/*.json 就位；GPU + torch/torchcrf/transformers。
# ============================================================================
set -e
export KELLECT_KEEP_BENIGN=1                    # 全程保留 huya* 事件 (訓練時標 O)

LLM_BACKEND="${LLM_BACKEND:-template}"          # template | hf | anthropic | openai
HF_MODEL="${HF_MODEL:-Qwen/Qwen2.5-7B-Instruct}"
PCA_DIM="${PCA_DIM:-128}"
EPOCHS="${EPOCHS:-20}"
SBDIR="./SecureBERT2.0-K4APT-llm"
GLOB="./KELLECT4APT/public_data/**/*.json"

echo "==== [1/5] 結構化 node/edge emb (含 huya) → $SBDIR ===="
if [ -f "$SBDIR/nodes/vocab2idx.pkl" ]; then
    echo "  已存在 $SBDIR/nodes/vocab2idx.pkl，跳過"
else
    python make_emb_K4APT.py --data_glob "$GLOB" --save_dir "$SBDIR"
fi

echo "==== [2/5] LLM node embedding (backend=$LLM_BACKEND) → $SBDIR ===="
if ls "$SBDIR"/llm_node_ent2emb_*.pkl >/dev/null 2>&1; then
    echo "  已存在 llm_node_ent2emb_*.pkl，跳過"
else
    python emb_K4APT_llm.py --data_glob "$GLOB" --save_dir "$SBDIR" \
        --llm_backend "$LLM_BACKEND" --hf_model "$HF_MODEL" --pca_dim "$PCA_DIM"
fi

echo "==== [3/5] 訓練 架構A：時間 chunk (256,64,16) + LLM ===="
python tranK_llm.py --chunk_kind temporal --use_llm 1 --sb_dir "$SBDIR" --llm_dir "$SBDIR" --epochs "$EPOCHS"

echo "==== [4/5] 訓練 架構B：圖 hop (3,2,1) + LLM ===="
python tranK_llm.py --chunk_kind hop --use_llm 1 --sb_dir "$SBDIR" --llm_dir "$SBDIR" --epochs "$EPOCHS"

echo "==== [5/5] 推論 (holdout, trace 級多數決) ===="
python infer_K4APT_llm.py --ckpt ./Trans_CRF_KELLECT4APT_llm/save_model/best_temporal_llm.pt
python infer_K4APT_llm.py --ckpt ./Trans_CRF_KELLECT4APT_llm/save_model/best_hop_llm.pt

echo "==== 完成。checkpoint: ./Trans_CRF_KELLECT4APT_llm/save_model/best_{temporal,hop}_llm.pt ===="

# -*- coding: utf-8 -*-
"""ckpt_guard.py — 防止固定檔名的 checkpoint 被無聲覆蓋。

背景:本專案 t2 的原始 checkpoint 就是被覆蓋掉的 —— 訓練腳本用固定檔名
(`best.pt` / `best_{kind}_llm{suffix}.pt`),沒換名字再跑一次就直接蓋掉,
沒有備份也沒有警告。t1/t5 用 `epoch_{N}_AtkF1_{f}` 命名,所以還在。

用法(在訓練腳本裡把 torch.save 換成 safe_save):

    from ckpt_guard import safe_save
    safe_save(blob, f"{MODEL_SAVE}/best.pt", epoch=epoch, score=val_f1)

它會做兩件事:
    1. 另存一份帶 epoch + 分數的唯一檔名(`best_ep7_f0.8123.pt`)→ 永不被覆蓋
    2. 固定檔名照舊寫(相容既有腳本與文件),但**先把舊的備份成 .bak_<時間>**

環境變數:
    NO_CKPT_BACKUP=1   不備份舊的固定檔名(確定不需要時)
    NO_CKPT_UNIQUE=1   不另存唯一檔名(省磁碟)
"""
import os
import shutil
from datetime import datetime

import torch

__all__ = ["safe_save", "backup_if_exists", "unique_name"]


def unique_name(path, epoch=None, score=None):
    """best.pt + epoch=7 + score=0.8123 → best_ep7_f0.8123.pt"""
    root, ext = os.path.splitext(path)
    bits = []
    if epoch is not None:
        bits.append(f"ep{epoch}")
    if score is not None:
        bits.append(f"f{score:.4f}")
    if not bits:
        bits.append(datetime.now().strftime("%Y%m%d_%H%M%S"))
    return f"{root}_{'_'.join(bits)}{ext or '.pt'}"


def backup_if_exists(path, quiet=False):
    """固定檔名已存在 → 複製成 .bak_<時間戳>。回傳備份路徑,沒備份則回 None。"""
    if os.environ.get("NO_CKPT_BACKUP") == "1":
        return None
    if not os.path.exists(path):
        return None
    bak = f"{path}.bak_{datetime.now():%Y%m%d_%H%M%S}"
    shutil.copy2(path, bak)
    if not quiet:
        print(f"[ckpt_guard] {os.path.basename(path)} 已存在 → 備份成 {os.path.basename(bak)}")
    return bak


def safe_save(obj, path, epoch=None, score=None, quiet=False):
    """取代 torch.save(obj, path)。回傳 (唯一檔名, 固定檔名)。"""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    uniq = None
    if os.environ.get("NO_CKPT_UNIQUE") != "1":
        uniq = unique_name(path, epoch, score)
        torch.save(obj, uniq)
    backup_if_exists(path, quiet=quiet)
    torch.save(obj, path)
    if not quiet:
        if uniq:
            print(f"[ckpt_guard] 存檔 {os.path.basename(uniq)}(唯一)"
                  f" + {os.path.basename(path)}(固定)")
        else:
            print(f"[ckpt_guard] 存檔 {os.path.basename(path)}")
    return uniq, path


if __name__ == "__main__":
    import tempfile
    d = tempfile.mkdtemp()
    p = os.path.join(d, "best.pt")
    print("[1] 第一次存檔(沒有舊檔,不該備份)")
    u1, _ = safe_save({"v": 1}, p, epoch=3, score=0.8123)
    assert os.path.exists(p) and os.path.exists(u1)
    assert os.path.basename(u1) == "best_ep3_f0.8123.pt", u1
    assert not [f for f in os.listdir(d) if ".bak_" in f]

    print("[2] 第二次存檔(應該備份舊的,兩個唯一檔都在)")
    u2, _ = safe_save({"v": 2}, p, epoch=7, score=0.9456)
    baks = [f for f in os.listdir(d) if ".bak_" in f]
    assert len(baks) == 1, baks
    assert torch.load(os.path.join(d, baks[0]), weights_only=False)["v"] == 1, "備份不是舊內容"
    assert torch.load(p, weights_only=False)["v"] == 2, "固定檔名不是新內容"
    assert torch.load(u1, weights_only=False)["v"] == 1, "舊的唯一檔被動到了"
    assert torch.load(u2, weights_only=False)["v"] == 2

    print("[3] NO_CKPT_BACKUP=1 不備份")
    os.environ["NO_CKPT_BACKUP"] = "1"
    safe_save({"v": 3}, p, epoch=9, score=0.99, quiet=True)
    assert len([f for f in os.listdir(d) if ".bak_" in f]) == 1
    del os.environ["NO_CKPT_BACKUP"]

    print(f"\n檔案:{sorted(os.listdir(d))}")
    print("smoke passed —— 舊 checkpoint 永遠不會無聲消失。")

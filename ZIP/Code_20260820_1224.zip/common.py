"""共享: embedding loading, event featurization, config."""
import os, pickle, torch, numpy as np
from typing import List, Tuple

NODE_EMB_SIZE = 256
EDGE_EMB_SIZE = 16
EMBEDDING_SIZE = NODE_EMB_SIZE * 2 + EDGE_EMB_SIZE   # 528 (legacy SFM 格式)
PRE_EMBED_SIZE = 768                                 # SecureBERT 2.0 base per-event
WINDOW_SIZE = 512
STRIDE = 384
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _collapse_ability_label(label: str) -> str:
    """T1005_720a3356..._B → T1005_B ; T1105_hash_I → T1105_I ; O → O"""
    if label == "O" or label == "" or label.lower() == "benign": return "O"
    if label.endswith("_B"): base, suf = label[:-2], "_B"
    elif label.endswith("_I"): base, suf = label[:-2], "_I"
    else: return "O"
    tech = base.split("_", 1)[0] if "_" in base else base
    return f"{tech}{suf}"


def load_embedded_pkl(path: str, label2index: dict, collapse_ability: bool = False):
    """讀 Training_data_embedded/**/expanded_instance.pkl:
        {'embeddings': ndarray[T, 768], 'labels': list[str] len=T}
    回傳 (X[T,768] float32, Y[T] long, T)

    collapse_ability=True 時，把 label 從 T{tech}_{ability_hash}_{B|I}
    收成 T{tech}_{B|I} 再查 label2index (需搭配 label2index_tech.pkl)
    """
    with open(path, "rb") as f:
        d = pickle.load(f)
    X = torch.as_tensor(d["embeddings"], dtype=torch.float32)
    X = torch.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)   # 防呆: 來源 embedding 若有 NaN/Inf
    O = label2index["O"]
    if collapse_ability:
        Y = torch.tensor([label2index.get(_collapse_ability_label(l), O)
                          for l in d["labels"]], dtype=torch.long)
    else:
        Y = torch.tensor([label2index.get(l, O) for l in d["labels"]],
                         dtype=torch.long)
    assert X.shape[0] == Y.shape[0], f"len mismatch in {path}: X={X.shape} Y={Y.shape}"
    return X, Y, X.shape[0]


def make_window(X: torch.Tensor, Y: torch.Tensor, win: int, O: int, start: int = None):
    """回傳 (X_win[win, D], Y_win[win], mask[win])。
    若序列 <= win: right-pad；否則以 start 起頭取 win 段（start=None 時隨機）。
    """
    T, D = X.shape
    if T <= win:
        pad_x = torch.zeros(win - T, D)
        pad_y = torch.full((win - T,), O, dtype=torch.long)
        mask = torch.cat([torch.ones(T, dtype=torch.bool),
                         torch.zeros(win - T, dtype=torch.bool)])
        return torch.cat([X, pad_x], 0), torch.cat([Y, pad_y], 0), mask
    if start is None:
        import random as _r
        start = _r.randint(0, T - win)
    return X[start:start+win], Y[start:start+win], torch.ones(win, dtype=torch.bool)

TYPE2ATTR = {"Process": "Cmdline", "File": "Name",
             "Registry": "Key", "Network": "Dstaddress"}


def load_pickle(path):
    with open(path, "rb") as f: return pickle.load(f)


class Vocab:
    def __init__(self, embed_dir: str):
        self.node_ent2idx = load_pickle(os.path.join(embed_dir, "nodes/vocab2idx.pkl"))
        self.edge_ent2idx = load_pickle(os.path.join(embed_dir, "edges/vocab2idx.pkl"))
        self.node_ent2emb = load_pickle(os.path.join(embed_dir, "nodes_ent2emb_256.pkl"))
        self.edge_ent2emb = load_pickle(os.path.join(embed_dir, "edges_ent2emb_16.pkl"))

    def node_emb(self, attr) -> torch.Tensor:
        if attr in self.node_ent2idx:
            v = torch.tensor(self.node_ent2emb[self.node_ent2idx[attr]], dtype=torch.float32)
            if v.shape[0] == NODE_EMB_SIZE: return v
        return torch.zeros(NODE_EMB_SIZE)

    def edge_emb(self, rel) -> torch.Tensor:
        if rel in self.edge_ent2idx:
            v = torch.tensor(self.edge_ent2emb[self.edge_ent2idx[rel]], dtype=torch.float32)
            if v.shape[0] == EDGE_EMB_SIZE: return v
        return torch.zeros(EDGE_EMB_SIZE)


def get_value(event):
    srcT = event["srcNode"]["Type"]
    srcA = event["srcNode"][TYPE2ATTR[srcT]]
    if event["dstNode"] is None:
        dstA, dstT = srcA, srcT
    else:
        dstT = event["dstNode"]["Type"]
        dstA = event["dstNode"][TYPE2ATTR[dstT]]
    label = event.get("label", "O")
    return str(srcA), str(dstA), event["relation"], label


def events_to_embs(events, vocab: Vocab, relations: set):
    """Return [T, 528] tensor + list of raw labels (as-in-file)."""
    xs, labs = [], []
    for e in events:
        if e["relation"] not in relations: continue
        srcA, dstA, rel, lab = get_value(e)
        xs.append(torch.cat([vocab.node_emb(srcA),
                             vocab.edge_emb(rel),
                             vocab.node_emb(dstA)], 0))
        labs.append(lab)
    if not xs: return torch.zeros(0, EMBEDDING_SIZE), []
    return torch.stack(xs), labs


def sliding_windows(x: torch.Tensor, win=WINDOW_SIZE, stride=STRIDE):
    """Return list of [win, D] chunks with right-padding on the last one."""
    T, D = x.shape
    if T <= win:
        pad = torch.zeros(win - T, D)
        return [torch.cat([x, pad], 0)], [torch.cat([torch.ones(T, dtype=torch.bool),
                                                    torch.zeros(win - T, dtype=torch.bool)])]
    chunks, masks = [], []
    for s in range(0, T - win + 1, stride):
        chunks.append(x[s:s+win])
        masks.append(torch.ones(win, dtype=torch.bool))
    # tail
    if (T - win) % stride != 0:
        tail = x[-win:]
        chunks.append(tail); masks.append(torch.ones(win, dtype=torch.bool))
    return chunks, masks

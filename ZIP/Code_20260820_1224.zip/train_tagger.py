"""Stage 2: Transformer+CRF BIO2 tagger (讀 pre-embedded pkl)。

資料:
    ./Training_data_embedded/{ability}/number_XXX/expanded_instance.pkl
    格式: {'embeddings': ndarray[T,768], 'labels': list[str] len=T}
輸出:
    ./ckpt/tagger.pt   : model state + label2index + pi_train + cfg
"""
import os, math, random, pickle, logging, argparse, numpy as np, torch
import torch.nn as nn, torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from glob import glob
from tqdm import tqdm
from torchcrf import CRF   # pytorch-crf (kmkurn) — 用 num_tags=, batch_first=, .decode()
from sklearn.metrics import classification_report

from common import (PRE_EMBED_SIZE, WINDOW_SIZE, STRIDE, DEVICE,
                    load_pickle, load_embedded_pkl, make_window)

logging.basicConfig(format='%(asctime)s | %(levelname)s | %(message)s',
                    level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S')
random.seed(42)


# ---------------------------------------------------------------------------
# Dataset (lazy load, per-epoch 隨機取一段 window)
# ---------------------------------------------------------------------------
class TagDatasetTrain(Dataset):
    """每個 pkl file 一個 sample；每次 __getitem__ 隨機截 WINDOW_SIZE 段。"""
    def __init__(self, paths, label2index, collapse_ability=False):
        self.paths = paths
        self.label2index = label2index
        self.O = label2index["O"]
        self.collapse_ability = collapse_ability

    def __len__(self): return len(self.paths)

    def __getitem__(self, i):
        X, Y, _ = load_embedded_pkl(self.paths[i], self.label2index,
                                     collapse_ability=getattr(self, 'collapse_ability', False))
        return make_window(X, Y, WINDOW_SIZE, self.O, start=None)


class TagDatasetEval(Dataset):
    """對每個 pkl 展開全部 sliding windows（deterministic）以正確算 P/R/F1。"""
    def __init__(self, paths, label2index, collapse_ability=False):
        self.label2index = label2index
        self.O = label2index["O"]
        self.collapse_ability = collapse_ability
        # flatten: 每個 file 展開成多個 (path, start) tuple
        self.items = []
        for p in paths:
            # 讀 pkl 只是為了拿 T，成本不高但可以之後 cache 起來
            with open(p, "rb") as f:
                T = len(pickle.load(f)["labels"])
            if T <= WINDOW_SIZE:
                self.items.append((p, 0, T))
            else:
                for s in range(0, T - WINDOW_SIZE + 1, STRIDE):
                    self.items.append((p, s, WINDOW_SIZE))
                if (T - WINDOW_SIZE) % STRIDE != 0:
                    self.items.append((p, T - WINDOW_SIZE, WINDOW_SIZE))

    def __len__(self): return len(self.items)

    def __getitem__(self, i):
        p, s, valid = self.items[i]
        X, Y, _ = load_embedded_pkl(p, self.label2index)
        return make_window(X, Y, WINDOW_SIZE, self.O, start=s)


def collate(batch):
    xs, ys, ms = zip(*batch)
    return torch.stack(xs), torch.stack(ys), torch.stack(ms)


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
class SinusoidalPE(nn.Module):
    def __init__(self, d_model, max_len=WINDOW_SIZE):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(max_len).unsqueeze(1).float()
        div = torch.exp(torch.arange(0, d_model, 2).float() * -(math.log(10000.0)/d_model))
        pe[:, 0::2] = torch.sin(pos*div); pe[:, 1::2] = torch.cos(pos*div)
        self.register_buffer("pe", pe.unsqueeze(0))
    def forward(self, x): return x + self.pe[:, :x.size(1)]


class TransformerCRF(nn.Module):
    def __init__(self, d_in, n_tags, d_model=256, n_layers=4, n_heads=8, dropout=0.1):
        super().__init__()
        self.in_norm = nn.LayerNorm(d_in)                  # 穩定輸入 scale (結構化 528 未 normalize → 防 NaN)
        self.proj = nn.Linear(d_in, d_model)               # d_in → d_model
        self.pe = SinusoidalPE(d_model)
        enc = nn.TransformerEncoderLayer(d_model, n_heads, dim_feedforward=1024,
                                         dropout=dropout, activation="gelu",
                                         batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(enc, n_layers)
        self.head = nn.Linear(d_model, n_tags)
        self.crf = CRF(num_tags=n_tags, batch_first=True)

    def emissions(self, x, mask):
        key_pad = ~mask
        h = self.pe(self.proj(self.in_norm(x)))
        h = self.encoder(h, src_key_padding_mask=key_pad)
        return self.head(h)

    def loss(self, x, y, mask):
        # emissions 在 autocast 下是 bf16; CRF 的 log-sum-exp 在 bf16 會 overflow→NaN,
        # 一律轉 fp32 再算 CRF/focal (數值穩定)。
        e = self.emissions(x, mask).float()
        crf_loss = -self.crf(e, y, mask=mask, reduction="token_mean")
        ce = F.cross_entropy(e.transpose(1, 2), y, reduction="none")
        pt = torch.exp(-ce)
        focal = ((1 - pt) ** 2 * ce)
        focal = (focal * mask.float()).sum() / mask.float().sum().clamp(min=1)
        return 0.7 * crf_loss + 0.3 * focal

    def decode(self, x, mask):
        return self.crf.decode(self.emissions(x, mask), mask=mask)


# ---------------------------------------------------------------------------
# Train
# ---------------------------------------------------------------------------
def split_paths(data_dir, seed=42):
    """8:1:1 split per ability（跟原 SFM 分割方式一致）。"""
    tr, va, te = [], [], []
    rng = random.Random(seed)
    for abi in sorted(os.listdir(data_dir)):
        ps = glob(f"{data_dir}/{abi}/number_*/expanded_instance.pkl")
        rng.shuffle(ps)
        n = len(ps)
        n_tr = int(n * 0.8); n_va = int(n * 0.1)
        tr += ps[:n_tr]; va += ps[n_tr:n_tr+n_va]; te += ps[n_tr+n_va:]
    return tr, va, te


def compute_pi_train(paths, label2index, n_tags, cap=2000):
    """從 (最多 cap 個) 訓練 pkl 累計 tag frequency。"""
    counts = np.zeros(n_tags, dtype=np.float64)
    O = label2index["O"]
    for p in tqdm(paths[:cap], desc="scan pi_train"):
        _, Y, _ = load_embedded_pkl(p, label2index)
        for t in Y.tolist(): counts[t] += 1
    return counts / counts.sum()


def eval_loop(model, loader):
    model.eval()
    all_pd, all_gt = [], []
    with torch.no_grad():
        for X, y, M in loader:
            out = model.decode(X.to(DEVICE), M.to(DEVICE))
            for i, seq in enumerate(out):
                all_pd.extend(seq)
                all_gt.extend(y[i][:len(seq)].tolist())
    return classification_report(all_gt, all_pd, output_dict=True,
                                 zero_division=0)


def train(args):
    label2index = load_pickle(args.label2index)
    n_tags = len(label2index)
    logging.info(f"n_tags = {n_tags}")

    tr_paths, va_paths, te_paths = split_paths(args.data_dir)
    logging.info(f"paths: train={len(tr_paths)} val={len(va_paths)} test={len(te_paths)}")
    if not tr_paths:
        raise RuntimeError(f"no .pkl under {args.data_dir}/*/number_*/expanded_instance.pkl")

    # 訓練 tag prior（存進 checkpoint 給 inference 做 prior-shift correction）
    pi_train = compute_pi_train(tr_paths, label2index, n_tags, cap=args.pi_cap)
    logging.info(f"pi_train[O] = {pi_train[label2index['O']]:.4f}  "
                 f"mean(non-O) = {pi_train.mean():.6f}")

    tl = DataLoader(TagDatasetTrain(tr_paths, label2index,
                                     collapse_ability=args.collapse_ability),
                    batch_size=args.batch_size, shuffle=True,
                    collate_fn=collate, num_workers=args.num_workers,
                    persistent_workers=True if args.num_workers > 0 else False)
    vl = DataLoader(TagDatasetEval(va_paths, label2index,
                                    collapse_ability=args.collapse_ability),
                    batch_size=args.batch_size, shuffle=False,
                    collate_fn=collate, num_workers=max(1, args.num_workers // 2))

    model = TransformerCRF(PRE_EMBED_SIZE, n_tags,
                           d_model=args.d_model, n_layers=args.n_layers,
                           n_heads=args.n_heads).to(DEVICE)
    n_params = sum(p.numel() for p in model.parameters())
    logging.info(f"model params = {n_params/1e6:.2f} M")

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs * len(tl))

    best_f1 = 0.0
    os.makedirs("./ckpt", exist_ok=True)
    ckpt_path = args.ckpt

    for ep in range(args.epochs):
        model.train()
        losses = []
        for X, y, M in tqdm(tl, desc=f"tag ep{ep}"):
            X, y, M = X.to(DEVICE), y.to(DEVICE), M.to(DEVICE)
            with torch.autocast(device_type=DEVICE.type, dtype=torch.bfloat16):
                loss = model.loss(X, y, M)
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); sched.step(); opt.zero_grad()
            losses.append(loss.item())

        rep = eval_loop(model, vl)
        macro_f1 = rep["macro avg"]["f1-score"]
        logging.info(f"ep{ep} loss={np.mean(losses):.4f} "
                     f"val macro-F1={macro_f1:.4f}  weighted-F1={rep['weighted avg']['f1-score']:.4f}")

        if macro_f1 > best_f1:
            best_f1 = macro_f1
            torch.save({"model": model.state_dict(),
                        "label2index": label2index,
                        "pi_train": pi_train,
                        "cfg": {"d_in": PRE_EMBED_SIZE, "n_tags": n_tags,
                                "d_model": args.d_model, "n_layers": args.n_layers,
                                "n_heads": args.n_heads}},
                       ckpt_path)
            logging.info(f"saved {ckpt_path}  best macro-F1={best_f1:.4f}")

    # Test on best
    logging.info("=== reload best ckpt and run test set ===")
    state = torch.load(ckpt_path, map_location=DEVICE, weights_only=False)
    model.load_state_dict(state["model"])
    tel = DataLoader(TagDatasetEval(te_paths, label2index,
                                     collapse_ability=args.collapse_ability),
                     batch_size=args.batch_size, shuffle=False, collate_fn=collate,
                     num_workers=max(1, args.num_workers // 2))
    rep = eval_loop(model, tel)
    logging.info(f"TEST macro-F1={rep['macro avg']['f1-score']:.4f}  "
                 f"weighted-F1={rep['weighted avg']['f1-score']:.4f}")

    idx2 = {v: k for k, v in label2index.items()}
    import pandas as pd
    df = pd.DataFrame(rep).transpose().reset_index(names="label")
    df["label"] = df["label"].apply(lambda s: idx2[int(s)] if s.isdigit() else s)
    df.to_csv("./ckpt/tagger_test_report.csv", index=False)
    logging.info("saved ./ckpt/tagger_test_report.csv")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="./Training_data_embedded")
    ap.add_argument("--label2index", default="./label2index_0201.pkl")
    ap.add_argument("--ckpt", default="./ckpt/tagger.pt")
    ap.add_argument("--epochs", type=int, default=12)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--d_model", type=int, default=256)
    ap.add_argument("--n_layers", type=int, default=4)
    ap.add_argument("--n_heads", type=int, default=8)
    ap.add_argument("--pi_cap", type=int, default=2000,
                    help="計算 pi_train 時最多掃描的 pkl 數（省時間）")
    ap.add_argument("--collapse_ability", action="store_true",
                    help="讀 pkl label 時把 ability hash 收成 technique-level "
                         "(需搭配 --label2index ./label2index_tech.pkl)")
    train(ap.parse_args())
